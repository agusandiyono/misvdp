<?php
class Perkembangan_desa_model extends MY_Model {
	var $table = 'perkembangan_desa';
	var $id = 'id';

    function __construct()
    {
        parent::__construct();
    }
}