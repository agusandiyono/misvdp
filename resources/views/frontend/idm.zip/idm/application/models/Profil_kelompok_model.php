<?php
class Profil_kelompok_model extends MY_Model {
	var $table = 'profil_kelompok';
	var $id = 'id';

    function __construct()
    {
        parent::__construct();
    }
}