<?php
class Data_dasar_keluarga_model extends MY_Model {
	var $table = 'data_dasar_keluarga';
	var $id = 'id';

    function __construct()
    {
        parent::__construct();
    }
}