<?php
class Evkin_model extends MY_Model {
	var $table = 'evkin';
	var $id = 'id';

    function __construct()
    {
        parent::__construct();
    }
}