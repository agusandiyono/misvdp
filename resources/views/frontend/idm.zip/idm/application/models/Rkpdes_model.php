<?php
class Rkpdes_model extends MY_Model {
	var $table = 'rkpdes';
	var $id = 'id';

    function __construct()
    {
        parent::__construct();
    }
}