<?php
class Provinsi_model extends MY_Model {
	var $table = 'provinsi';
	var $id = 'provinsi_id';

    function __construct()
    {
        parent::__construct();
    }
}