<?php
class Desa_model extends MY_Model {
	var $table = 'desa';
	var $id = 'desa_id';

    function __construct()
    {
        parent::__construct();
    }
}