<?php
class Group_access_model extends MY_Model {
	var $table = 'groups_access';
	var $id = 'id';

    function __construct()
    {
        parent::__construct();
    }
}