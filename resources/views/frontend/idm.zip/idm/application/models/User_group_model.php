<?php
class User_group_model extends MY_Model {
	var $table = 'users_group';
	var $id = 'id';

    function __construct()
    {
        parent::__construct();
    }
}