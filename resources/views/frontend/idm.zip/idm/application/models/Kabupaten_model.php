<?php
class Kabupaten_model extends MY_Model {
	var $table = 'kabupaten';
	var $id = 'kabupaten_id';

    function __construct()
    {
        parent::__construct();
    }
}