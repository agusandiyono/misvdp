<?php
class Kecamatan_model extends MY_Model {
	var $table = 'kecamatan';
	var $id = 'kecamatan_id';

    function __construct()
    {
        parent::__construct();
    }
}