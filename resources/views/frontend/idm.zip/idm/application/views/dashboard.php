				<div class="row">
					<div class="col-sm-12">
						<!-- <h2 class="text-center">Tipologi Desa </h2> -->
						<!-- <div id="map" style="height: 500px; width: 100%"></div> -->
						<div class="col-sm-3">
				    	    <div class="hero-widget well well-sm">
				                <div class="icon">
				                     <i class="glyphicon glyphicon-stats"></i>
				                </div>
				                <div class="text">
				                    <var>74,093</var>
				                    <label class="text-muted">Data IPD 2014</label>
				                </div>
				                <div class="options">
				                    <a href="<?php echo site_url('ipd') ?>" class="btn btn-red btn-lg"><i class="glyphicon glyphicon-search"></i> Lihat data</a>
				                </div>
				            </div>
						</div>
				        <div class="col-sm-3">
				            <div class="hero-widget well well-sm">
				                <div class="icon">
				                     <i class="glyphicon glyphicon-star"></i>
				                </div>
				                <div class="text">
				                    <var>73,709</var>
				                    <label class="text-muted">Data IDM 2015</label>
				                </div>
				                <div class="options">
				                    <a href="<?php echo site_url('idm')?>" class="btn btn-blue btn-lg"><i class="glyphicon glyphicon-search"></i> Lihat data</a>
				                </div>
				            </div>
						</div>
				        <!-- <div class="col-sm-3">
				            <div class="hero-widget well well-sm">
				                <div class="icon">
				                     <i class="glyphicon glyphicon-tags"></i>
				                </div>
				                <div class="text">
				                    <var>73</var>
				                    <label class="text-muted">total orders</label>
				                </div>
				                <div class="options">
				                    <a href="javascript:;" class="btn btn-default btn-lg"><i class="glyphicon glyphicon-search"></i> View orders</a>
				                </div>
				            </div>
				    	</div> -->
				        <div class="col-sm-3">
				            <div class="hero-widget well well-sm">
				                <div class="icon">
				                     <i class="glyphicon glyphicon-book"></i>
				                </div>
				                <div class="text">
				                    <var>1</var>
				                    <label class="text-muted">Dokumen</label>
				                </div>
				                <div class="options">
				                    <a href="<?php echo site_url('dokumen')?>" class="btn btn-green btn-lg"><i class="glyphicon glyphicon-wrench"></i> Lihat</a>
				                </div>
				            </div>
						</div>
					</div>
				</div>
