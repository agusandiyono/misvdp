	<?php if ($this->session->flashdata('error_message')) : ?>
		<div class="alert alert-danger"><?php echo $this->session->flashdata('error_message'); ?></div>
	<?php endif;?>
	<form role="form" method="post" class="form-horizontal form-groups-bordered validate" enctype="multipart/form-data">
		<input type="hidden" name="<?php echo $this->security->get_csrf_token_name() ?>" id="csrf" value="<?php echo $this->security->get_csrf_hash() ?>" />
		<div class="form-group">
			<div class="col-sm-12">
				<span class="text-danger">* Wajib Diisi</span>
			</div>
		</div>
		<div class="form-group">
			<label for="nomor_kartu_keluarga" class="col-sm-3 control-label">Nomor Kartu Keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="nomor_kartu_keluarga" name="data[nomor_kartu_keluarga]" placeholder="nomor kartu keluarga" value="<?php echo $ddk->nomor_kartu_keluarga ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="nama_kepala_keluarga" class="col-sm-3 control-label">Nama Kepala Keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="nama_kepala_keluarga" name="data[nama_kepala_keluarga]" placeholder="nama kepala keluarga" value="<?php echo $ddk->nama_kepala_keluarga ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="alamat" class="col-sm-3 control-label">Alamat</label>
			<div class="col-sm-5">
				<textarea name="data[alamat]" id="alamat" rows="5" class="form-control" placeholder="alamat"><?php echo $ddk->alamat ?></textarea>
			</div>
		</div>
		<div class="form-group">
			<label for="provinsi_id" class="col-sm-3 control-label">Provinsi<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<?php if(!empty($this->session->userdata('provinsi_id'))): ?>
					<input type="hidden" name="data[provinsi_id]" value="<?php echo $this->session->userdata('provinsi_id') ?>" />
				<?php endif ?>
				<select name="data[provinsi_id]" class="form-control select2" id="provinsi_id" placeholder="provinsi" data-validate="required" data-message-required="kolom provinsi tidak boleh kosong." <?php echo !empty($this->session->userdata('provinsi_id')) ? 'disabled' : "" ?>>
					<option></option>
				<?php foreach ($list_provinsi as $provinsi): ?>
					<option value="<?php echo $provinsi->provinsi_code ?>" <?php echo $provinsi->provinsi_code == $ddk->provinsi_id ? "selected" : "" ?>><?php echo $provinsi->provinsi_code ?> - <?php echo $provinsi->provinsi_name ?></option>
				<?php endforeach ?>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="kabupaten_id" class="col-sm-3 control-label">Kabupaten<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" name="data[kabupaten_id]" class="form-control" id="kabupaten_id" placeholder="kabupaten" <?php echo !empty($this->session->userdata('kabupaten_id')) ? 'readonly' : "" ?>>
			</div>
		</div>
		<div class="form-group">
			<label for="kecamatan_id" class="col-sm-3 control-label">Kecamatan<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" name="data[kecamatan_id]" class="form-control" id="kecamatan_id" placeholder="kecamatan" <?php echo !empty($this->session->userdata('kecamatan_id')) ? 'readonly' : "" ?>>
			</div>
		</div>
		<div class="form-group">
			<label for="desa_id" class="col-sm-3 control-label">Desa<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" name="data[desa_id]" class="form-control" id="desa_id" placeholder="desa" <?php echo !empty($this->session->userdata('desa_id')) ? 'readonly' : "" ?>>
			</div>
		</div>
		<div class="form-group">
			<label for="dusun" class="col-sm-3 control-label">Dusun/Lingkungan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="dusun" name="data[dusun]" placeholder="dusun/lingkungan" value="<?php echo $ddk->dusun ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="rtrw" class="col-sm-3 control-label">RT/RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="rtrw" name="data[rtrw]" placeholder="rt/rw" value="<?php echo $ddk->rtrw ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="tanggal" class="col-sm-3 control-label">Tanggal<span class="text-danger">*</span></label>
			<div class="col-sm-6">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="tanggal" name="data[tanggal]" placeholder="tanggal" value="<?php echo $ddk->tanggal ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="pengisi" class="col-sm-3 control-label">Nama Pengisi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="pengisi" name="data[detail][pengisi]" placeholder="nama pengisi" value="<?php echo $ddk->detail["pengisi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="pekerjaan" class="col-sm-3 control-label">Pekerjaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="pekerjaan" name="data[detail][pekerjaan]" placeholder="pekerjaan" value="<?php echo $ddk->detail["pekerjaan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="jabatan" class="col-sm-3 control-label">Jabatan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="jabatan" name="data[detail][jabatan]" placeholder="jabatan" value="<?php echo $ddk->detail["jabatan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="sumber_data" class="col-sm-3 control-label">Sumber Data Untuk Mengisi Data Dasar Keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="sumber_data" name="data[detail][sumber_data][1]" placeholder="sumber data 1" value="<?php echo $ddk->detail["sumber_data"][1] ?>"><br>
				<input type="text" class="form-control" id="sumber_data" name="data[detail][sumber_data][2]" placeholder="sumber data 2" value="<?php echo $ddk->detail["sumber_data"][2] ?>"><br>
				<input type="text" class="form-control" id="sumber_data" name="data[detail][sumber_data][3]" placeholder="sumber data 3" value="<?php echo $ddk->detail["sumber_data"][3] ?>"><br>
				<input type="text" class="form-control" id="sumber_data" name="data[detail][sumber_data][4]" placeholder="sumber data 4" value="<?php echo $ddk->detail["sumber_data"][4] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h3>1. Data Keluarga</h3>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penghasilan" class="col-sm-3 control-label">Jumlah Penghasilan Perbulan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penghasilan" name="data[detail][keluarga][penghasilan]" placeholder="jumlah penghasilan perbulan" value="<?php echo $ddk->detail["keluarga"]["penghasilan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pengeluaran" class="col-sm-3 control-label">Jumlah Pengeluaran Perbulan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pengeluaran" name="data[detail][keluarga][pengeluaran]" placeholder="jumlah pengeluaran perbulan" value="<?php echo $ddk->detail["keluarga"]["pengeluaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Jumlah Kepemilikan Rumah</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_rumah_sendiri" class="col-sm-3 control-label">Milik Sendiri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_rumah_sendiri" name="data[detail][keluarga][rumah][sendiri]" placeholder="jumlah milik sendiri" value="<?php echo $ddk->detail["keluarga"]["rumah"]["sendiri"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_rumah_ortu" class="col-sm-3 control-label">Milik Orang Tua</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_rumah_ortu" name="data[detail][keluarga][rumah][ortu]" placeholder="jumlah milik orang tua" value="<?php echo $ddk->detail["keluarga"]["rumah"]["ortu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_rumah_keluarga" class="col-sm-3 control-label">Milik Keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_rumah_keluarga" name="data[detail][keluarga][rumah][keluarga]" placeholder="jumlah milik keluarga" value="<?php echo $ddk->detail["keluarga"]["rumah"]["keluarga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_rumah_sewa" class="col-sm-3 control-label">Sewa/Kontrak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_rumah_sewa" name="data[detail][keluarga][rumah][sewa]" placeholder="jumlah sewa/kontrak" value="<?php echo $ddk->detail["keluarga"]["rumah"]["sewa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_rumah_pinjam" class="col-sm-3 control-label">Pinjam Pakai</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_rumah_pinjam" name="data[detail][keluarga][rumah][pinjam]" placeholder="jumlah pinjam pakai" value="<?php echo $ddk->detail["keluarga"]["rumah"]["pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_rumah_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_rumah_lainnya" name="data[detail][keluarga][rumah][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["rumah"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_rumah_lainnya" name="data[detail][keluarga][rumah][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["rumah"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Sumber Air Minum yang digunakan anggota keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_sumber" class="col-sm-3 control-label">Mata air</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][sumber][]" id="keluarga_sumber_air_sumber1" value="baik" <?php echo (array_key_exists("sumber", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["sumber"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][sumber][]" id="keluarga_sumber_air_sumber2" value="berasa" <?php echo (array_key_exists("sumber", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["sumber"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][sumber][]" id="keluarga_sumber_air_sumber3" value="berwarna" <?php echo (array_key_exists("sumber", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["sumber"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][sumber][]" id="keluarga_sumber_air_sumber4" value="berbau" <?php echo (array_key_exists("sumber", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["sumber"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_gali" class="col-sm-3 control-label">Sumur gali</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][gali][]" id="keluarga_sumber_air_gali1" value="baik" <?php echo (array_key_exists("gali", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["gali"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][gali][]" id="keluarga_sumber_air_gali2" value="berasa" <?php echo (array_key_exists("gali", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["gali"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][gali][]" id="keluarga_sumber_air_gali3" value="berwarna" <?php echo (array_key_exists("gali", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["gali"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][gali][]" id="keluarga_sumber_air_gali4" value="berbau" <?php echo (array_key_exists("gali", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["gali"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_pompa" class="col-sm-3 control-label">Sumur pompa</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pompa][]" id="keluarga_sumber_air_pompa1" value="baik" <?php echo (array_key_exists("pompa", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["pompa"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pompa][]" id="keluarga_sumber_air_pompa2" value="berasa" <?php echo (array_key_exists("pompa", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["pompa"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pompa][]" id="keluarga_sumber_air_pompa3" value="berwarna" <?php echo (array_key_exists("pompa", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["pompa"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pompa][]" id="keluarga_sumber_air_pompa4" value="berbau" <?php echo (array_key_exists("pompa", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["pompa"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_hidran" class="col-sm-3 control-label">Hidran umum</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][hidran][]" id="keluarga_sumber_air_hidran1" value="baik" <?php echo (array_key_exists("hidran", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["hidran"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][hidran][]" id="keluarga_sumber_air_hidran2" value="berasa" <?php echo (array_key_exists("hidran", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["hidran"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][hidran][]" id="keluarga_sumber_air_hidran3" value="berwarna" <?php echo (array_key_exists("hidran", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["hidran"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][hidran][]" id="keluarga_sumber_air_hidran4" value="berbau" <?php echo (array_key_exists("hidran", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["hidran"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_pam" class="col-sm-3 control-label">PAM</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pam][]" id="keluarga_sumber_air_pam1" value="baik" <?php echo (array_key_exists("pam", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["pam"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pam][]" id="keluarga_sumber_air_pam2" value="berasa" <?php echo (array_key_exists("pam", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["pam"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pam][]" id="keluarga_sumber_air_pam3" value="berwarna" <?php echo (array_key_exists("pam", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["pam"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pam][]" id="keluarga_sumber_air_pam4" value="berbau" <?php echo (array_key_exists("pam", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["pam"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_pipa" class="col-sm-3 control-label">Pipa</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pipa][]" id="keluarga_sumber_air_pipa1" value="baik" <?php echo (array_key_exists("pipa", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["pipa"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pipa][]" id="keluarga_sumber_air_pipa2" value="berasa" <?php echo (array_key_exists("pipa", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["pipa"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pipa][]" id="keluarga_sumber_air_pipa3" value="berwarna" <?php echo (array_key_exists("pipa", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["pipa"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][pipa][]" id="keluarga_sumber_air_pipa4" value="berbau" <?php echo (array_key_exists("pipa", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["pipa"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_sungai" class="col-sm-3 control-label">Sungai</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][sungai][]" id="keluarga_sumber_air_sungai1" value="baik" <?php echo (array_key_exists("sungai", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["sungai"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][sungai][]" id="keluarga_sumber_air_sungai2" value="berasa" <?php echo (array_key_exists("sungai", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["sungai"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][sungai][]" id="keluarga_sumber_air_sungai3" value="berwarna" <?php echo (array_key_exists("sungai", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["sungai"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][sungai][]" id="keluarga_sumber_air_sungai4" value="berbau" <?php echo (array_key_exists("sungai", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["sungai"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_embung" class="col-sm-3 control-label">Embung</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][embung][]" id="keluarga_sumber_air_embung1" value="baik" <?php echo (array_key_exists("embung", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["embung"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][embung][]" id="keluarga_sumber_air_embung2" value="berasa" <?php echo (array_key_exists("embung", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["embung"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][embung][]" id="keluarga_sumber_air_embung3" value="berwarna" <?php echo (array_key_exists("embung", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["embung"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][embung][]" id="keluarga_sumber_air_embung4" value="berbau" <?php echo (array_key_exists("embung", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["embung"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_penampung" class="col-sm-3 control-label">Bak penampung air hujan</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][penampung][]" id="keluarga_sumber_air_penampung1" value="baik" <?php echo (array_key_exists("penampung", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["penampung"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][penampung][]" id="keluarga_sumber_air_penampung2" value="berasa" <?php echo (array_key_exists("penampung", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["penampung"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][penampung][]" id="keluarga_sumber_air_penampung3" value="berwarna" <?php echo (array_key_exists("penampung", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["penampung"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][penampung][]" id="keluarga_sumber_air_penampung4" value="berbau" <?php echo (array_key_exists("penampung", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["penampung"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_tangki" class="col-sm-3 control-label">Beli dari tangki swasta</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][tangki][]" id="keluarga_sumber_air_tangki1" value="baik" <?php echo (array_key_exists("tangki", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["tangki"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][tangki][]" id="keluarga_sumber_air_tangki2" value="berasa" <?php echo (array_key_exists("tangki", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["tangki"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][tangki][]" id="keluarga_sumber_air_tangki3" value="berwarna" <?php echo (array_key_exists("tangki", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["tangki"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][tangki][]" id="keluarga_sumber_air_tangki4" value="berbau" <?php echo (array_key_exists("tangki", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["tangki"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_depot" class="col-sm-3 control-label">Depot isi ulang</label>
			<div class="col-sm-5">
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][depot][]" id="keluarga_sumber_air_depot1" value="baik" <?php echo (array_key_exists("depot", $ddk->detail["keluarga"]["sumber_air"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["depot"])) ? "checked" : "" ?>>
					<label>Baik</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][depot][]" id="keluarga_sumber_air_depot2" value="berasa" <?php echo (array_key_exists("depot", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["depot"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][depot][]" id="keluarga_sumber_air_depot3" value="berwarna" <?php echo (array_key_exists("depot", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["depot"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][depot][]" id="keluarga_sumber_air_depot4" value="berbau" <?php echo (array_key_exists("depot", $ddk->detail["keluarga"]["sumber_air"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["depot"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_sumber_air_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_sumber_air_lainnya" name="data[detail][keluarga][sumber_air][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["sumber_air"]["lainnya"]["keterangan"] ?>">
				<div class="checkbox checkbox-replace color-blue"><div class="checkbox checkbox-replace color-blue">
				<input type="checkbox" name="data[detail][keluarga][sumber_air][lainnya][opsi][]" id="keluarga_sumber_air_lainnya1" value="baik" <?php echo (array_key_exists("opsi", $ddk->detail["keluarga"]["sumber_air"]["lainnya"]) && in_array("baik", $ddk->detail["keluarga"]["sumber_air"]["lainnya"]["opsi"])) ? "checked" : "" ?>>
			<label>Baik</label>
	</div></div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][lainnya][opsi][]" id="keluarga_sumber_air_lainnya2" value="berasa" <?php echo (array_key_exists("opsi", $ddk->detail["keluarga"]["sumber_air"]["lainnya"]) && in_array("berasa", $ddk->detail["keluarga"]["sumber_air"]["lainnya"]["opsi"])) ? "checked" : "" ?>>
					<label>Berasa</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][lainnya][opsi][]" id="keluarga_sumber_air_lainnya3" value="berwarna" <?php echo (array_key_exists("opsi", $ddk->detail["keluarga"]["sumber_air"]["lainnya"]) && in_array("berwarna", $ddk->detail["keluarga"]["sumber_air"]["lainnya"]["opsi"])) ? "checked" : "" ?>>
					<label>Berwarna</label>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[detail][keluarga][sumber_air][lainnya][opsi][]" id="keluarga_sumber_air_lainnya4" value="berbau" <?php echo (array_key_exists("opsi", $ddk->detail["keluarga"]["sumber_air"]["lainnya"]) && in_array("berbau", $ddk->detail["keluarga"]["sumber_air"]["lainnya"]["opsi"])) ? "checked" : "" ?>>
					<label>Berbau</label>
				</div>
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Kepemilikan Lahan</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lahan_pangan" class="col-sm-3 control-label">Lahan Tanaman Pangan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[detail][keluarga][lahan][pangan]" id="keluarga_lahan_pangan">
					<option value="Tidak memiliki" <?php echo $ddk->detail["keluarga"]["lahan"]["pangan"] == "Tidak memiliki" ? "selected" : ""; ?>>Tidak memiliki</option>
					<option value="Memiliki kurang 0,5 ha" <?php echo $ddk->detail["keluarga"]["lahan"]["pangan"] == "Memiliki kurang 0,5 ha" ? "selected" : ""; ?>>Memiliki kurang 0,5 ha</option>
					<option value="Memiliki 0,5 – 1,0 ha" <?php echo $ddk->detail["keluarga"]["lahan"]["pangan"] == "Memiliki 0,5 – 1,0 ha" ? "selected" : ""; ?>>Memiliki 0,5 – 1,0 ha</option>
					<option value="Memiliki lebih dari 1" <?php echo $ddk->detail["keluarga"]["lahan"]["pangan"] == "Memiliki lebih dari 1" ? "selected" : ""; ?>>Memiliki lebih dari 1</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lahan_kebun" class="col-sm-3 control-label">Lahan Tanaman Perkebunan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[detail][keluarga][lahan][kebun]" id="keluarga_lahan_kebun">
					<option value="Tidak memiliki" <?php echo $ddk->detail["keluarga"]["lahan"]["kebun"] == "Tidak memiliki" ? "selected" : ""; ?>>Tidak memiliki</option>
					<option value="Memiliki kurang 0,5 ha" <?php echo $ddk->detail["keluarga"]["lahan"]["kebun"] == "Memiliki kurang 0,5 ha" ? "selected" : ""; ?>>Memiliki kurang 0,5 ha</option>
					<option value="Memiliki 0,5 – 1,0 ha" <?php echo $ddk->detail["keluarga"]["lahan"]["kebun"] == "Memiliki 0,5 – 1,0 ha" ? "selected" : ""; ?>>Memiliki 0,5 – 1,0 ha</option>
					<option value="Memiliki lebih dari 1" <?php echo $ddk->detail["keluarga"]["lahan"]["kebun"] == "Memiliki lebih dari 1" ? "selected" : ""; ?>>Memiliki lebih dari 1</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lahan_hutan" class="col-sm-3 control-label">Lahan Hutan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[detail][keluarga][lahan][hutan]" id="keluarga_lahan_hutan">
					<option value="Tidak memiliki" <?php echo $ddk->detail["keluarga"]["lahan"]["hutan"] == "Tidak memiliki" ? "selected" : ""; ?>>Tidak memiliki</option>
					<option value="Memiliki kurang 0,5 ha" <?php echo $ddk->detail["keluarga"]["lahan"]["hutan"] == "Memiliki kurang 0,5 ha" ? "selected" : ""; ?>>Memiliki kurang 0,5 ha</option>
					<option value="Memiliki 0,5 – 1,0 ha" <?php echo $ddk->detail["keluarga"]["lahan"]["hutan"] == "Memiliki 0,5 – 1,0 ha" ? "selected" : ""; ?>>Memiliki 0,5 – 1,0 ha</option>
					<option value="Memiliki lebih dari 1" <?php echo $ddk->detail["keluarga"]["lahan"]["hutan"] == "Memiliki lebih dari 1" ? "selected" : ""; ?>>Memiliki lebih dari 1</option>
				</select>
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Produksi Tahun Ini</strong></h4>
				<h4>Tanaman Pangan</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_jagung" class="col-sm-3 control-label">Jagung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_jagung" name="data[detail][keluarga][produksi_pangan][jagung][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["jagung"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_jagung" name="data[detail][keluarga][produksi_pangan][jagung][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["jagung"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_jagung" name="data[detail][keluarga][produksi_pangan][jagung][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["jagung"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_jagung" name="data[detail][keluarga][produksi_pangan][jagung][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["jagung"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_kacang_kedelai" class="col-sm-3 control-label">Kacang kedelai</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_kedelai" name="data[detail][keluarga][produksi_pangan][kacang_kedelai][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_kedelai"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_kedelai" name="data[detail][keluarga][produksi_pangan][kacang_kedelai][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_kedelai"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_kedelai" name="data[detail][keluarga][produksi_pangan][kacang_kedelai][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_kedelai"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_kedelai" name="data[detail][keluarga][produksi_pangan][kacang_kedelai][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_kedelai"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_kacang_tanah" class="col-sm-3 control-label">Kacang tanah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_tanah" name="data[detail][keluarga][produksi_pangan][kacang_tanah][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_tanah"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_tanah" name="data[detail][keluarga][produksi_pangan][kacang_tanah][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_tanah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_tanah" name="data[detail][keluarga][produksi_pangan][kacang_tanah][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_tanah"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_tanah" name="data[detail][keluarga][produksi_pangan][kacang_tanah][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_tanah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_kacang_panjang" class="col-sm-3 control-label">Kacang panjang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_panjang" name="data[detail][keluarga][produksi_pangan][kacang_panjang][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_panjang"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_panjang" name="data[detail][keluarga][produksi_pangan][kacang_panjang][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_panjang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_panjang" name="data[detail][keluarga][produksi_pangan][kacang_panjang][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_panjang"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_panjang" name="data[detail][keluarga][produksi_pangan][kacang_panjang][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_panjang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_kacang_mede" class="col-sm-3 control-label">Kacang mede</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_mede" name="data[detail][keluarga][produksi_pangan][kacang_mede][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_mede"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_mede" name="data[detail][keluarga][produksi_pangan][kacang_mede][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_mede"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_mede" name="data[detail][keluarga][produksi_pangan][kacang_mede][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_mede"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_mede" name="data[detail][keluarga][produksi_pangan][kacang_mede][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_mede"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_kacang_merah" class="col-sm-3 control-label">Kacang merah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_merah" name="data[detail][keluarga][produksi_pangan][kacang_merah][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_merah"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_merah" name="data[detail][keluarga][produksi_pangan][kacang_merah][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_merah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_merah" name="data[detail][keluarga][produksi_pangan][kacang_merah][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_merah"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_merah" name="data[detail][keluarga][produksi_pangan][kacang_merah][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_merah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_padi_sawah" class="col-sm-3 control-label">Padi sawah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_padi_sawah" name="data[detail][keluarga][produksi_pangan][padi_sawah][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["padi_sawah"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_padi_sawah" name="data[detail][keluarga][produksi_pangan][padi_sawah][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["padi_sawah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_padi_sawah" name="data[detail][keluarga][produksi_pangan][padi_sawah][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["padi_sawah"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_padi_sawah" name="data[detail][keluarga][produksi_pangan][padi_sawah][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["padi_sawah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_padi_ladang" class="col-sm-3 control-label">Padi ladang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_padi_ladang" name="data[detail][keluarga][produksi_pangan][padi_ladang][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["padi_ladang"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_padi_ladang" name="data[detail][keluarga][produksi_pangan][padi_ladang][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["padi_ladang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_padi_ladang" name="data[detail][keluarga][produksi_pangan][padi_ladang][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["padi_ladang"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_padi_ladang" name="data[detail][keluarga][produksi_pangan][padi_ladang][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["padi_ladang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_ubi_kayu" class="col-sm-3 control-label">Ubi kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_ubi_kayu" name="data[detail][keluarga][produksi_pangan][ubi_kayu][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["ubi_kayu"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_ubi_kayu" name="data[detail][keluarga][produksi_pangan][ubi_kayu][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["ubi_kayu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_ubi_kayu" name="data[detail][keluarga][produksi_pangan][ubi_kayu][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["ubi_kayu"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_ubi_kayu" name="data[detail][keluarga][produksi_pangan][ubi_kayu][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["ubi_kayu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_ubi_jalar" class="col-sm-3 control-label">Ubi jalar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_ubi_jalar" name="data[detail][keluarga][produksi_pangan][ubi_jalar][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["ubi_jalar"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_ubi_jalar" name="data[detail][keluarga][produksi_pangan][ubi_jalar][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["ubi_jalar"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_ubi_jalar" name="data[detail][keluarga][produksi_pangan][ubi_jalar][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["ubi_jalar"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_ubi_jalar" name="data[detail][keluarga][produksi_pangan][ubi_jalar][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["ubi_jalar"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_cabe" class="col-sm-3 control-label">Cabe</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_cabe" name="data[detail][keluarga][produksi_pangan][cabe][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["cabe"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_cabe" name="data[detail][keluarga][produksi_pangan][cabe][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["cabe"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_cabe" name="data[detail][keluarga][produksi_pangan][cabe][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["cabe"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_cabe" name="data[detail][keluarga][produksi_pangan][cabe][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["cabe"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_bawah_merah" class="col-sm-3 control-label">Bawah merah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bawah_merah" name="data[detail][keluarga][produksi_pangan][bawah_merah][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bawah_merah"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bawah_merah" name="data[detail][keluarga][produksi_pangan][bawah_merah][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bawah_merah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bawah_merah" name="data[detail][keluarga][produksi_pangan][bawah_merah][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bawah_merah"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bawah_merah" name="data[detail][keluarga][produksi_pangan][bawah_merah][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bawah_merah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_bawang_putih" class="col-sm-3 control-label">Bawang putih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bawang_putih" name="data[detail][keluarga][produksi_pangan][bawang_putih][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bawang_putih"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bawang_putih" name="data[detail][keluarga][produksi_pangan][bawang_putih][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bawang_putih"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bawang_putih" name="data[detail][keluarga][produksi_pangan][bawang_putih][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bawang_putih"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bawang_putih" name="data[detail][keluarga][produksi_pangan][bawang_putih][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bawang_putih"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_tomat" class="col-sm-3 control-label">Tomat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_tomat" name="data[detail][keluarga][produksi_pangan][tomat][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["tomat"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_tomat" name="data[detail][keluarga][produksi_pangan][tomat][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["tomat"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_tomat" name="data[detail][keluarga][produksi_pangan][tomat][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["tomat"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_tomat" name="data[detail][keluarga][produksi_pangan][tomat][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["tomat"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_sawi" class="col-sm-3 control-label">Sawi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_sawi" name="data[detail][keluarga][produksi_pangan][sawi][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["sawi"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_sawi" name="data[detail][keluarga][produksi_pangan][sawi][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["sawi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_sawi" name="data[detail][keluarga][produksi_pangan][sawi][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["sawi"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_sawi" name="data[detail][keluarga][produksi_pangan][sawi][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["sawi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_kentang" class="col-sm-3 control-label">Kentang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kentang" name="data[detail][keluarga][produksi_pangan][kentang][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kentang"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kentang" name="data[detail][keluarga][produksi_pangan][kentang][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kentang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kentang" name="data[detail][keluarga][produksi_pangan][kentang][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kentang"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kentang" name="data[detail][keluarga][produksi_pangan][kentang][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kentang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_kubis" class="col-sm-3 control-label">Kubis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kubis" name="data[detail][keluarga][produksi_pangan][kubis][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kubis"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kubis" name="data[detail][keluarga][produksi_pangan][kubis][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kubis"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kubis" name="data[detail][keluarga][produksi_pangan][kubis][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kubis"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kubis" name="data[detail][keluarga][produksi_pangan][kubis][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kubis"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_mentimun" class="col-sm-3 control-label">Mentimun</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_mentimun" name="data[detail][keluarga][produksi_pangan][mentimun][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["mentimun"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_mentimun" name="data[detail][keluarga][produksi_pangan][mentimun][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["mentimun"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_mentimun" name="data[detail][keluarga][produksi_pangan][mentimun][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["mentimun"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_mentimun" name="data[detail][keluarga][produksi_pangan][mentimun][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["mentimun"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_buncis" class="col-sm-3 control-label">Buncis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_buncis" name="data[detail][keluarga][produksi_pangan][buncis][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["buncis"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_buncis" name="data[detail][keluarga][produksi_pangan][buncis][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["buncis"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_buncis" name="data[detail][keluarga][produksi_pangan][buncis][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["buncis"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_buncis" name="data[detail][keluarga][produksi_pangan][buncis][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["buncis"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_brocoli" class="col-sm-3 control-label">Brocoli</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_brocoli" name="data[detail][keluarga][produksi_pangan][brocoli][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["brocoli"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_brocoli" name="data[detail][keluarga][produksi_pangan][brocoli][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["brocoli"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_brocoli" name="data[detail][keluarga][produksi_pangan][brocoli][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["brocoli"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_brocoli" name="data[detail][keluarga][produksi_pangan][brocoli][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["brocoli"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_terong" class="col-sm-3 control-label">Terong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_terong" name="data[detail][keluarga][produksi_pangan][terong][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["terong"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_terong" name="data[detail][keluarga][produksi_pangan][terong][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["terong"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_terong" name="data[detail][keluarga][produksi_pangan][terong][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["terong"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_terong" name="data[detail][keluarga][produksi_pangan][terong][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["terong"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_bayam" class="col-sm-3 control-label">Bayam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bayam" name="data[detail][keluarga][produksi_pangan][bayam][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bayam"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bayam" name="data[detail][keluarga][produksi_pangan][bayam][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bayam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bayam" name="data[detail][keluarga][produksi_pangan][bayam][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bayam"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_bayam" name="data[detail][keluarga][produksi_pangan][bayam][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["bayam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_kangkung" class="col-sm-3 control-label">Kangkung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kangkung" name="data[detail][keluarga][produksi_pangan][kangkung][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kangkung"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kangkung" name="data[detail][keluarga][produksi_pangan][kangkung][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kangkung"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kangkung" name="data[detail][keluarga][produksi_pangan][kangkung][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kangkung"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kangkung" name="data[detail][keluarga][produksi_pangan][kangkung][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kangkung"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_kacang_turis" class="col-sm-3 control-label">Kacang turis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_turis" name="data[detail][keluarga][produksi_pangan][kacang_turis][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_turis"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_turis" name="data[detail][keluarga][produksi_pangan][kacang_turis][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_turis"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_turis" name="data[detail][keluarga][produksi_pangan][kacang_turis][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_turis"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_kacang_turis" name="data[detail][keluarga][produksi_pangan][kacang_turis][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["kacang_turis"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_umbi_lain" class="col-sm-3 control-label">Umbi-umbian lain</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_umbi_lain" name="data[detail][keluarga][produksi_pangan][umbi_lain][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["umbi_lain"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_umbi_lain" name="data[detail][keluarga][produksi_pangan][umbi_lain][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["umbi_lain"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_umbi_lain" name="data[detail][keluarga][produksi_pangan][umbi_lain][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["umbi_lain"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_umbi_lain" name="data[detail][keluarga][produksi_pangan][umbi_lain][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["umbi_lain"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_selada" class="col-sm-3 control-label">Selada</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_selada" name="data[detail][keluarga][produksi_pangan][selada][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["selada"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_selada" name="data[detail][keluarga][produksi_pangan][selada][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["selada"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_selada" name="data[detail][keluarga][produksi_pangan][selada][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["selada"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_selada" name="data[detail][keluarga][produksi_pangan][selada][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["selada"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_talas" class="col-sm-3 control-label">Talas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_talas" name="data[detail][keluarga][produksi_pangan][talas][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["talas"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_talas" name="data[detail][keluarga][produksi_pangan][talas][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["talas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_talas" name="data[detail][keluarga][produksi_pangan][talas][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["talas"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_talas" name="data[detail][keluarga][produksi_pangan][talas][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["talas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_wortel" class="col-sm-3 control-label">Wortel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_wortel" name="data[detail][keluarga][produksi_pangan][wortel][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["wortel"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_wortel" name="data[detail][keluarga][produksi_pangan][wortel][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["wortel"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_wortel" name="data[detail][keluarga][produksi_pangan][wortel][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["wortel"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_wortel" name="data[detail][keluarga][produksi_pangan][wortel][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["wortel"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_pangan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_pangan_lainnya" name="data[detail][keluarga][produksi_pangan][lainnya][keterangan]" placeholder="tanaman pangan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_lainnya" name="data[detail][keluarga][produksi_pangan][lainnya][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["lainnya"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_lainnya" name="data[detail][keluarga][produksi_pangan][lainnya][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["lainnya"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_lainnya" name="data[detail][keluarga][produksi_pangan][lainnya][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["lainnya"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_pangan_lainnya" name="data[detail][keluarga][produksi_pangan][lainnya][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_pangan"]["lainnya"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4>Buah-Buahan</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_jeruk" class="col-sm-3 control-label">Jeruk</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_jeruk" name="data[detail][keluarga][produksi_buah][jeruk][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jeruk"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jeruk" name="data[detail][keluarga][produksi_buah][jeruk][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jeruk"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jeruk" name="data[detail][keluarga][produksi_buah][jeruk][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jeruk"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jeruk" name="data[detail][keluarga][produksi_buah][jeruk][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jeruk"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jeruk" name="data[detail][keluarga][produksi_buah][jeruk][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jeruk"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_alpokat" class="col-sm-3 control-label">Alpokat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_alpokat" name="data[detail][keluarga][produksi_buah][alpokat][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["alpokat"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_alpokat" name="data[detail][keluarga][produksi_buah][alpokat][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["alpokat"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_alpokat" name="data[detail][keluarga][produksi_buah][alpokat][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["alpokat"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_alpokat" name="data[detail][keluarga][produksi_buah][alpokat][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["alpokat"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_alpokat" name="data[detail][keluarga][produksi_buah][alpokat][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["alpokat"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_mangga" class="col-sm-3 control-label">Mangga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_mangga" name="data[detail][keluarga][produksi_buah][mangga][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["mangga"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_mangga" name="data[detail][keluarga][produksi_buah][mangga][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["mangga"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_mangga" name="data[detail][keluarga][produksi_buah][mangga][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["mangga"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_mangga" name="data[detail][keluarga][produksi_buah][mangga][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["mangga"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_mangga" name="data[detail][keluarga][produksi_buah][mangga][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["mangga"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_rambutan" class="col-sm-3 control-label">Rambutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_rambutan" name="data[detail][keluarga][produksi_buah][rambutan][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["rambutan"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_rambutan" name="data[detail][keluarga][produksi_buah][rambutan][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["rambutan"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_rambutan" name="data[detail][keluarga][produksi_buah][rambutan][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["rambutan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_rambutan" name="data[detail][keluarga][produksi_buah][rambutan][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["rambutan"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_rambutan" name="data[detail][keluarga][produksi_buah][rambutan][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["rambutan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_manggis" class="col-sm-3 control-label">Manggis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_manggis" name="data[detail][keluarga][produksi_buah][manggis][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["manggis"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_manggis" name="data[detail][keluarga][produksi_buah][manggis][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["manggis"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_manggis" name="data[detail][keluarga][produksi_buah][manggis][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["manggis"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_manggis" name="data[detail][keluarga][produksi_buah][manggis][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["manggis"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_manggis" name="data[detail][keluarga][produksi_buah][manggis][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["manggis"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_salak" class="col-sm-3 control-label">Salak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_salak" name="data[detail][keluarga][produksi_buah][salak][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["salak"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_salak" name="data[detail][keluarga][produksi_buah][salak][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["salak"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_salak" name="data[detail][keluarga][produksi_buah][salak][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["salak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_salak" name="data[detail][keluarga][produksi_buah][salak][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["salak"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_salak" name="data[detail][keluarga][produksi_buah][salak][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["salak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_apel" class="col-sm-3 control-label">Apel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_apel" name="data[detail][keluarga][produksi_buah][apel][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["apel"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_apel" name="data[detail][keluarga][produksi_buah][apel][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["apel"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_apel" name="data[detail][keluarga][produksi_buah][apel][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["apel"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_apel" name="data[detail][keluarga][produksi_buah][apel][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["apel"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_apel" name="data[detail][keluarga][produksi_buah][apel][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["apel"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_pepaya" class="col-sm-3 control-label">Pepaya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_pepaya" name="data[detail][keluarga][produksi_buah][pepaya][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["pepaya"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_pepaya" name="data[detail][keluarga][produksi_buah][pepaya][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["pepaya"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_pepaya" name="data[detail][keluarga][produksi_buah][pepaya][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["pepaya"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_pepaya" name="data[detail][keluarga][produksi_buah][pepaya][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["pepaya"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_pepaya" name="data[detail][keluarga][produksi_buah][pepaya][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["pepaya"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_belimbing" class="col-sm-3 control-label">Belimbing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_belimbing" name="data[detail][keluarga][produksi_buah][belimbing][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["belimbing"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_belimbing" name="data[detail][keluarga][produksi_buah][belimbing][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["belimbing"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_belimbing" name="data[detail][keluarga][produksi_buah][belimbing][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["belimbing"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_belimbing" name="data[detail][keluarga][produksi_buah][belimbing][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["belimbing"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_belimbing" name="data[detail][keluarga][produksi_buah][belimbing][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["belimbing"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_durian" class="col-sm-3 control-label">Durian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_durian" name="data[detail][keluarga][produksi_buah][durian][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["durian"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_durian" name="data[detail][keluarga][produksi_buah][durian][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["durian"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_durian" name="data[detail][keluarga][produksi_buah][durian][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["durian"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_durian" name="data[detail][keluarga][produksi_buah][durian][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["durian"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_durian" name="data[detail][keluarga][produksi_buah][durian][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["durian"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_sawo" class="col-sm-3 control-label">Sawo</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_sawo" name="data[detail][keluarga][produksi_buah][sawo][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["sawo"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_sawo" name="data[detail][keluarga][produksi_buah][sawo][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["sawo"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_sawo" name="data[detail][keluarga][produksi_buah][sawo][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["sawo"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_sawo" name="data[detail][keluarga][produksi_buah][sawo][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["sawo"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_sawo" name="data[detail][keluarga][produksi_buah][sawo][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["sawo"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_duku" class="col-sm-3 control-label">Duku</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_duku" name="data[detail][keluarga][produksi_buah][duku][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["duku"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_duku" name="data[detail][keluarga][produksi_buah][duku][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["duku"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_duku" name="data[detail][keluarga][produksi_buah][duku][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["duku"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_duku" name="data[detail][keluarga][produksi_buah][duku][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["duku"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_duku" name="data[detail][keluarga][produksi_buah][duku][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["duku"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_kokosan" class="col-sm-3 control-label">Kokosan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_kokosan" name="data[detail][keluarga][produksi_buah][kokosan][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kokosan"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kokosan" name="data[detail][keluarga][produksi_buah][kokosan][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kokosan"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kokosan" name="data[detail][keluarga][produksi_buah][kokosan][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kokosan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kokosan" name="data[detail][keluarga][produksi_buah][kokosan][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kokosan"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kokosan" name="data[detail][keluarga][produksi_buah][kokosan][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kokosan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_pisang" class="col-sm-3 control-label">Pisang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_pisang" name="data[detail][keluarga][produksi_buah][pisang][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["pisang"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_pisang" name="data[detail][keluarga][produksi_buah][pisang][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["pisang"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_pisang" name="data[detail][keluarga][produksi_buah][pisang][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["pisang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_pisang" name="data[detail][keluarga][produksi_buah][pisang][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["pisang"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_pisang" name="data[detail][keluarga][produksi_buah][pisang][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["pisang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_markisa" class="col-sm-3 control-label">Markisa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_markisa" name="data[detail][keluarga][produksi_buah][markisa][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["markisa"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_markisa" name="data[detail][keluarga][produksi_buah][markisa][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["markisa"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_markisa" name="data[detail][keluarga][produksi_buah][markisa][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["markisa"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_markisa" name="data[detail][keluarga][produksi_buah][markisa][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["markisa"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_markisa" name="data[detail][keluarga][produksi_buah][markisa][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["markisa"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_lengkeng" class="col-sm-3 control-label">Lengkeng</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_lengkeng" name="data[detail][keluarga][produksi_buah][lengkeng][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lengkeng"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_lengkeng" name="data[detail][keluarga][produksi_buah][lengkeng][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lengkeng"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_lengkeng" name="data[detail][keluarga][produksi_buah][lengkeng][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lengkeng"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_lengkeng" name="data[detail][keluarga][produksi_buah][lengkeng][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lengkeng"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_lengkeng" name="data[detail][keluarga][produksi_buah][lengkeng][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lengkeng"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_semangka" class="col-sm-3 control-label">Semangka</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_semangka" name="data[detail][keluarga][produksi_buah][semangka][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["semangka"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_semangka" name="data[detail][keluarga][produksi_buah][semangka][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["semangka"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_semangka" name="data[detail][keluarga][produksi_buah][semangka][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["semangka"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_semangka" name="data[detail][keluarga][produksi_buah][semangka][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["semangka"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_semangka" name="data[detail][keluarga][produksi_buah][semangka][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["semangka"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_limau" class="col-sm-3 control-label">Limau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_limau" name="data[detail][keluarga][produksi_buah][limau][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["limau"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_limau" name="data[detail][keluarga][produksi_buah][limau][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["limau"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_limau" name="data[detail][keluarga][produksi_buah][limau][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["limau"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_limau" name="data[detail][keluarga][produksi_buah][limau][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["limau"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_limau" name="data[detail][keluarga][produksi_buah][limau][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["limau"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_jeruk_nipis" class="col-sm-3 control-label">Jeruk nipis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_jeruk_nipis" name="data[detail][keluarga][produksi_buah][jeruk_nipis][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jeruk_nipis"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jeruk_nipis" name="data[detail][keluarga][produksi_buah][jeruk_nipis][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jeruk_nipis"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jeruk_nipis" name="data[detail][keluarga][produksi_buah][jeruk_nipis][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jeruk_nipis"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jeruk_nipis" name="data[detail][keluarga][produksi_buah][jeruk_nipis][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jeruk_nipis"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jeruk_nipis" name="data[detail][keluarga][produksi_buah][jeruk_nipis][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jeruk_nipis"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_sirsak" class="col-sm-3 control-label">Sirsak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_sirsak" name="data[detail][keluarga][produksi_buah][sirsak][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["sirsak"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_sirsak" name="data[detail][keluarga][produksi_buah][sirsak][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["sirsak"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_sirsak" name="data[detail][keluarga][produksi_buah][sirsak][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["sirsak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_sirsak" name="data[detail][keluarga][produksi_buah][sirsak][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["sirsak"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_sirsak" name="data[detail][keluarga][produksi_buah][sirsak][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["sirsak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_melon" class="col-sm-3 control-label">Melon</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_melon" name="data[detail][keluarga][produksi_buah][melon][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["melon"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_melon" name="data[detail][keluarga][produksi_buah][melon][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["melon"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_melon" name="data[detail][keluarga][produksi_buah][melon][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["melon"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_melon" name="data[detail][keluarga][produksi_buah][melon][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["melon"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_melon" name="data[detail][keluarga][produksi_buah][melon][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["melon"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_jambu_air" class="col-sm-3 control-label">Jambu air</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_jambu_air" name="data[detail][keluarga][produksi_buah][jambu_air][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jambu_air"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jambu_air" name="data[detail][keluarga][produksi_buah][jambu_air][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jambu_air"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jambu_air" name="data[detail][keluarga][produksi_buah][jambu_air][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jambu_air"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jambu_air" name="data[detail][keluarga][produksi_buah][jambu_air][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jambu_air"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jambu_air" name="data[detail][keluarga][produksi_buah][jambu_air][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jambu_air"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_nangka" class="col-sm-3 control-label">Nangka</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_nangka" name="data[detail][keluarga][produksi_buah][nangka][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["nangka"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_nangka" name="data[detail][keluarga][produksi_buah][nangka][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["nangka"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_nangka" name="data[detail][keluarga][produksi_buah][nangka][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["nangka"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_nangka" name="data[detail][keluarga][produksi_buah][nangka][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["nangka"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_nangka" name="data[detail][keluarga][produksi_buah][nangka][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["nangka"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_kelapa" class="col-sm-3 control-label">Kelapa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_kelapa" name="data[detail][keluarga][produksi_buah][kelapa][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kelapa"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kelapa" name="data[detail][keluarga][produksi_buah][kelapa][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kelapa"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kelapa" name="data[detail][keluarga][produksi_buah][kelapa][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kelapa"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kelapa" name="data[detail][keluarga][produksi_buah][kelapa][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kelapa"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kelapa" name="data[detail][keluarga][produksi_buah][kelapa][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kelapa"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_kedondong" class="col-sm-3 control-label">Kedondong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_kedondong" name="data[detail][keluarga][produksi_buah][kedondong][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kedondong"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kedondong" name="data[detail][keluarga][produksi_buah][kedondong][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kedondong"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kedondong" name="data[detail][keluarga][produksi_buah][kedondong][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kedondong"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kedondong" name="data[detail][keluarga][produksi_buah][kedondong][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kedondong"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_kedondong" name="data[detail][keluarga][produksi_buah][kedondong][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["kedondong"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_anggur" class="col-sm-3 control-label">Anggur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_anggur" name="data[detail][keluarga][produksi_buah][anggur][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["anggur"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_anggur" name="data[detail][keluarga][produksi_buah][anggur][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["anggur"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_anggur" name="data[detail][keluarga][produksi_buah][anggur][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["anggur"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_anggur" name="data[detail][keluarga][produksi_buah][anggur][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["anggur"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_anggur" name="data[detail][keluarga][produksi_buah][anggur][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["anggur"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_nenas" class="col-sm-3 control-label">Nenas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_nenas" name="data[detail][keluarga][produksi_buah][nenas][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["nenas"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_nenas" name="data[detail][keluarga][produksi_buah][nenas][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["nenas"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_nenas" name="data[detail][keluarga][produksi_buah][nenas][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["nenas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_nenas" name="data[detail][keluarga][produksi_buah][nenas][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["nenas"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_nenas" name="data[detail][keluarga][produksi_buah][nenas][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["nenas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_jambu_klutuk" class="col-sm-3 control-label">Jambu klutuk</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_jambu_klutuk" name="data[detail][keluarga][produksi_buah][jambu_klutuk][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jambu_klutuk"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jambu_klutuk" name="data[detail][keluarga][produksi_buah][jambu_klutuk][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jambu_klutuk"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jambu_klutuk" name="data[detail][keluarga][produksi_buah][jambu_klutuk][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jambu_klutuk"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jambu_klutuk" name="data[detail][keluarga][produksi_buah][jambu_klutuk][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jambu_klutuk"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_jambu_klutuk" name="data[detail][keluarga][produksi_buah][jambu_klutuk][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["jambu_klutuk"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_murbei" class="col-sm-3 control-label">Murbei</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_murbei" name="data[detail][keluarga][produksi_buah][murbei][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["murbei"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_murbei" name="data[detail][keluarga][produksi_buah][murbei][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["murbei"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_murbei" name="data[detail][keluarga][produksi_buah][murbei][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["murbei"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_murbei" name="data[detail][keluarga][produksi_buah][murbei][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["murbei"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_murbei" name="data[detail][keluarga][produksi_buah][murbei][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["murbei"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_buah_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_buah_lainnya" name="data[detail][keluarga][produksi_buah][lainnya][keterangan]" placeholder="tanaman buah" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_lainnya" name="data[detail][keluarga][produksi_buah][lainnya][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lainnya"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_lainnya" name="data[detail][keluarga][produksi_buah][lainnya][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lainnya"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_lainnya" name="data[detail][keluarga][produksi_buah][lainnya][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lainnya"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_lainnya" name="data[detail][keluarga][produksi_buah][lainnya][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lainnya"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_buah_lainnya" name="data[detail][keluarga][produksi_buah][lainnya][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_buah"]["lainnya"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4>Tanaman Obat</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_jahe" class="col-sm-3 control-label">Jahe</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_jahe" name="data[detail][keluarga][produksi_obat][jahe][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["jahe"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_jahe" name="data[detail][keluarga][produksi_obat][jahe][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["jahe"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_jahe" name="data[detail][keluarga][produksi_obat][jahe][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["jahe"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_jahe" name="data[detail][keluarga][produksi_obat][jahe][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["jahe"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_kunyit" class="col-sm-3 control-label">Kunyit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_kunyit" name="data[detail][keluarga][produksi_obat][kunyit][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kunyit"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kunyit" name="data[detail][keluarga][produksi_obat][kunyit][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kunyit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kunyit" name="data[detail][keluarga][produksi_obat][kunyit][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kunyit"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kunyit" name="data[detail][keluarga][produksi_obat][kunyit][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kunyit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_lengkuas" class="col-sm-3 control-label">Lengkuas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_lengkuas" name="data[detail][keluarga][produksi_obat][lengkuas][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["lengkuas"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_lengkuas" name="data[detail][keluarga][produksi_obat][lengkuas][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["lengkuas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_lengkuas" name="data[detail][keluarga][produksi_obat][lengkuas][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["lengkuas"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_lengkuas" name="data[detail][keluarga][produksi_obat][lengkuas][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["lengkuas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_mengkudu" class="col-sm-3 control-label">Mengkudu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_mengkudu" name="data[detail][keluarga][produksi_obat][mengkudu][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["mengkudu"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_mengkudu" name="data[detail][keluarga][produksi_obat][mengkudu][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["mengkudu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_mengkudu" name="data[detail][keluarga][produksi_obat][mengkudu][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["mengkudu"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_mengkudu" name="data[detail][keluarga][produksi_obat][mengkudu][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["mengkudu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_daun_dewa" class="col-sm-3 control-label">Daun dewa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_dewa" name="data[detail][keluarga][produksi_obat][daun_dewa][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_dewa"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_dewa" name="data[detail][keluarga][produksi_obat][daun_dewa][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_dewa"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_dewa" name="data[detail][keluarga][produksi_obat][daun_dewa][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_dewa"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_dewa" name="data[detail][keluarga][produksi_obat][daun_dewa][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_dewa"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_kumis_kucing" class="col-sm-3 control-label">Kumis kucing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_kumis_kucing" name="data[detail][keluarga][produksi_obat][kumis_kucing][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kumis_kucing"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kumis_kucing" name="data[detail][keluarga][produksi_obat][kumis_kucing][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kumis_kucing"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kumis_kucing" name="data[detail][keluarga][produksi_obat][kumis_kucing][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kumis_kucing"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kumis_kucing" name="data[detail][keluarga][produksi_obat][kumis_kucing][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kumis_kucing"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_buah_merah" class="col-sm-3 control-label">Buah Merah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_buah_merah" name="data[detail][keluarga][produksi_obat][buah_merah][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["buah_merah"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_buah_merah" name="data[detail][keluarga][produksi_obat][buah_merah][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["buah_merah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_buah_merah" name="data[detail][keluarga][produksi_obat][buah_merah][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["buah_merah"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_buah_merah" name="data[detail][keluarga][produksi_obat][buah_merah][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["buah_merah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_sambiloto" class="col-sm-3 control-label">Sambiloto</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_sambiloto" name="data[detail][keluarga][produksi_obat][sambiloto][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["sambiloto"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_sambiloto" name="data[detail][keluarga][produksi_obat][sambiloto][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["sambiloto"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_sambiloto" name="data[detail][keluarga][produksi_obat][sambiloto][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["sambiloto"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_sambiloto" name="data[detail][keluarga][produksi_obat][sambiloto][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["sambiloto"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_temulawak" class="col-sm-3 control-label">Temulawak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_temulawak" name="data[detail][keluarga][produksi_obat][temulawak][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temulawak"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temulawak" name="data[detail][keluarga][produksi_obat][temulawak][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temulawak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temulawak" name="data[detail][keluarga][produksi_obat][temulawak][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temulawak"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temulawak" name="data[detail][keluarga][produksi_obat][temulawak][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temulawak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_temu_hitam" class="col-sm-3 control-label">Temu hitam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_hitam" name="data[detail][keluarga][produksi_obat][temu_hitam][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_hitam"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_hitam" name="data[detail][keluarga][produksi_obat][temu_hitam][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_hitam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_hitam" name="data[detail][keluarga][produksi_obat][temu_hitam][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_hitam"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_hitam" name="data[detail][keluarga][produksi_obat][temu_hitam][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_hitam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_temu_putih" class="col-sm-3 control-label">Temu putih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_putih" name="data[detail][keluarga][produksi_obat][temu_putih][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_putih"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_putih" name="data[detail][keluarga][produksi_obat][temu_putih][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_putih"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_putih" name="data[detail][keluarga][produksi_obat][temu_putih][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_putih"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_putih" name="data[detail][keluarga][produksi_obat][temu_putih][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_putih"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_temu_putri" class="col-sm-3 control-label">Temu putri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_putri" name="data[detail][keluarga][produksi_obat][temu_putri][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_putri"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_putri" name="data[detail][keluarga][produksi_obat][temu_putri][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_putri"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_putri" name="data[detail][keluarga][produksi_obat][temu_putri][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_putri"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_putri" name="data[detail][keluarga][produksi_obat][temu_putri][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_putri"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_temu_kunci" class="col-sm-3 control-label">Temu kunci</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_kunci" name="data[detail][keluarga][produksi_obat][temu_kunci][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_kunci"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_kunci" name="data[detail][keluarga][produksi_obat][temu_kunci][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_kunci"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_kunci" name="data[detail][keluarga][produksi_obat][temu_kunci][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_kunci"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_temu_kunci" name="data[detail][keluarga][produksi_obat][temu_kunci][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["temu_kunci"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_daun_sirih" class="col-sm-3 control-label">Daun sirih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_sirih" name="data[detail][keluarga][produksi_obat][daun_sirih][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_sirih"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_sirih" name="data[detail][keluarga][produksi_obat][daun_sirih][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_sirih"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_sirih" name="data[detail][keluarga][produksi_obat][daun_sirih][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_sirih"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_sirih" name="data[detail][keluarga][produksi_obat][daun_sirih][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_sirih"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_kayu_manis" class="col-sm-3 control-label">Kayu manis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_kayu_manis" name="data[detail][keluarga][produksi_obat][kayu_manis][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kayu_manis"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kayu_manis" name="data[detail][keluarga][produksi_obat][kayu_manis][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kayu_manis"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kayu_manis" name="data[detail][keluarga][produksi_obat][kayu_manis][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kayu_manis"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kayu_manis" name="data[detail][keluarga][produksi_obat][kayu_manis][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kayu_manis"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_daun_sereh" class="col-sm-3 control-label">Daun sereh</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_sereh" name="data[detail][keluarga][produksi_obat][daun_sereh][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_sereh"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_sereh" name="data[detail][keluarga][produksi_obat][daun_sereh][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_sereh"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_sereh" name="data[detail][keluarga][produksi_obat][daun_sereh][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_sereh"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_daun_sereh" name="data[detail][keluarga][produksi_obat][daun_sereh][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["daun_sereh"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_mahkota_dewa" class="col-sm-3 control-label">Mahkota dewa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_mahkota_dewa" name="data[detail][keluarga][produksi_obat][mahkota_dewa][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["mahkota_dewa"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_mahkota_dewa" name="data[detail][keluarga][produksi_obat][mahkota_dewa][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["mahkota_dewa"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_mahkota_dewa" name="data[detail][keluarga][produksi_obat][mahkota_dewa][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["mahkota_dewa"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_mahkota_dewa" name="data[detail][keluarga][produksi_obat][mahkota_dewa][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["mahkota_dewa"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_akar_wangi" class="col-sm-3 control-label">Akar wangi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_akar_wangi" name="data[detail][keluarga][produksi_obat][akar_wangi][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["akar_wangi"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_akar_wangi" name="data[detail][keluarga][produksi_obat][akar_wangi][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["akar_wangi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_akar_wangi" name="data[detail][keluarga][produksi_obat][akar_wangi][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["akar_wangi"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_akar_wangi" name="data[detail][keluarga][produksi_obat][akar_wangi][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["akar_wangi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_kencur" class="col-sm-3 control-label">Kencur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_kencur" name="data[detail][keluarga][produksi_obat][kencur][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kencur"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kencur" name="data[detail][keluarga][produksi_obat][kencur][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kencur"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kencur" name="data[detail][keluarga][produksi_obat][kencur][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kencur"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_kencur" name="data[detail][keluarga][produksi_obat][kencur][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["kencur"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_jamur" class="col-sm-3 control-label">Jamur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_jamur" name="data[detail][keluarga][produksi_obat][jamur][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["jamur"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_jamur" name="data[detail][keluarga][produksi_obat][jamur][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["jamur"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_jamur" name="data[detail][keluarga][produksi_obat][jamur][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["jamur"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_jamur" name="data[detail][keluarga][produksi_obat][jamur][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["jamur"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_obat_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_obat_lainnya" name="data[detail][keluarga][produksi_obat][lainnya][keterangan]" placeholder="tanaman obat" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_lainnya" name="data[detail][keluarga][produksi_obat][lainnya][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["lainnya"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_lainnya" name="data[detail][keluarga][produksi_obat][lainnya][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["lainnya"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_lainnya" name="data[detail][keluarga][produksi_obat][lainnya][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["lainnya"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_obat_lainnya" name="data[detail][keluarga][produksi_obat][lainnya][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_obat"]["lainnya"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4>Tanaman Perkebunan</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_kelapa" class="col-sm-3 control-label">Kelapa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kelapa" name="data[detail][keluarga][produksi_perkebunan][kelapa][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kelapa"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kelapa" name="data[detail][keluarga][produksi_perkebunan][kelapa][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kelapa"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kelapa" name="data[detail][keluarga][produksi_perkebunan][kelapa][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kelapa"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kelapa" name="data[detail][keluarga][produksi_perkebunan][kelapa][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kelapa"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kelapa" name="data[detail][keluarga][produksi_perkebunan][kelapa][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kelapa"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_kelapa_sawit" class="col-sm-3 control-label">Kelapa sawit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kelapa_sawit" name="data[detail][keluarga][produksi_perkebunan][kelapa_sawit][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kelapa_sawit"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kelapa_sawit" name="data[detail][keluarga][produksi_perkebunan][kelapa_sawit][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kelapa_sawit"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kelapa_sawit" name="data[detail][keluarga][produksi_perkebunan][kelapa_sawit][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kelapa_sawit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kelapa_sawit" name="data[detail][keluarga][produksi_perkebunan][kelapa_sawit][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kelapa_sawit"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kelapa_sawit" name="data[detail][keluarga][produksi_perkebunan][kelapa_sawit][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kelapa_sawit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_kopi" class="col-sm-3 control-label">Kopi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kopi" name="data[detail][keluarga][produksi_perkebunan][kopi][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kopi"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kopi" name="data[detail][keluarga][produksi_perkebunan][kopi][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kopi"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kopi" name="data[detail][keluarga][produksi_perkebunan][kopi][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kopi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kopi" name="data[detail][keluarga][produksi_perkebunan][kopi][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kopi"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kopi" name="data[detail][keluarga][produksi_perkebunan][kopi][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kopi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_cengkeh" class="col-sm-3 control-label">Cengkeh</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_cengkeh" name="data[detail][keluarga][produksi_perkebunan][cengkeh][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["cengkeh"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_cengkeh" name="data[detail][keluarga][produksi_perkebunan][cengkeh][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["cengkeh"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_cengkeh" name="data[detail][keluarga][produksi_perkebunan][cengkeh][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["cengkeh"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_cengkeh" name="data[detail][keluarga][produksi_perkebunan][cengkeh][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["cengkeh"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_cengkeh" name="data[detail][keluarga][produksi_perkebunan][cengkeh][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["cengkeh"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_coklat" class="col-sm-3 control-label">Coklat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_coklat" name="data[detail][keluarga][produksi_perkebunan][coklat][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["coklat"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_coklat" name="data[detail][keluarga][produksi_perkebunan][coklat][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["coklat"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_coklat" name="data[detail][keluarga][produksi_perkebunan][coklat][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["coklat"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_coklat" name="data[detail][keluarga][produksi_perkebunan][coklat][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["coklat"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_coklat" name="data[detail][keluarga][produksi_perkebunan][coklat][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["coklat"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_pinang" class="col-sm-3 control-label">Pinang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_pinang" name="data[detail][keluarga][produksi_perkebunan][pinang][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["pinang"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_pinang" name="data[detail][keluarga][produksi_perkebunan][pinang][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["pinang"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_pinang" name="data[detail][keluarga][produksi_perkebunan][pinang][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["pinang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_pinang" name="data[detail][keluarga][produksi_perkebunan][pinang][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["pinang"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_pinang" name="data[detail][keluarga][produksi_perkebunan][pinang][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["pinang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_lada" class="col-sm-3 control-label">Lada</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lada" name="data[detail][keluarga][produksi_perkebunan][lada][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lada"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lada" name="data[detail][keluarga][produksi_perkebunan][lada][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lada"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lada" name="data[detail][keluarga][produksi_perkebunan][lada][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lada"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lada" name="data[detail][keluarga][produksi_perkebunan][lada][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lada"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lada" name="data[detail][keluarga][produksi_perkebunan][lada][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lada"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_karet" class="col-sm-3 control-label">Karet</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_karet" name="data[detail][keluarga][produksi_perkebunan][karet][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["karet"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_karet" name="data[detail][keluarga][produksi_perkebunan][karet][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["karet"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_karet" name="data[detail][keluarga][produksi_perkebunan][karet][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["karet"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_karet" name="data[detail][keluarga][produksi_perkebunan][karet][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["karet"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_karet" name="data[detail][keluarga][produksi_perkebunan][karet][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["karet"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_jambu_mete" class="col-sm-3 control-label">Jambu mete</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jambu_mete" name="data[detail][keluarga][produksi_perkebunan][jambu_mete][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jambu_mete"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jambu_mete" name="data[detail][keluarga][produksi_perkebunan][jambu_mete][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jambu_mete"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jambu_mete" name="data[detail][keluarga][produksi_perkebunan][jambu_mete][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jambu_mete"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jambu_mete" name="data[detail][keluarga][produksi_perkebunan][jambu_mete][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jambu_mete"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jambu_mete" name="data[detail][keluarga][produksi_perkebunan][jambu_mete][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jambu_mete"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_tembakau" class="col-sm-3 control-label">Tembakau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_tembakau" name="data[detail][keluarga][produksi_perkebunan][tembakau][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["tembakau"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_tembakau" name="data[detail][keluarga][produksi_perkebunan][tembakau][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["tembakau"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_tembakau" name="data[detail][keluarga][produksi_perkebunan][tembakau][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["tembakau"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_tembakau" name="data[detail][keluarga][produksi_perkebunan][tembakau][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["tembakau"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_tembakau" name="data[detail][keluarga][produksi_perkebunan][tembakau][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["tembakau"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_pala" class="col-sm-3 control-label">Pala</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_pala" name="data[detail][keluarga][produksi_perkebunan][pala][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["pala"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_pala" name="data[detail][keluarga][produksi_perkebunan][pala][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["pala"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_pala" name="data[detail][keluarga][produksi_perkebunan][pala][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["pala"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_pala" name="data[detail][keluarga][produksi_perkebunan][pala][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["pala"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_pala" name="data[detail][keluarga][produksi_perkebunan][pala][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["pala"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_vanili" class="col-sm-3 control-label">Vanili</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_vanili" name="data[detail][keluarga][produksi_perkebunan][vanili][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["vanili"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_vanili" name="data[detail][keluarga][produksi_perkebunan][vanili][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["vanili"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_vanili" name="data[detail][keluarga][produksi_perkebunan][vanili][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["vanili"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_vanili" name="data[detail][keluarga][produksi_perkebunan][vanili][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["vanili"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_vanili" name="data[detail][keluarga][produksi_perkebunan][vanili][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["vanili"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_jarak_pagar" class="col-sm-3 control-label">Jarak pagar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jarak_pagar" name="data[detail][keluarga][produksi_perkebunan][jarak_pagar][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jarak_pagar"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jarak_pagar" name="data[detail][keluarga][produksi_perkebunan][jarak_pagar][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jarak_pagar"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jarak_pagar" name="data[detail][keluarga][produksi_perkebunan][jarak_pagar][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jarak_pagar"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jarak_pagar" name="data[detail][keluarga][produksi_perkebunan][jarak_pagar][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jarak_pagar"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jarak_pagar" name="data[detail][keluarga][produksi_perkebunan][jarak_pagar][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jarak_pagar"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_jarak_kepyar" class="col-sm-3 control-label">Jarak kepyar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jarak_kepyar" name="data[detail][keluarga][produksi_perkebunan][jarak_kepyar][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jarak_kepyar"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jarak_kepyar" name="data[detail][keluarga][produksi_perkebunan][jarak_kepyar][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jarak_kepyar"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jarak_kepyar" name="data[detail][keluarga][produksi_perkebunan][jarak_kepyar][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jarak_kepyar"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jarak_kepyar" name="data[detail][keluarga][produksi_perkebunan][jarak_kepyar][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jarak_kepyar"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_jarak_kepyar" name="data[detail][keluarga][produksi_perkebunan][jarak_kepyar][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["jarak_kepyar"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_tebu" class="col-sm-3 control-label">Tebu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_tebu" name="data[detail][keluarga][produksi_perkebunan][tebu][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["tebu"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_tebu" name="data[detail][keluarga][produksi_perkebunan][tebu][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["tebu"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_tebu" name="data[detail][keluarga][produksi_perkebunan][tebu][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["tebu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_tebu" name="data[detail][keluarga][produksi_perkebunan][tebu][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["tebu"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_tebu" name="data[detail][keluarga][produksi_perkebunan][tebu][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["tebu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_kapuk" class="col-sm-3 control-label">Kapuk</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kapuk" name="data[detail][keluarga][produksi_perkebunan][kapuk][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kapuk"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kapuk" name="data[detail][keluarga][produksi_perkebunan][kapuk][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kapuk"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kapuk" name="data[detail][keluarga][produksi_perkebunan][kapuk][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kapuk"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kapuk" name="data[detail][keluarga][produksi_perkebunan][kapuk][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kapuk"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kapuk" name="data[detail][keluarga][produksi_perkebunan][kapuk][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kapuk"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_kemiri" class="col-sm-3 control-label">Kemiri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kemiri" name="data[detail][keluarga][produksi_perkebunan][kemiri][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kemiri"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kemiri" name="data[detail][keluarga][produksi_perkebunan][kemiri][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kemiri"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kemiri" name="data[detail][keluarga][produksi_perkebunan][kemiri][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kemiri"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kemiri" name="data[detail][keluarga][produksi_perkebunan][kemiri][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kemiri"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_kemiri" name="data[detail][keluarga][produksi_perkebunan][kemiri][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["kemiri"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_teh" class="col-sm-3 control-label">Teh</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_teh" name="data[detail][keluarga][produksi_perkebunan][teh][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["teh"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_teh" name="data[detail][keluarga][produksi_perkebunan][teh][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["teh"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_teh" name="data[detail][keluarga][produksi_perkebunan][teh][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["teh"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_teh" name="data[detail][keluarga][produksi_perkebunan][teh][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["teh"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_teh" name="data[detail][keluarga][produksi_perkebunan][teh][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["teh"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perkebunan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lainnya" name="data[detail][keluarga][produksi_perkebunan][lainnya][keterangan]" placeholder="tanaman perkebunan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lainnya" name="data[detail][keluarga][produksi_perkebunan][lainnya][jumlah]" placeholder="jumlah pohon" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lainnya"]["jumlah"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lainnya" name="data[detail][keluarga][produksi_perkebunan][lainnya][luas]" placeholder="luas panen (m2)" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lainnya"]["luas"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lainnya" name="data[detail][keluarga][produksi_perkebunan][lainnya][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lainnya"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lainnya" name="data[detail][keluarga][produksi_perkebunan][lainnya][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lainnya"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perkebunan_lainnya" name="data[detail][keluarga][produksi_perkebunan][lainnya][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perkebunan"]["lainnya"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4>Hasil Hutan</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_kayu_bakar" class="col-sm-3 control-label">Kayu bakar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_bakar" name="data[detail][keluarga][produksi_hutan][kayu_bakar][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_bakar"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_bakar" name="data[detail][keluarga][produksi_hutan][kayu_bakar][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_bakar"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_bakar" name="data[detail][keluarga][produksi_hutan][kayu_bakar][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_bakar"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_madu_lebah" class="col-sm-3 control-label">Madu lebah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_madu_lebah" name="data[detail][keluarga][produksi_hutan][madu_lebah][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["madu_lebah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_madu_lebah" name="data[detail][keluarga][produksi_hutan][madu_lebah][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["madu_lebah"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_madu_lebah" name="data[detail][keluarga][produksi_hutan][madu_lebah][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["madu_lebah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_rotan" class="col-sm-3 control-label">Rotan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_rotan" name="data[detail][keluarga][produksi_hutan][rotan][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["rotan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_rotan" name="data[detail][keluarga][produksi_hutan][rotan][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["rotan"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_rotan" name="data[detail][keluarga][produksi_hutan][rotan][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["rotan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_damar" class="col-sm-3 control-label">Damar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_damar" name="data[detail][keluarga][produksi_hutan][damar][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["damar"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_damar" name="data[detail][keluarga][produksi_hutan][damar][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["damar"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_damar" name="data[detail][keluarga][produksi_hutan][damar][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["damar"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_bambu" class="col-sm-3 control-label">Bambu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_bambu" name="data[detail][keluarga][produksi_hutan][bambu][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["bambu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_bambu" name="data[detail][keluarga][produksi_hutan][bambu][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["bambu"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_bambu" name="data[detail][keluarga][produksi_hutan][bambu][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["bambu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_jati" class="col-sm-3 control-label">Jati</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_jati" name="data[detail][keluarga][produksi_hutan][jati][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["jati"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_jati" name="data[detail][keluarga][produksi_hutan][jati][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["jati"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_jati" name="data[detail][keluarga][produksi_hutan][jati][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["jati"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_nilam" class="col-sm-3 control-label">Nilam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_nilam" name="data[detail][keluarga][produksi_hutan][nilam][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["nilam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_nilam" name="data[detail][keluarga][produksi_hutan][nilam][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["nilam"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_nilam" name="data[detail][keluarga][produksi_hutan][nilam][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["nilam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_nira_lontar" class="col-sm-3 control-label">Nira Lontar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_nira_lontar" name="data[detail][keluarga][produksi_hutan][nira_lontar][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["nira_lontar"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_nira_lontar" name="data[detail][keluarga][produksi_hutan][nira_lontar][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["nira_lontar"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_nira_lontar" name="data[detail][keluarga][produksi_hutan][nira_lontar][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["nira_lontar"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_tepung_sagu" class="col-sm-3 control-label">Tepung Sagu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_tepung_sagu" name="data[detail][keluarga][produksi_hutan][tepung_sagu][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["tepung_sagu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_tepung_sagu" name="data[detail][keluarga][produksi_hutan][tepung_sagu][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["tepung_sagu"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_tepung_sagu" name="data[detail][keluarga][produksi_hutan][tepung_sagu][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["tepung_sagu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_ijuk_enau" class="col-sm-3 control-label">Ijuk Enau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_ijuk_enau" name="data[detail][keluarga][produksi_hutan][ijuk_enau][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["ijuk_enau"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_ijuk_enau" name="data[detail][keluarga][produksi_hutan][ijuk_enau][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["ijuk_enau"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_ijuk_enau" name="data[detail][keluarga][produksi_hutan][ijuk_enau][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["ijuk_enau"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_mahoni" class="col-sm-3 control-label">Mahoni</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_mahoni" name="data[detail][keluarga][produksi_hutan][mahoni][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["mahoni"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_mahoni" name="data[detail][keluarga][produksi_hutan][mahoni][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["mahoni"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_mahoni" name="data[detail][keluarga][produksi_hutan][mahoni][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["mahoni"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_cemara" class="col-sm-3 control-label">Cemara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_cemara" name="data[detail][keluarga][produksi_hutan][cemara][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["cemara"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_cemara" name="data[detail][keluarga][produksi_hutan][cemara][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["cemara"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_cemara" name="data[detail][keluarga][produksi_hutan][cemara][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["cemara"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_kayu_cendana" class="col-sm-3 control-label">Kayu cendana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_cendana" name="data[detail][keluarga][produksi_hutan][kayu_cendana][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_cendana"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_cendana" name="data[detail][keluarga][produksi_hutan][kayu_cendana][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_cendana"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_cendana" name="data[detail][keluarga][produksi_hutan][kayu_cendana][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_cendana"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_kayu_gaharu" class="col-sm-3 control-label">Kayu gaharu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_gaharu" name="data[detail][keluarga][produksi_hutan][kayu_gaharu][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_gaharu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_gaharu" name="data[detail][keluarga][produksi_hutan][kayu_gaharu][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_gaharu"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_gaharu" name="data[detail][keluarga][produksi_hutan][kayu_gaharu][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_gaharu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_sarang_burung" class="col-sm-3 control-label">Sarang burung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_sarang_burung" name="data[detail][keluarga][produksi_hutan][sarang_burung][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["sarang_burung"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_sarang_burung" name="data[detail][keluarga][produksi_hutan][sarang_burung][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["sarang_burung"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_sarang_burung" name="data[detail][keluarga][produksi_hutan][sarang_burung][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["sarang_burung"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_meranti" class="col-sm-3 control-label">Meranti</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_meranti" name="data[detail][keluarga][produksi_hutan][meranti][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["meranti"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_meranti" name="data[detail][keluarga][produksi_hutan][meranti][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["meranti"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_meranti" name="data[detail][keluarga][produksi_hutan][meranti][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["meranti"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_kayu_besi" class="col-sm-3 control-label">Kayu besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_besi" name="data[detail][keluarga][produksi_hutan][kayu_besi][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_besi" name="data[detail][keluarga][produksi_hutan][kayu_besi][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_besi"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_besi" name="data[detail][keluarga][produksi_hutan][kayu_besi][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_kayu_ulin" class="col-sm-3 control-label">Kayu ulin</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_ulin" name="data[detail][keluarga][produksi_hutan][kayu_ulin][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_ulin"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_ulin" name="data[detail][keluarga][produksi_hutan][kayu_ulin][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_ulin"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kayu_ulin" name="data[detail][keluarga][produksi_hutan][kayu_ulin][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kayu_ulin"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_kemenyan" class="col-sm-3 control-label">Kemenyan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kemenyan" name="data[detail][keluarga][produksi_hutan][kemenyan][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kemenyan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kemenyan" name="data[detail][keluarga][produksi_hutan][kemenyan][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kemenyan"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_kemenyan" name="data[detail][keluarga][produksi_hutan][kemenyan][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["kemenyan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_gambir" class="col-sm-3 control-label">Gambir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_gambir" name="data[detail][keluarga][produksi_hutan][gambir][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["gambir"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_gambir" name="data[detail][keluarga][produksi_hutan][gambir][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["gambir"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_gambir" name="data[detail][keluarga][produksi_hutan][gambir][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["gambir"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_minyak_kayu_putih" class="col-sm-3 control-label">Minyak kayu putih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_minyak_kayu_putih" name="data[detail][keluarga][produksi_hutan][minyak_kayu_putih][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["minyak_kayu_putih"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_minyak_kayu_putih" name="data[detail][keluarga][produksi_hutan][minyak_kayu_putih][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["minyak_kayu_putih"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_minyak_kayu_putih" name="data[detail][keluarga][produksi_hutan][minyak_kayu_putih][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["minyak_kayu_putih"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_gula_lontar" class="col-sm-3 control-label">Gula Lontar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_gula_lontar" name="data[detail][keluarga][produksi_hutan][gula_lontar][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["gula_lontar"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_gula_lontar" name="data[detail][keluarga][produksi_hutan][gula_lontar][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["gula_lontar"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_gula_lontar" name="data[detail][keluarga][produksi_hutan][gula_lontar][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["gula_lontar"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_gula_enau" class="col-sm-3 control-label">Gula Enau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_gula_enau" name="data[detail][keluarga][produksi_hutan][gula_enau][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["gula_enau"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_gula_enau" name="data[detail][keluarga][produksi_hutan][gula_enau][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["gula_enau"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_gula_enau" name="data[detail][keluarga][produksi_hutan][gula_enau][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["gula_enau"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_hutan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_hutan_lainnya" name="data[detail][keluarga][produksi_hutan][lainnya][keterangan]" placeholder="tanaman hasil hutan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_lainnya" name="data[detail][keluarga][produksi_hutan][lainnya][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["lainnya"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_lainnya" name="data[detail][keluarga][produksi_hutan][lainnya][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["lainnya"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_hutan_lainnya" name="data[detail][keluarga][produksi_hutan][lainnya][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_hutan"]["lainnya"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4>Pengolahan Hasil Ternak</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_susu" class="col-sm-3 control-label">Susu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_susu" name="data[detail][keluarga][produksi_ternak][susu][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["susu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_susu" name="data[detail][keluarga][produksi_ternak][susu][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["susu"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_susu" name="data[detail][keluarga][produksi_ternak][susu][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["susu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_kulit" class="col-sm-3 control-label">Kulit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_kulit" name="data[detail][keluarga][produksi_ternak][kulit][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["kulit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_kulit" name="data[detail][keluarga][produksi_ternak][kulit][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["kulit"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_kulit" name="data[detail][keluarga][produksi_ternak][kulit][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["kulit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_telur" class="col-sm-3 control-label">Telur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_telur" name="data[detail][keluarga][produksi_ternak][telur][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["telur"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_telur" name="data[detail][keluarga][produksi_ternak][telur][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["telur"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_telur" name="data[detail][keluarga][produksi_ternak][telur][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["telur"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_daging" class="col-sm-3 control-label">Daging</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_daging" name="data[detail][keluarga][produksi_ternak][daging][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["daging"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_daging" name="data[detail][keluarga][produksi_ternak][daging][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["daging"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_daging" name="data[detail][keluarga][produksi_ternak][daging][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["daging"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_madu_lebah" class="col-sm-3 control-label">Madu Lebah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_madu_lebah" name="data[detail][keluarga][produksi_ternak][madu_lebah][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["madu_lebah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_madu_lebah" name="data[detail][keluarga][produksi_ternak][madu_lebah][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["madu_lebah"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_madu_lebah" name="data[detail][keluarga][produksi_ternak][madu_lebah][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["madu_lebah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_bulu" class="col-sm-3 control-label">Bulu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_bulu" name="data[detail][keluarga][produksi_ternak][bulu][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["bulu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_bulu" name="data[detail][keluarga][produksi_ternak][bulu][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["bulu"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_bulu" name="data[detail][keluarga][produksi_ternak][bulu][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["bulu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_air_liur_burung_walet" class="col-sm-3 control-label">Air liur burung walet</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_air_liur_burung_walet" name="data[detail][keluarga][produksi_ternak][air_liur_burung_walet][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["air_liur_burung_walet"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_air_liur_burung_walet" name="data[detail][keluarga][produksi_ternak][air_liur_burung_walet][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["air_liur_burung_walet"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_air_liur_burung_walet" name="data[detail][keluarga][produksi_ternak][air_liur_burung_walet][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["air_liur_burung_walet"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_minyak_hewani" class="col-sm-3 control-label">Minyak hewani</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_minyak_hewani" name="data[detail][keluarga][produksi_ternak][minyak_hewani][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["minyak_hewani"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_minyak_hewani" name="data[detail][keluarga][produksi_ternak][minyak_hewani][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["minyak_hewani"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_minyak_hewani" name="data[detail][keluarga][produksi_ternak][minyak_hewani][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["minyak_hewani"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_hiasan_lukisan" class="col-sm-3 control-label">Hiasan/lukisan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_hiasan_lukisan" name="data[detail][keluarga][produksi_ternak][hiasan_lukisan][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["hiasan_lukisan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_hiasan_lukisan" name="data[detail][keluarga][produksi_ternak][hiasan_lukisan][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["hiasan_lukisan"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_hiasan_lukisan" name="data[detail][keluarga][produksi_ternak][hiasan_lukisan][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["hiasan_lukisan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_kerajinan_cinderamata" class="col-sm-3 control-label">Kerajinan Cinderamata</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_kerajinan_cinderamata" name="data[detail][keluarga][produksi_ternak][kerajinan_cinderamata][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["kerajinan_cinderamata"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_kerajinan_cinderamata" name="data[detail][keluarga][produksi_ternak][kerajinan_cinderamata][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["kerajinan_cinderamata"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_kerajinan_cinderamata" name="data[detail][keluarga][produksi_ternak][kerajinan_cinderamata][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["kerajinan_cinderamata"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_dendeng" class="col-sm-3 control-label">Dendeng</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_dendeng" name="data[detail][keluarga][produksi_ternak][dendeng][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["dendeng"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_dendeng" name="data[detail][keluarga][produksi_ternak][dendeng][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["dendeng"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_dendeng" name="data[detail][keluarga][produksi_ternak][dendeng][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["dendeng"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_abon" class="col-sm-3 control-label">Abon</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_abon" name="data[detail][keluarga][produksi_ternak][abon][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["abon"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_abon" name="data[detail][keluarga][produksi_ternak][abon][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["abon"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_abon" name="data[detail][keluarga][produksi_ternak][abon][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["abon"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_biogas" class="col-sm-3 control-label">Biogas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_biogas" name="data[detail][keluarga][produksi_ternak][biogas][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["biogas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_biogas" name="data[detail][keluarga][produksi_ternak][biogas][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["biogas"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_biogas" name="data[detail][keluarga][produksi_ternak][biogas][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["biogas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_telur_asin" class="col-sm-3 control-label">Telur Asin</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_telur_asin" name="data[detail][keluarga][produksi_ternak][telur_asin][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["telur_asin"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_telur_asin" name="data[detail][keluarga][produksi_ternak][telur_asin][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["telur_asin"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_telur_asin" name="data[detail][keluarga][produksi_ternak][telur_asin][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["telur_asin"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_kerupuk_kulit" class="col-sm-3 control-label">Kerupuk Kulit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_kerupuk_kulit" name="data[detail][keluarga][produksi_ternak][kerupuk_kulit][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["kerupuk_kulit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_kerupuk_kulit" name="data[detail][keluarga][produksi_ternak][kerupuk_kulit][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["kerupuk_kulit"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_kerupuk_kulit" name="data[detail][keluarga][produksi_ternak][kerupuk_kulit][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["kerupuk_kulit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_ternak_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_ternak_lainnya" name="data[detail][keluarga][produksi_ternak][lainnya][keterangan]" placeholder="tanaman hasil hutan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_lainnya" name="data[detail][keluarga][produksi_ternak][lainnya][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["lainnya"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_lainnya" name="data[detail][keluarga][produksi_ternak][lainnya][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["lainnya"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_ternak_lainnya" name="data[detail][keluarga][produksi_ternak][lainnya][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_ternak"]["lainnya"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4>Perikanan</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_tuna" class="col-sm-3 control-label">Tuna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tuna" name="data[detail][keluarga][produksi_perikanan][tuna][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tuna"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tuna" name="data[detail][keluarga][produksi_perikanan][tuna][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tuna"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tuna" name="data[detail][keluarga][produksi_perikanan][tuna][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tuna"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_salmon" class="col-sm-3 control-label">Salmon</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_salmon" name="data[detail][keluarga][produksi_perikanan][salmon][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["salmon"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_salmon" name="data[detail][keluarga][produksi_perikanan][salmon][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["salmon"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_salmon" name="data[detail][keluarga][produksi_perikanan][salmon][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["salmon"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_tongkol_cakalang" class="col-sm-3 control-label">Tongkol/cakalang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tongkol_cakalang" name="data[detail][keluarga][produksi_perikanan][tongkol_cakalang][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tongkol_cakalang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tongkol_cakalang" name="data[detail][keluarga][produksi_perikanan][tongkol_cakalang][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tongkol_cakalang"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tongkol_cakalang" name="data[detail][keluarga][produksi_perikanan][tongkol_cakalang][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tongkol_cakalang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_hiu" class="col-sm-3 control-label">Hiu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_hiu" name="data[detail][keluarga][produksi_perikanan][hiu][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["hiu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_hiu" name="data[detail][keluarga][produksi_perikanan][hiu][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["hiu"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_hiu" name="data[detail][keluarga][produksi_perikanan][hiu][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["hiu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_kakap" class="col-sm-3 control-label">Kakap</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kakap" name="data[detail][keluarga][produksi_perikanan][kakap][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kakap"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kakap" name="data[detail][keluarga][produksi_perikanan][kakap][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kakap"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kakap" name="data[detail][keluarga][produksi_perikanan][kakap][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kakap"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_tenggiri" class="col-sm-3 control-label">Tenggiri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tenggiri" name="data[detail][keluarga][produksi_perikanan][tenggiri][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tenggiri"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tenggiri" name="data[detail][keluarga][produksi_perikanan][tenggiri][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tenggiri"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tenggiri" name="data[detail][keluarga][produksi_perikanan][tenggiri][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tenggiri"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_jambal" class="col-sm-3 control-label">Jambal</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_jambal" name="data[detail][keluarga][produksi_perikanan][jambal][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["jambal"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_jambal" name="data[detail][keluarga][produksi_perikanan][jambal][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["jambal"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_jambal" name="data[detail][keluarga][produksi_perikanan][jambal][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["jambal"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_pari" class="col-sm-3 control-label">Pari</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_pari" name="data[detail][keluarga][produksi_perikanan][pari][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["pari"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_pari" name="data[detail][keluarga][produksi_perikanan][pari][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["pari"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_pari" name="data[detail][keluarga][produksi_perikanan][pari][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["pari"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_kuwe" class="col-sm-3 control-label">Kuwe</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kuwe" name="data[detail][keluarga][produksi_perikanan][kuwe][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kuwe"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kuwe" name="data[detail][keluarga][produksi_perikanan][kuwe][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kuwe"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kuwe" name="data[detail][keluarga][produksi_perikanan][kuwe][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kuwe"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_belanak" class="col-sm-3 control-label">Belanak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_belanak" name="data[detail][keluarga][produksi_perikanan][belanak][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["belanak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_belanak" name="data[detail][keluarga][produksi_perikanan][belanak][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["belanak"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_belanak" name="data[detail][keluarga][produksi_perikanan][belanak][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["belanak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_cumi" class="col-sm-3 control-label">Cumi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_cumi" name="data[detail][keluarga][produksi_perikanan][cumi][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["cumi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_cumi" name="data[detail][keluarga][produksi_perikanan][cumi][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["cumi"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_cumi" name="data[detail][keluarga][produksi_perikanan][cumi][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["cumi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_gurita" class="col-sm-3 control-label">Gurita</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_gurita" name="data[detail][keluarga][produksi_perikanan][gurita][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["gurita"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_gurita" name="data[detail][keluarga][produksi_perikanan][gurita][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["gurita"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_gurita" name="data[detail][keluarga][produksi_perikanan][gurita][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["gurita"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_sarden" class="col-sm-3 control-label">Sarden</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_sarden" name="data[detail][keluarga][produksi_perikanan][sarden][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["sarden"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_sarden" name="data[detail][keluarga][produksi_perikanan][sarden][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["sarden"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_sarden" name="data[detail][keluarga][produksi_perikanan][sarden][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["sarden"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_bawal" class="col-sm-3 control-label">Bawal</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_bawal" name="data[detail][keluarga][produksi_perikanan][bawal][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["bawal"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_bawal" name="data[detail][keluarga][produksi_perikanan][bawal][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["bawal"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_bawal" name="data[detail][keluarga][produksi_perikanan][bawal][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["bawal"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_baronang" class="col-sm-3 control-label">Baronang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_baronang" name="data[detail][keluarga][produksi_perikanan][baronang][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["baronang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_baronang" name="data[detail][keluarga][produksi_perikanan][baronang][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["baronang"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_baronang" name="data[detail][keluarga][produksi_perikanan][baronang][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["baronang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_kembung" class="col-sm-3 control-label">Kembung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kembung" name="data[detail][keluarga][produksi_perikanan][kembung][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kembung"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kembung" name="data[detail][keluarga][produksi_perikanan][kembung][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kembung"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kembung" name="data[detail][keluarga][produksi_perikanan][kembung][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kembung"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_balanak" class="col-sm-3 control-label">Balanak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_balanak" name="data[detail][keluarga][produksi_perikanan][balanak][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["balanak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_balanak" name="data[detail][keluarga][produksi_perikanan][balanak][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["balanak"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_balanak" name="data[detail][keluarga][produksi_perikanan][balanak][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["balanak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_ikan_ekor_kuning" class="col-sm-3 control-label">Ikan ekor kuning</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_ikan_ekor_kuning" name="data[detail][keluarga][produksi_perikanan][ikan_ekor_kuning][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["ikan_ekor_kuning"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_ikan_ekor_kuning" name="data[detail][keluarga][produksi_perikanan][ikan_ekor_kuning][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["ikan_ekor_kuning"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_ikan_ekor_kuning" name="data[detail][keluarga][produksi_perikanan][ikan_ekor_kuning][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["ikan_ekor_kuning"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_kerapu_sunuk" class="col-sm-3 control-label">Kerapu/Sunuk</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kerapu_sunuk" name="data[detail][keluarga][produksi_perikanan][kerapu_sunuk][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kerapu_sunuk"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kerapu_sunuk" name="data[detail][keluarga][produksi_perikanan][kerapu_sunuk][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kerapu_sunuk"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kerapu_sunuk" name="data[detail][keluarga][produksi_perikanan][kerapu_sunuk][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kerapu_sunuk"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_teripang" class="col-sm-3 control-label">Teripang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_teripang" name="data[detail][keluarga][produksi_perikanan][teripang][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["teripang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_teripang" name="data[detail][keluarga][produksi_perikanan][teripang][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["teripang"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_teripang" name="data[detail][keluarga][produksi_perikanan][teripang][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["teripang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_barabara" class="col-sm-3 control-label">Barabara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_barabara" name="data[detail][keluarga][produksi_perikanan][barabara][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["barabara"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_barabara" name="data[detail][keluarga][produksi_perikanan][barabara][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["barabara"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_barabara" name="data[detail][keluarga][produksi_perikanan][barabara][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["barabara"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_cucut" class="col-sm-3 control-label">Cucut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_cucut" name="data[detail][keluarga][produksi_perikanan][cucut][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["cucut"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_cucut" name="data[detail][keluarga][produksi_perikanan][cucut][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["cucut"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_cucut" name="data[detail][keluarga][produksi_perikanan][cucut][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["cucut"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_layur" class="col-sm-3 control-label">Layur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_layur" name="data[detail][keluarga][produksi_perikanan][layur][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["layur"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_layur" name="data[detail][keluarga][produksi_perikanan][layur][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["layur"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_layur" name="data[detail][keluarga][produksi_perikanan][layur][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["layur"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_ayam_ayam" class="col-sm-3 control-label">Ayam-ayam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_ayam_ayam" name="data[detail][keluarga][produksi_perikanan][ayam_ayam][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["ayam_ayam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_ayam_ayam" name="data[detail][keluarga][produksi_perikanan][ayam_ayam][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["ayam_ayam"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_ayam_ayam" name="data[detail][keluarga][produksi_perikanan][ayam_ayam][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["ayam_ayam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_udang_lobster" class="col-sm-3 control-label">Udang/lobster</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_udang_lobster" name="data[detail][keluarga][produksi_perikanan][udang_lobster][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["udang_lobster"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_udang_lobster" name="data[detail][keluarga][produksi_perikanan][udang_lobster][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["udang_lobster"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_udang_lobster" name="data[detail][keluarga][produksi_perikanan][udang_lobster][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["udang_lobster"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_tembang" class="col-sm-3 control-label">Tembang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tembang" name="data[detail][keluarga][produksi_perikanan][tembang][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tembang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tembang" name="data[detail][keluarga][produksi_perikanan][tembang][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tembang"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_tembang" name="data[detail][keluarga][produksi_perikanan][tembang][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["tembang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_bandeng" class="col-sm-3 control-label">Bandeng</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_bandeng" name="data[detail][keluarga][produksi_perikanan][bandeng][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["bandeng"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_bandeng" name="data[detail][keluarga][produksi_perikanan][bandeng][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["bandeng"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_bandeng" name="data[detail][keluarga][produksi_perikanan][bandeng][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["bandeng"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_nener" class="col-sm-3 control-label">Nener</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_nener" name="data[detail][keluarga][produksi_perikanan][nener][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["nener"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_nener" name="data[detail][keluarga][produksi_perikanan][nener][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["nener"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_nener" name="data[detail][keluarga][produksi_perikanan][nener][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["nener"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_kerang" class="col-sm-3 control-label">Kerang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kerang" name="data[detail][keluarga][produksi_perikanan][kerang][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kerang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kerang" name="data[detail][keluarga][produksi_perikanan][kerang][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kerang"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kerang" name="data[detail][keluarga][produksi_perikanan][kerang][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kerang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_kepiting" class="col-sm-3 control-label">Kepiting</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kepiting" name="data[detail][keluarga][produksi_perikanan][kepiting][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kepiting"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kepiting" name="data[detail][keluarga][produksi_perikanan][kepiting][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kepiting"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kepiting" name="data[detail][keluarga][produksi_perikanan][kepiting][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kepiting"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_mas" class="col-sm-3 control-label">Mas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_mas" name="data[detail][keluarga][produksi_perikanan][mas][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["mas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_mas" name="data[detail][keluarga][produksi_perikanan][mas][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["mas"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_mas" name="data[detail][keluarga][produksi_perikanan][mas][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["mas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_rajungan" class="col-sm-3 control-label">Rajungan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_rajungan" name="data[detail][keluarga][produksi_perikanan][rajungan][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["rajungan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_rajungan" name="data[detail][keluarga][produksi_perikanan][rajungan][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["rajungan"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_rajungan" name="data[detail][keluarga][produksi_perikanan][rajungan][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["rajungan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_mujair" class="col-sm-3 control-label">Mujair</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_mujair" name="data[detail][keluarga][produksi_perikanan][mujair][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["mujair"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_mujair" name="data[detail][keluarga][produksi_perikanan][mujair][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["mujair"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_mujair" name="data[detail][keluarga][produksi_perikanan][mujair][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["mujair"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_lele" class="col-sm-3 control-label">Lele</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_lele" name="data[detail][keluarga][produksi_perikanan][lele][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["lele"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_lele" name="data[detail][keluarga][produksi_perikanan][lele][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["lele"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_lele" name="data[detail][keluarga][produksi_perikanan][lele][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["lele"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_gabus" class="col-sm-3 control-label">Gabus</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_gabus" name="data[detail][keluarga][produksi_perikanan][gabus][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["gabus"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_gabus" name="data[detail][keluarga][produksi_perikanan][gabus][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["gabus"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_gabus" name="data[detail][keluarga][produksi_perikanan][gabus][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["gabus"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_patin" class="col-sm-3 control-label">Patin</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_patin" name="data[detail][keluarga][produksi_perikanan][patin][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["patin"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_patin" name="data[detail][keluarga][produksi_perikanan][patin][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["patin"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_patin" name="data[detail][keluarga][produksi_perikanan][patin][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["patin"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_nila" class="col-sm-3 control-label">Nila</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_nila" name="data[detail][keluarga][produksi_perikanan][nila][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["nila"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_nila" name="data[detail][keluarga][produksi_perikanan][nila][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["nila"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_nila" name="data[detail][keluarga][produksi_perikanan][nila][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["nila"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_sepat" class="col-sm-3 control-label">Sepat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_sepat" name="data[detail][keluarga][produksi_perikanan][sepat][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["sepat"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_sepat" name="data[detail][keluarga][produksi_perikanan][sepat][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["sepat"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_sepat" name="data[detail][keluarga][produksi_perikanan][sepat][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["sepat"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_gurame" class="col-sm-3 control-label">Gurame</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_gurame" name="data[detail][keluarga][produksi_perikanan][gurame][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["gurame"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_gurame" name="data[detail][keluarga][produksi_perikanan][gurame][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["gurame"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_gurame" name="data[detail][keluarga][produksi_perikanan][gurame][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["gurame"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_belut" class="col-sm-3 control-label">Belut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_belut" name="data[detail][keluarga][produksi_perikanan][belut][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["belut"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_belut" name="data[detail][keluarga][produksi_perikanan][belut][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["belut"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_belut" name="data[detail][keluarga][produksi_perikanan][belut][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["belut"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_penyu" class="col-sm-3 control-label">Penyu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_penyu" name="data[detail][keluarga][produksi_perikanan][penyu][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["penyu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_penyu" name="data[detail][keluarga][produksi_perikanan][penyu][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["penyu"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_penyu" name="data[detail][keluarga][produksi_perikanan][penyu][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["penyu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_rumput_laut" class="col-sm-3 control-label">Rumput laut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_rumput_laut" name="data[detail][keluarga][produksi_perikanan][rumput_laut][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["rumput_laut"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_rumput_laut" name="data[detail][keluarga][produksi_perikanan][rumput_laut][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["rumput_laut"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_rumput_laut" name="data[detail][keluarga][produksi_perikanan][rumput_laut][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["rumput_laut"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_kodok" class="col-sm-3 control-label">Kodok</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kodok" name="data[detail][keluarga][produksi_perikanan][kodok][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kodok"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kodok" name="data[detail][keluarga][produksi_perikanan][kodok][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kodok"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_kodok" name="data[detail][keluarga][produksi_perikanan][kodok][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["kodok"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_katak" class="col-sm-3 control-label">Katak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_katak" name="data[detail][keluarga][produksi_perikanan][katak][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["katak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_katak" name="data[detail][keluarga][produksi_perikanan][katak][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["katak"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_katak" name="data[detail][keluarga][produksi_perikanan][katak][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["katak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_produksi_perikanan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_lainnya" name="data[detail][keluarga][produksi_perikanan][lainnya][keterangan]" placeholder="tanaman hasil hutan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_lainnya" name="data[detail][keluarga][produksi_perikanan][lainnya][produksi]" placeholder="produksi" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["lainnya"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_lainnya" name="data[detail][keluarga][produksi_perikanan][lainnya][satuan]" placeholder="satuan" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["lainnya"]["satuan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_produksi_perikanan_lainnya" name="data[detail][keluarga][produksi_perikanan][lainnya][pemasaran]" placeholder="pemasaran hasil" value="<?php echo $ddk->detail["keluarga"]["produksi_perikanan"]["lainnya"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Kepemilikan Jenis Ternak Keluarga Tahun Ini</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_sapi" class="col-sm-3 control-label">Sapi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_sapi" name="data[detail][keluarga][jenis_ternak][sapi]" placeholder="jumlah sapi" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["sapi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_kerbau" class="col-sm-3 control-label">Kerbau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_kerbau" name="data[detail][keluarga][jenis_ternak][kerbau]" placeholder="jumlah kerbau" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["kerbau"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_babi" class="col-sm-3 control-label">Babi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_babi" name="data[detail][keluarga][jenis_ternak][babi]" placeholder="jumlah babi" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["babi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_ayam_kampung" class="col-sm-3 control-label">Ayam kampung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_ayam_kampung" name="data[detail][keluarga][jenis_ternak][ayam_kampung]" placeholder="jumlah ayam kampung" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["ayam_kampung"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_ayam_broiler" class="col-sm-3 control-label">Ayam Broiler</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_ayam_broiler" name="data[detail][keluarga][jenis_ternak][ayam_broiler]" placeholder="jumlah ayam broiler" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["ayam_broiler"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_bebek" class="col-sm-3 control-label">Bebek</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_bebek" name="data[detail][keluarga][jenis_ternak][bebek]" placeholder="jumlah bebek" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["bebek"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_kuda" class="col-sm-3 control-label">Kuda</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_kuda" name="data[detail][keluarga][jenis_ternak][kuda]" placeholder="jumlah kuda" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["kuda"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_kambing" class="col-sm-3 control-label">Kambing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_kambing" name="data[detail][keluarga][jenis_ternak][kambing]" placeholder="jumlah kambing" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["kambing"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_domba" class="col-sm-3 control-label">Domba</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_domba" name="data[detail][keluarga][jenis_ternak][domba]" placeholder="jumlah domba" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["domba"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_angsa" class="col-sm-3 control-label">Angsa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_angsa" name="data[detail][keluarga][jenis_ternak][angsa]" placeholder="jumlah angsa" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["angsa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_burung_puyuh" class="col-sm-3 control-label">Burung Puyuh</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_burung_puyuh" name="data[detail][keluarga][jenis_ternak][burung_puyuh]" placeholder="jumlah burung puyuh" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["burung_puyuh"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_kelinci" class="col-sm-3 control-label">Kelinci</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_kelinci" name="data[detail][keluarga][jenis_ternak][kelinci]" placeholder="jumlah kelinci" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["kelinci"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_burung_walet" class="col-sm-3 control-label">Burung walet</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_burung_walet" name="data[detail][keluarga][jenis_ternak][burung_walet]" placeholder="jumlah burung walet" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["burung_walet"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_anjing" class="col-sm-3 control-label">Anjing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_anjing" name="data[detail][keluarga][jenis_ternak][anjing]" placeholder="jumlah anjing" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["anjing"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_kucing" class="col-sm-3 control-label">Kucing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_kucing" name="data[detail][keluarga][jenis_ternak][kucing]" placeholder="jumlah kucing" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["kucing"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_ular_cobra" class="col-sm-3 control-label">Ular cobra</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_ular_cobra" name="data[detail][keluarga][jenis_ternak][ular_cobra]" placeholder="jumlah ular cobra" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["ular_cobra"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_burung_onta" class="col-sm-3 control-label">Burung Onta</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_burung_onta" name="data[detail][keluarga][jenis_ternak][burung_onta]" placeholder="jumlah burung onta" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["burung_onta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_ular_pithon" class="col-sm-3 control-label">Ular pithon</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_ular_pithon" name="data[detail][keluarga][jenis_ternak][ular_pithon]" placeholder="jumlah ular pithon" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["ular_pithon"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_burung_cendrawasih" class="col-sm-3 control-label">Burung cendrawasih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_burung_cendrawasih" name="data[detail][keluarga][jenis_ternak][burung_cendrawasih]" placeholder="jumlah burung cendrawasih" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["burung_cendrawasih"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_burung_kakatua" class="col-sm-3 control-label">Burung kakatua</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_burung_kakatua" name="data[detail][keluarga][jenis_ternak][burung_kakatua]" placeholder="jumlah burung kakatua" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["burung_kakatua"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_burung_beo" class="col-sm-3 control-label">Burung beo</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_burung_beo" name="data[detail][keluarga][jenis_ternak][burung_beo]" placeholder="jumlah burung beo" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["burung_beo"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_burung_merak" class="col-sm-3 control-label">Burung merak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_burung_merak" name="data[detail][keluarga][jenis_ternak][burung_merak]" placeholder="jumlah burung merak" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["burung_merak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_burung_langka_lainnya" class="col-sm-3 control-label">Burung langka lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_burung_langka_lainnya" name="data[detail][keluarga][jenis_ternak][burung_langka_lainnya]" placeholder="jumlah burung langka lainnya" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["burung_langka_lainnya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_buaya" class="col-sm-3 control-label">Buaya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_buaya" name="data[detail][keluarga][jenis_ternak][buaya]" placeholder="jumlah buaya" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["buaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_jenis_ternak_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_jenis_ternak_lainnya" name="data[detail][keluarga][jenis_ternak][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_jenis_ternak_lainnya" name="data[detail][keluarga][jenis_ternak][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["jenis_ternak"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Alat Produksi Budidaya Ikan</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_alat_perikanan_karamba" class="col-sm-3 control-label">Karamba</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_alat_perikanan_karamba" name="data[detail][keluarga][alat_perikanan][karamba]" placeholder="jumlah karamba" value="<?php echo $ddk->detail["keluarga"]["alat_perikanan"]["karamba"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_alat_perikanan_tambak" class="col-sm-3 control-label">Tambak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_alat_perikanan_tambak" name="data[detail][keluarga][alat_perikanan][tambak]" placeholder="jumlah tambak" value="<?php echo $ddk->detail["keluarga"]["alat_perikanan"]["tambak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_alat_perikanan_jermal" class="col-sm-3 control-label">Jermal</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_alat_perikanan_jermal" name="data[detail][keluarga][alat_perikanan][jermal]" placeholder="jumlah jermal" value="<?php echo $ddk->detail["keluarga"]["alat_perikanan"]["jermal"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_alat_perikanan_pancing" class="col-sm-3 control-label">Pancing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_alat_perikanan_pancing" name="data[detail][keluarga][alat_perikanan][pancing]" placeholder="jumlah pancing" value="<?php echo $ddk->detail["keluarga"]["alat_perikanan"]["pancing"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_alat_perikanan_pukat" class="col-sm-3 control-label">Pukat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_alat_perikanan_pukat" name="data[detail][keluarga][alat_perikanan][pukat]" placeholder="jumlah pukat" value="<?php echo $ddk->detail["keluarga"]["alat_perikanan"]["pukat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_alat_perikanan_jala" class="col-sm-3 control-label">Jala</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_alat_perikanan_jala" name="data[detail][keluarga][alat_perikanan][jala]" placeholder="jumlah jala" value="<?php echo $ddk->detail["keluarga"]["alat_perikanan"]["jala"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_alat_perikanan_lainnya1" class="col-sm-3 control-label">Peralatan Lainnya 1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_alat_perikanan_lainnya1" name="data[detail][keluarga][alat_perikanan][lainnya1][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["alat_perikanan"]["lainnya1"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_alat_perikanan_lainnya1" name="data[detail][keluarga][alat_perikanan][lainnya1][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["alat_perikanan"]["lainnya1"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_alat_perikanan_lainnya2" class="col-sm-3 control-label">Peralatan Lainnya 2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_alat_perikanan_lainnya2" name="data[detail][keluarga][alat_perikanan][lainnya2][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["alat_perikanan"]["lainnya2"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_alat_perikanan_lainnya2" name="data[detail][keluarga][alat_perikanan][lainnya2][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["alat_perikanan"]["lainnya2"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Pemanfaatan Danau/Sungai/Waduk/Situ/Mata Air oleh Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pemanfaatan_air_usaha_perikanan" class="col-sm-3 control-label">Usaha Perikanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pemanfaatan_air_usaha_perikanan" name="data[detail][keluarga][pemanfaatan_air][usaha_perikanan]" placeholder="jumlah usaha perikanan" value="<?php echo $ddk->detail["keluarga"]["pemanfaatan_air"]["usaha_perikanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pemanfaatan_air_air_minum_air_baku" class="col-sm-3 control-label">Air minum/air baku</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pemanfaatan_air_air_minum_air_baku" name="data[detail][keluarga][pemanfaatan_air][air_minum_air_baku]" placeholder="jumlah air minum/air baku" value="<?php echo $ddk->detail["keluarga"]["pemanfaatan_air"]["air_minum_air_baku"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pemanfaatan_air_cuci_dan_mandi" class="col-sm-3 control-label">Cuci dan mandi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pemanfaatan_air_cuci_dan_mandi" name="data[detail][keluarga][pemanfaatan_air][cuci_dan_mandi]" placeholder="jumlah cuci dan mandi" value="<?php echo $ddk->detail["keluarga"]["pemanfaatan_air"]["cuci_dan_mandi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pemanfaatan_air_irigasi" class="col-sm-3 control-label">Irigasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pemanfaatan_air_irigasi" name="data[detail][keluarga][pemanfaatan_air][irigasi]" placeholder="jumlah irigasi" value="<?php echo $ddk->detail["keluarga"]["pemanfaatan_air"]["irigasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pemanfaatan_air_buang_air_besar" class="col-sm-3 control-label">Buang air besar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pemanfaatan_air_buang_air_besar" name="data[detail][keluarga][pemanfaatan_air][buang_air_besar]" placeholder="jumlah buang air besar" value="<?php echo $ddk->detail["keluarga"]["pemanfaatan_air"]["buang_air_besar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pemanfaatan_air_pembangkit_listrik" class="col-sm-3 control-label">Pembangkit listrik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pemanfaatan_air_pembangkit_listrik" name="data[detail][keluarga][pemanfaatan_air][pembangkit_listrik]" placeholder="jumlah pembangkit listrik" value="<?php echo $ddk->detail["keluarga"]["pemanfaatan_air"]["pembangkit_listrik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pemanfaatan_air_prasarana_transportasi" class="col-sm-3 control-label">Prasarana transportasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pemanfaatan_air_prasarana_transportasi" name="data[detail][keluarga][pemanfaatan_air][prasarana_transportasi]" placeholder="jumlah prasarana transportasi" value="<?php echo $ddk->detail["keluarga"]["pemanfaatan_air"]["prasarana_transportasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pemanfaatan_air_sumber_air_panas" class="col-sm-3 control-label">Sumber air panas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pemanfaatan_air_sumber_air_panas" name="data[detail][keluarga][pemanfaatan_air][sumber_air_panas]" placeholder="jumlah sumber air panas" value="<?php echo $ddk->detail["keluarga"]["pemanfaatan_air"]["sumber_air_panas"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pemanfaatan_air_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pemanfaatan_air_lainnya" name="data[detail][keluarga][pemanfaatan_air][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["pemanfaatan_air"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_pemanfaatan_air_lainnya" name="data[detail][keluarga][pemanfaatan_air][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["pemanfaatan_air"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Lembaga Pendidikan Yang Dimiliki</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_tk_preschool_play_group" class="col-sm-3 control-label">TK/Preschool/Play Group</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_tk_preschool_play_group" name="data[detail][keluarga][lembaga_dimiliki][tk_preschool_play_group]" placeholder="tk/preschool/play group" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["tk_preschool_play_group"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_sd_sederajat" class="col-sm-3 control-label">SD/Sederajat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_sd_sederajat" name="data[detail][keluarga][lembaga_dimiliki][sd_sederajat]" placeholder="sd/sederajat" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["sd_sederajat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_smp_sederajat" class="col-sm-3 control-label">SMP/Sederajat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_smp_sederajat" name="data[detail][keluarga][lembaga_dimiliki][smp_sederajat]" placeholder="smp/sederajat" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["smp_sederajat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_sma_sederajat" class="col-sm-3 control-label">SMA/Sederajat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_sma_sederajat" name="data[detail][keluarga][lembaga_dimiliki][sma_sederajat]" placeholder="sma/sederajat" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["sma_sederajat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_perguruan_tinggi" class="col-sm-3 control-label">Perguruan Tinggi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_perguruan_tinggi" name="data[detail][keluarga][lembaga_dimiliki][perguruan_tinggi]" placeholder="perguruan tinggi" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["perguruan_tinggi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_pondok_pesantren" class="col-sm-3 control-label">Pondok Pesantren</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_pondok_pesantren" name="data[detail][keluarga][lembaga_dimiliki][pondok_pesantren]" placeholder="pondok pesantren" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["pondok_pesantren"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_taman_pendidikan_alquran" class="col-sm-3 control-label">Taman Pendidikan Alqur’an</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_taman_pendidikan_alquran" name="data[detail][keluarga][lembaga_dimiliki][taman_pendidikan_alquran]" placeholder="taman pendidikan alqur’an" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["taman_pendidikan_alquran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_rhaudatul_athfal" class="col-sm-3 control-label">Rhaudatul Athfal (Tk)</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_rhaudatul_athfal" name="data[detail][keluarga][lembaga_dimiliki][rhaudatul_athfal]" placeholder="rhaudatul athfal (tk)" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["rhaudatul_athfal"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_madrasah_ibtidaiyah" class="col-sm-3 control-label">Madrasah Ibtidaiyah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_madrasah_ibtidaiyah" name="data[detail][keluarga][lembaga_dimiliki][madrasah_ibtidaiyah]" placeholder="madrasah ibtidaiyah" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["madrasah_ibtidaiyah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_madrasah_tsanawiyah" class="col-sm-3 control-label">Madrasah Tsanawiyah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_madrasah_tsanawiyah" name="data[detail][keluarga][lembaga_dimiliki][madrasah_tsanawiyah]" placeholder="madrasah tsanawiyah" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["madrasah_tsanawiyah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_madrasah_aliyah" class="col-sm-3 control-label">Madrasah Aliyah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_madrasah_aliyah" name="data[detail][keluarga][lembaga_dimiliki][madrasah_aliyah]" placeholder="madrasah aliyah" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["madrasah_aliyah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_sekolah_tinggi_agama_islam" class="col-sm-3 control-label">Sekolah Tinggi Agama Islam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_sekolah_tinggi_agama_islam" name="data[detail][keluarga][lembaga_dimiliki][sekolah_tinggi_agama_islam]" placeholder="sekolah tinggi agama islam" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["sekolah_tinggi_agama_islam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_universitas_swasta_islam" class="col-sm-3 control-label">Universitas Swasta Islam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_universitas_swasta_islam" name="data[detail][keluarga][lembaga_dimiliki][universitas_swasta_islam]" placeholder="universitas swasta islam" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["universitas_swasta_islam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_seminari_menengah" class="col-sm-3 control-label">Seminari Menengah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_seminari_menengah" name="data[detail][keluarga][lembaga_dimiliki][seminari_menengah]" placeholder="seminari menengah" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["seminari_menengah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_seminari_tinggi" class="col-sm-3 control-label">Seminari Tinggi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_seminari_tinggi" name="data[detail][keluarga][lembaga_dimiliki][seminari_tinggi]" placeholder="seminari tinggi" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["seminari_tinggi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_biara" class="col-sm-3 control-label">Biara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_biara" name="data[detail][keluarga][lembaga_dimiliki][biara]" placeholder="biara" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["biara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_perguruan_tinggi_swasta_katolik" class="col-sm-3 control-label">Perguruan Tinggi Swasta Katolik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_perguruan_tinggi_swasta_katolik" name="data[detail][keluarga][lembaga_dimiliki][perguruan_tinggi_swasta_katolik]" placeholder="perguruan tinggi swasta katolik" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["perguruan_tinggi_swasta_katolik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_sekolah_dasar_swasta_katolik" class="col-sm-3 control-label">Sekolah Dasar Swasta Katolik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_sekolah_dasar_swasta_katolik" name="data[detail][keluarga][lembaga_dimiliki][sekolah_dasar_swasta_katolik]" placeholder="sekolah dasar swasta katolik" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["sekolah_dasar_swasta_katolik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_sltp_swasta_katolik" class="col-sm-3 control-label">SLTP Swasta Katolik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_sltp_swasta_katolik" name="data[detail][keluarga][lembaga_dimiliki][sltp_swasta_katolik]" placeholder="sltp swasta katolik" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["sltp_swasta_katolik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_slta_swasta_katolik" class="col-sm-3 control-label">SLTA Swasta Katolik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_slta_swasta_katolik" name="data[detail][keluarga][lembaga_dimiliki][slta_swasta_katolik]" placeholder="slta swasta katolik" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["slta_swasta_katolik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_lembaga_kursus_keterampilan_swasta_katolik" class="col-sm-3 control-label">Lembaga Kursus Keterampilan Swasta Katolik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_lembaga_kursus_keterampilan_swasta_katolik" name="data[detail][keluarga][lembaga_dimiliki][lembaga_kursus_keterampilan_swasta_katolik]" placeholder="lembaga kursus keterampilan swasta katolik" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["lembaga_kursus_keterampilan_swasta_katolik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_lembaga_pendidikan_swasta_kristen_protestan" class="col-sm-3 control-label">Lembaga Pendidikan Swasta Kristen Protestan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_lembaga_pendidikan_swasta_kristen_protestan" name="data[detail][keluarga][lembaga_dimiliki][lembaga_pendidikan_swasta_kristen_protestan]" placeholder="lembaga pendidikan swasta kristen protestan" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["lembaga_pendidikan_swasta_kristen_protestan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_lembaga_pendidikan_swasta_hindu" class="col-sm-3 control-label">Lembaga Pendidikan Swasta Hindu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_lembaga_pendidikan_swasta_hindu" name="data[detail][keluarga][lembaga_dimiliki][lembaga_pendidikan_swasta_hindu]" placeholder="lembaga pendidikan swasta hindu" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["lembaga_pendidikan_swasta_hindu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_lembaga_pendidikan_swasta_budha" class="col-sm-3 control-label">Lembaga Pendidikan Swasta Budha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_lembaga_pendidikan_swasta_budha" name="data[detail][keluarga][lembaga_dimiliki][lembaga_pendidikan_swasta_budha]" placeholder="lembaga pendidikan swasta budha" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["lembaga_pendidikan_swasta_budha"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_lembaga_pendidikan_swasta_konghucu" class="col-sm-3 control-label">Lembaga Pendidikan Swasta Konghucu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_lembaga_pendidikan_swasta_konghucu" name="data[detail][keluarga][lembaga_dimiliki][lembaga_pendidikan_swasta_konghucu]" placeholder="lembaga pendidikan swasta konghucu" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["lembaga_pendidikan_swasta_konghucu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_kursus_bahasa" class="col-sm-3 control-label">Kursus Bahasa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_kursus_bahasa" name="data[detail][keluarga][lembaga_dimiliki][kursus_bahasa]" placeholder="kursus bahasa" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["kursus_bahasa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_kursus_menjahit" class="col-sm-3 control-label">Kursus Menjahit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_kursus_menjahit" name="data[detail][keluarga][lembaga_dimiliki][kursus_menjahit]" placeholder="kursus menjahit" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["kursus_menjahit"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_kursus_montir" class="col-sm-3 control-label">Kursus Montir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_kursus_montir" name="data[detail][keluarga][lembaga_dimiliki][kursus_montir]" placeholder="kursus montir" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["kursus_montir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_kursus_komputer" class="col-sm-3 control-label">Kursus Komputer</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_kursus_komputer" name="data[detail][keluarga][lembaga_dimiliki][kursus_komputer]" placeholder="kursus komputer" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["kursus_komputer"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_kursus_mengemudi" class="col-sm-3 control-label">Kursus Mengemudi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_kursus_mengemudi" name="data[detail][keluarga][lembaga_dimiliki][kursus_mengemudi]" placeholder="kursus mengemudi" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["kursus_mengemudi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_kursus_satpam" class="col-sm-3 control-label">Kursus Satpam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_kursus_satpam" name="data[detail][keluarga][lembaga_dimiliki][kursus_satpam]" placeholder="kursus satpam" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["kursus_satpam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_lembaga_dimiliki_kursus_bela_diri" class="col-sm-3 control-label">Kursus Bela Diri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_lembaga_dimiliki_kursus_bela_diri" name="data[detail][keluarga][lembaga_dimiliki][kursus_bela_diri]" placeholder="kursus bela diri" value="<?php echo $ddk->detail["keluarga"]["lembaga_dimiliki"]["kursus_bela_diri"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Penguasaan Aset Tanah oleh Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_tidak" class="col-sm-3 control-label">Tidak memiliki tanah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_tidak" name="data[detail][keluarga][aset_tanah][tidak]" placeholder="tidak memiliki tanah" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"]["tidak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_1" class="col-sm-3 control-label">Memiliki tanah antara 0,1 - 0,2 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_1" name="data[detail][keluarga][aset_tanah][1]" placeholder="memiliki tanah antara 0,1 - 0,2 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][1] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_2" class="col-sm-3 control-label">Memiliki tanah antara 0,21 - 0,3 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_2" name="data[detail][keluarga][aset_tanah][2]" placeholder="memiliki tanah antara 0,21 - 0,3 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][2] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_3" class="col-sm-3 control-label">Memiliki tanah antara 0,31 - 0,4 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_3" name="data[detail][keluarga][aset_tanah][3]" placeholder="memiliki tanah antara 0,31 - 0,4 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][3] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_4" class="col-sm-3 control-label">Memiliki tanah antara 0,41 - 0,5 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_4" name="data[detail][keluarga][aset_tanah][4]" placeholder="memiliki tanah antara 0,41 - 0,5 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][4] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_5" class="col-sm-3 control-label">Memiliki tanah antara 0,51 - 0,6 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_5" name="data[detail][keluarga][aset_tanah][4]" placeholder="memiliki tanah antara 0,51 - 0,6 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][4] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_6" class="col-sm-3 control-label">Memiliki tanah antara 0,61 - 0,7 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_6" name="data[detail][keluarga][aset_tanah][6]" placeholder="memiliki tanah antara 0,61 - 0,7 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][6] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_7" class="col-sm-3 control-label">Memiliki tanah antara 0,71 - 0,8 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_7" name="data[detail][keluarga][aset_tanah][7]" placeholder="memiliki tanah antara 0,71 - 0,8 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][7] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_8" class="col-sm-3 control-label">Memiliki tanah antara 0,81 - 0,9 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_8" name="data[detail][keluarga][aset_tanah][8]" placeholder="memiliki tanah antara 0,81 - 0,9 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][8] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_9" class="col-sm-3 control-label">Memiliki tanah antara 0,91 - 1,0 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_9" name="data[detail][keluarga][aset_tanah][9]" placeholder="memiliki tanah antara 0,91 - 1,0 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][9] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_10" class="col-sm-3 control-label">Memiliki tanah antara 1,0 - 5,0 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_10" name="data[detail][keluarga][aset_tanah][10]" placeholder="memiliki tanah antara 1,0 - 5,0 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][10] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_tanah_11" class="col-sm-3 control-label">Memilliki tanah lebih dari 5,0 ha</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_tanah_11" name="data[detail][keluarga][aset_tanah][11]" placeholder="memilliki tanah lebih dari 5,0 ha" value="<?php echo $ddk->detail["keluarga"]["aset_tanah"][11] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Aset Sarana Transportasi Umum</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_transportasi_motor" class="col-sm-3 control-label">Memiliki ojek motor/sepeda motor/bentor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_transportasi_motor" name="data[detail][keluarga][aset_transportasi][motor]" placeholder="memiliki ojek motor/sepeda motor/bentor" value="<?php echo $ddk->detail["keluarga"]["aset_transportasi"]["motor"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_transportasi_becak" class="col-sm-3 control-label">Memiliki becak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_transportasi_becak" name="data[detail][keluarga][aset_transportasi][becak]" placeholder="memiliki becak" value="<?php echo $ddk->detail["keluarga"]["aset_transportasi"]["becak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_transportasi_cidemo" class="col-sm-3 control-label">Memiliki cidemo/andong/dokar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_transportasi_cidemo" name="data[detail][keluarga][aset_transportasi][cidemo]" placeholder="memiliki cidemo/andong/dokar" value="<?php echo $ddk->detail["keluarga"]["aset_transportasi"]["cidemo"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_transportasi_perahu" class="col-sm-3 control-label">Memiliki perahu tidak bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_transportasi_perahu" name="data[detail][keluarga][aset_transportasi][perahu]" placeholder="memiliki perahu tidak bermotor" value="<?php echo $ddk->detail["keluarga"]["aset_transportasi"]["perahu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_transportasi_tongkang" class="col-sm-3 control-label">Memiliki tongkang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_transportasi_tongkang" name="data[detail][keluarga][aset_transportasi][tongkang]" placeholder="memiliki tongkang" value="<?php echo $ddk->detail["keluarga"]["aset_transportasi"]["tongkang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_transportasi_bus" class="col-sm-3 control-label">Memiliki bus penumpang/angkutan orang/barang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_transportasi_bus" name="data[detail][keluarga][aset_transportasi][bus]" placeholder="memiliki bus penumpang/angkutan orang/barang" value="<?php echo $ddk->detail["keluarga"]["aset_transportasi"]["bus"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_transportasi_sepeda" class="col-sm-3 control-label">Memiliki sepeda dayung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_transportasi_sepeda" name="data[detail][keluarga][aset_transportasi][sepeda]" placeholder="memiliki sepeda dayung" value="<?php echo $ddk->detail["keluarga"]["aset_transportasi"]["sepeda"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_transportasi_bajaj" class="col-sm-3 control-label">Memiliki bajaj/kancil</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_transportasi_bajaj" name="data[detail][keluarga][aset_transportasi][bajaj]" placeholder="memiliki bajaj/kancil" value="<?php echo $ddk->detail["keluarga"]["aset_transportasi"]["bajaj"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_transportasi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_transportasi_lainnya" name="data[detail][keluarga][aset_transportasi][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_transportasi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_aset_transportasi_lainnya" name="data[detail][keluarga][aset_transportasi][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_transportasi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Aset Sarana Produksi</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_padi" class="col-sm-3 control-label">Memiliki penggilingan padi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_padi" name="data[detail][keluarga][aset_produksi][padi]" placeholder="memiliki penggilingan padi" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["padi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_traktor" class="col-sm-3 control-label">Memiliki traktor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_traktor" name="data[detail][keluarga][aset_produksi][traktor]" placeholder="memiliki traktor" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["traktor"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_pertanian" class="col-sm-3 control-label">Memiliki pabrik pengolahan hasil pertanian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_pertanian" name="data[detail][keluarga][aset_produksi][pertanian]" placeholder="memiliki pabrik pengolahan hasil pertanian" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["pertanian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_kapal" class="col-sm-3 control-label">Memiliki kapal penangkap ikan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_kapal" name="data[detail][keluarga][aset_produksi][kapal]" placeholder="memiliki kapal penangkap ikan" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["kapal"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_perikanan" class="col-sm-3 control-label">Memiliki alat pengolahan hasil perikanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_perikanan" name="data[detail][keluarga][aset_produksi][perikanan]" placeholder="memiliki alat pengolahan hasil perikanan" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["perikanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_peternakan" class="col-sm-3 control-label">Memiliki alat pengolahan hasil peternakan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_peternakan" name="data[detail][keluarga][aset_produksi][peternakan]" placeholder="memiliki alat pengolahan hasil peternakan" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["peternakan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_perkebunan" class="col-sm-3 control-label">Memiliki alat pengolahan hasil perkebunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_perkebunan" name="data[detail][keluarga][aset_produksi][perkebunan]" placeholder="memiliki alat pengolahan hasil perkebunan" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["perkebunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_hutan" class="col-sm-3 control-label">Memiliki alat pengolahan hasil hutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_hutan" name="data[detail][keluarga][aset_produksi][hutan]" placeholder="memiliki alat pengolahan hasil hutan" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["hutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_pertambangan" class="col-sm-3 control-label">Memiliki alat produksi dan pengolahan hasil pertambangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_pertambangan" name="data[detail][keluarga][aset_produksi][pertambangan]" placeholder="memiliki alat produksi dan pengolahan hasil pertambangan" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["pertambangan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_kerajinan" class="col-sm-3 control-label">Memiliki alat produksi dan pengolahan hasil Industri kerajinan keluarga skala kecil dan menengah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_kerajinan" name="data[detail][keluarga][aset_produksi][kerajinan]" placeholder="memiliki alat produksi dan pengolahan hasil industri kerajinan keluarga skala kecil dan menengah" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["kerajinan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_gas" class="col-sm-3 control-label">Memiliki alat produksi dan pengolahan hasil industri bahan bakar dan gas skala rumah tangga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_gas" name="data[detail][keluarga][aset_produksi][gas]" placeholder="memiliki alat produksi dan pengolahan hasil industri bahan bakar dan gas skala rumah tangga" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["gas"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_produksi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_produksi_lainnya" name="data[detail][keluarga][aset_produksi][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_aset_produksi_lainnya" name="data[detail][keluarga][aset_produksi][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_produksi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Aset Perumahan</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_tembok" class="col-sm-3 control-label">Tembok</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_tembok" name="data[detail][keluarga][aset_perumahan][dinding][tembok]" placeholder="tembok" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["dinding"]["tembok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_kayu" class="col-sm-3 control-label">Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_kayu" name="data[detail][keluarga][aset_perumahan][dinding][kayu]" placeholder="kayu" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["dinding"]["kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_bambu" class="col-sm-3 control-label">Bambu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_bambu" name="data[detail][keluarga][aset_perumahan][dinding][bambu]" placeholder="bambu" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["dinding"]["bambu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_tanah_liat" class="col-sm-3 control-label">Tanah liat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_tanah_liat" name="data[detail][keluarga][aset_perumahan][dinding][tanah_liat]" placeholder="tanah liat" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["dinding"]["tanah_liat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_pelepah_kelapa" class="col-sm-3 control-label">Pelepah kelapa/lontar/gebang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_pelepah_kelapa" name="data[detail][keluarga][aset_perumahan][dinding][pelepah_kelapa]" placeholder="pelepah kelapa/lontar/gebang" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["dinding"]["pelepah_kelapa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_dedaunan" class="col-sm-3 control-label">Dedaunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_dedaunan" name="data[detail][keluarga][aset_perumahan][dinding][dedaunan]" placeholder="dedaunan" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["dinding"]["dedaunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_keramik" class="col-sm-3 control-label">Keramik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_keramik" name="data[detail][keluarga][aset_perumahan][lantai][keramik]" placeholder="keramik" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["lantai"]["keramik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_semen" class="col-sm-3 control-label">Semen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_semen" name="data[detail][keluarga][aset_perumahan][lantai][semen]" placeholder="semen" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["lantai"]["semen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_kayu" class="col-sm-3 control-label">Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_kayu" name="data[detail][keluarga][aset_perumahan][lantai][kayu]" placeholder="kayu" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["lantai"]["kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_tanah" class="col-sm-3 control-label">Tanah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_tanah" name="data[detail][keluarga][aset_perumahan][lantai][tanah]" placeholder="tanah" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["lantai"]["tanah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_genteng" class="col-sm-3 control-label">Genteng</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_genteng" name="data[detail][keluarga][aset_perumahan][atap][genteng]" placeholder="genteng" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["atap"]["genteng"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_seng" class="col-sm-3 control-label">Seng</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_seng" name="data[detail][keluarga][aset_perumahan][atap][seng]" placeholder="seng" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["atap"]["seng"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_asbes" class="col-sm-3 control-label">Asbes</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_asbes" name="data[detail][keluarga][aset_perumahan][atap][asbes]" placeholder="asbes" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["atap"]["asbes"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_beton" class="col-sm-3 control-label">Beton</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_beton" name="data[detail][keluarga][aset_perumahan][atap][beton]" placeholder="beton" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["atap"]["beton"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_bambu" class="col-sm-3 control-label">Bambu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_bambu" name="data[detail][keluarga][aset_perumahan][atap][bambu]" placeholder="bambu" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["atap"]["bambu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_kayu" class="col-sm-3 control-label">Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_kayu" name="data[detail][keluarga][aset_perumahan][atap][kayu]" placeholder="kayu" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["atap"]["kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_daun_lontar" class="col-sm-3 control-label">Daun lontar/gebang/enau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_daun_lontar" name="data[detail][keluarga][aset_perumahan][atap][daun_lontar]" placeholder="daun lontar/gebang/enau" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["atap"]["daun_lontar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_perumahan_daun_ilalang" class="col-sm-3 control-label">Daun ilalang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_perumahan_daun_ilalang" name="data[detail][keluarga][aset_perumahan][atap][daun_ilalang]" placeholder="daun ilalang" value="<?php echo $ddk->detail["keluarga"]["aset_perumahan"]["atap"]["daun_ilalang"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Aset Lainnya dalam Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_elektronik" class="col-sm-3 control-label">Memiliki TV dan elektronik sejenis lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_elektronik" name="data[detail][keluarga][aset_lain][elektronik]" placeholder="memiliki tv dan elektronik sejenis lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_motor" class="col-sm-3 control-label">Memiliki sepeda motor pribadi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_motor" name="data[detail][keluarga][aset_lain][motor]" placeholder="memiliki sepeda motor pribadi" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["motor"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_mobil" class="col-sm-3 control-label">Memiliki mobil pribadi dan sejenisnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_mobil" name="data[detail][keluarga][aset_lain][mobil]" placeholder="memiliki mobil pribadi dan sejenisnya" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["mobil"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_perahu" class="col-sm-3 control-label">Memiliki perahu bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_perahu" name="data[detail][keluarga][aset_lain][perahu]" placeholder="memiliki perahu bermotor" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["perahu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_kapal_barang" class="col-sm-3 control-label">Memiliki kapal barang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_kapal_barang" name="data[detail][keluarga][aset_lain][kapal_barang]" placeholder="memiliki kapal barang" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["kapal_barang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_kapal_penumpang" class="col-sm-3 control-label">Memiliki kapal penumpang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_kapal_penumpang" name="data[detail][keluarga][aset_lain][kapal_penumpang]" placeholder="memiliki kapal penumpang" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["kapal_penumpang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_kapal_pesiar" class="col-sm-3 control-label">Memiliki kapal pesiar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_kapal_pesiar" name="data[detail][keluarga][aset_lain][kapal_pesiar]" placeholder="memiliki kapal pesiar" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["kapal_pesiar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_helikopter" class="col-sm-3 control-label">Memiliki/menyewa helikopter pribadi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_helikopter" name="data[detail][keluarga][aset_lain][helikopter]" placeholder="memiliki/menyewa helikopter pribadi" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["helikopter"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_pesawat_terbang" class="col-sm-3 control-label">Memiliki/menyewa pesawat terbang pribadi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_pesawat_terbang" name="data[detail][keluarga][aset_lain][pesawat_terbang]" placeholder="memiliki/menyewa pesawat terbang pribadi" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["pesawat_terbang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_ternak_besar" class="col-sm-3 control-label">Memiliki ternak besar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_ternak_besar" name="data[detail][keluarga][aset_lain][ternak_besar]" placeholder="memiliki ternak besar" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["ternak_besar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_ternak_kecil" class="col-sm-3 control-label">Memiliki ternak kecil</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_ternak_kecil" name="data[detail][keluarga][aset_lain][ternak_kecil]" placeholder="memiliki ternak kecil" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["ternak_kecil"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_emas_berlian" class="col-sm-3 control-label">Memiliki hiasan emas/berlian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_emas_berlian" name="data[detail][keluarga][aset_lain][emas_berlian]" placeholder="memiliki hiasan emas/berlian" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["emas_berlian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_tabungan_bank" class="col-sm-3 control-label">Memiliki buku tabungan bank</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_tabungan_bank" name="data[detail][keluarga][aset_lain][tabungan_bank]" placeholder="memiliki buku tabungan bank" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["tabungan_bank"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_surat_berharga" class="col-sm-3 control-label">Memiliki buku surat berharga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_surat_berharga" name="data[detail][keluarga][aset_lain][surat_berharga]" placeholder="memiliki buku surat berharga" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["surat_berharga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_deposito" class="col-sm-3 control-label">Memiliki sertifikat deposito</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_deposito" name="data[detail][keluarga][aset_lain][deposito]" placeholder="memiliki sertifikat deposito" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["deposito"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_tanah" class="col-sm-3 control-label">Memiliki sertifikat tanah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_tanah" name="data[detail][keluarga][aset_lain][tanah]" placeholder="memiliki sertifikat tanah" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["tanah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_bangunan" class="col-sm-3 control-label">Memiliki sertifikat bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_bangunan" name="data[detail][keluarga][aset_lain][bangunan]" placeholder="memiliki sertifikat bangunan" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["bangunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_industri_besar" class="col-sm-3 control-label">Memiliki perusahaan industri besar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_industri_besar" name="data[detail][keluarga][aset_lain][industri_besar]" placeholder="memiliki perusahaan industri besar" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["industri_besar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_industri_menengah" class="col-sm-3 control-label">Memiliki perusahaan industri menengah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_industri_menengah" name="data[detail][keluarga][aset_lain][industri_menengah]" placeholder="memiliki perusahaan industri menengah" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["industri_menengah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_industri_kecil" class="col-sm-3 control-label">Memiliki perusahaan industri kecil</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_industri_kecil" name="data[detail][keluarga][aset_lain][industri_kecil]" placeholder="memiliki perusahaan industri kecil" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["industri_kecil"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_perikanan" class="col-sm-3 control-label">Memiliki usaha perikanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_perikanan" name="data[detail][keluarga][aset_lain][perikanan]" placeholder="memiliki usaha perikanan" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["perikanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_peternakan" class="col-sm-3 control-label">Memiliki usaha peternakan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_peternakan" name="data[detail][keluarga][aset_lain][peternakan]" placeholder="memiliki usaha peternakan" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["peternakan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_perkebunan" class="col-sm-3 control-label">Memiliki usaha perkebunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_perkebunan" name="data[detail][keluarga][aset_lain][perkebunan]" placeholder="memiliki usaha perkebunan" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["perkebunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_pasar_swalayan" class="col-sm-3 control-label">Memiliki usaha pasar swalayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_pasar_swalayan" name="data[detail][keluarga][aset_lain][pasar_swalayan]" placeholder="memiliki usaha pasar swalayan" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["pasar_swalayan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_di_pasar_swalayan" class="col-sm-3 control-label">Memiliki usaha di pasar swalayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_di_pasar_swalayan" name="data[detail][keluarga][aset_lain][di_pasar_swalayan]" placeholder="memiliki usaha di pasar swalayan" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["di_pasar_swalayan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_di_pasar_tradisional" class="col-sm-3 control-label">Memiliki usaha di pasar tradisional</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_di_pasar_tradisional" name="data[detail][keluarga][aset_lain][di_pasar_tradisional]" placeholder="memiliki usaha di pasar tradisional" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["di_pasar_tradisional"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_di_pasar_desa" class="col-sm-3 control-label">Memiliki usaha di pasar desa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_di_pasar_desa" name="data[detail][keluarga][aset_lain][di_pasar_desa]" placeholder="memiliki usaha di pasar desa" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["di_pasar_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_transportasi" class="col-sm-3 control-label">Memiliki usaha transportasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_transportasi" name="data[detail][keluarga][aset_lain][transportasi]" placeholder="memiliki usaha transportasi" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["transportasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_saham_perusahaan" class="col-sm-3 control-label">Memiliki saham di perusahaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_saham_perusahaan" name="data[detail][keluarga][aset_lain][saham_perusahaan]" placeholder="memiliki saham di perusahaan" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["saham_perusahaan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_pelanggan_telkom" class="col-sm-3 control-label">Pelanggan Telkom</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_pelanggan_telkom" name="data[detail][keluarga][aset_lain][pelanggan_telkom]" placeholder="pelanggan telkom" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["pelanggan_telkom"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_hp_gsm" class="col-sm-3 control-label">Memiliki HP GSM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_hp_gsm" name="data[detail][keluarga][aset_lain][hp_gsm]" placeholder="memiliki hp gsm" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["hp_gsm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_hp_cdma" class="col-sm-3 control-label">Memiliki HP CDMA</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_hp_cdma" name="data[detail][keluarga][aset_lain][hp_cdma]" placeholder="memiliki hp cdma" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["hp_cdma"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_wartel" class="col-sm-3 control-label">Memiliki Usaha Wartel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_wartel" name="data[detail][keluarga][aset_lain][wartel]" placeholder="memiliki usaha wartel" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["wartel"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_parabola" class="col-sm-3 control-label">Memiliki parabola</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_parabola" name="data[detail][keluarga][aset_lain][parabola]" placeholder="memiliki parabola" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["parabola"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_koran_majalah" class="col-sm-3 control-label">Berlangganan koran/majalah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_koran_majalah" name="data[detail][keluarga][aset_lain][koran_majalah]" placeholder="berlangganan koran/majalah" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["koran_majalah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_lainnya1" class="col-sm-3 control-label">Lainnya 1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_lainnya1" name="data[detail][keluarga][aset_lain][lainnya1][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["lainnya1"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_aset_lain_lainnya1" name="data[detail][keluarga][aset_lain][lainnya1][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["lainnya1"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_lainnya2" class="col-sm-3 control-label">Lainnya 2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_lainnya2" name="data[detail][keluarga][aset_lain][lainnya2][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["lainnya2"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_aset_lain_lainnya2" name="data[detail][keluarga][aset_lain][lainnya2][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["lainnya2"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_aset_lain_lainnya3" class="col-sm-3 control-label">Lainnya 3</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_aset_lain_lainnya3" name="data[detail][keluarga][aset_lain][lainnya3][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["lainnya3"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_aset_lain_lainnya3" name="data[detail][keluarga][aset_lain][lainnya3][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["aset_lain"]["lainnya3"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Kualitas Ibu Hamil dalam Keluarga (jika ada/pernah ada ibu hamil/nifas)</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_posyandu" class="col-sm-3 control-label">Ibu hamil periksa di Posyandu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_posyandu" name="data[detail][keluarga][kualitas_ibu_hamil][posyandu]" placeholder="ibu hamil periksa di posyandu" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["posyandu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_puskesmas" class="col-sm-3 control-label">Ibu hamil periksa di Puskesmas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_puskesmas" name="data[detail][keluarga][kualitas_ibu_hamil][puskesmas]" placeholder="ibu hamil periksa di puskesmas" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["puskesmas"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_rumah_sakit" class="col-sm-3 control-label">Ibu hamil periksa di Rumah Sakit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_rumah_sakit" name="data[detail][keluarga][kualitas_ibu_hamil][rumah_sakit]" placeholder="ibu hamil periksa di rumah sakit" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["rumah_sakit"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_dokter_praktek" class="col-sm-3 control-label">Ibu hamil periksa di Dokter Praktek</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_dokter_praktek" name="data[detail][keluarga][kualitas_ibu_hamil][dokter_praktek]" placeholder="ibu hamil periksa di dokter praktek" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["dokter_praktek"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_bidan_praktek" class="col-sm-3 control-label">Ibu hamil periksa di Bidan Praktek</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_bidan_praktek" name="data[detail][keluarga][kualitas_ibu_hamil][bidan_praktek]" placeholder="ibu hamil periksa di bidan praktek" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["bidan_praktek"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_dukun_terlatih" class="col-sm-3 control-label">Ibu hamil periksa di Dukun Terlatih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_dukun_terlatih" name="data[detail][keluarga][kualitas_ibu_hamil][dukun_terlatih]" placeholder="ibu hamil periksa di dukun terlatih" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["dukun_terlatih"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_tidak_periksa" class="col-sm-3 control-label">Ibu hamil tidak periksa kesehatan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_tidak_periksa" name="data[detail][keluarga][kualitas_ibu_hamil][tidak_periksa]" placeholder="ibu hamil tidak periksa kesehatan" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["tidak_periksa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_yang_meninggal" class="col-sm-3 control-label">Ibu hamil yang meninggal</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_yang_meninggal" name="data[detail][keluarga][kualitas_ibu_hamil][yang_meninggal]" placeholder="ibu hamil yang meninggal" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["yang_meninggal"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_melahirkan" class="col-sm-3 control-label">Ibu hamil melahirkan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_melahirkan" name="data[detail][keluarga][kualitas_ibu_hamil][melahirkan]" placeholder="ibu hamil melahirkan" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["melahirkan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_nifas_sakit" class="col-sm-3 control-label">Ibu nifas sakit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_nifas_sakit" name="data[detail][keluarga][kualitas_ibu_hamil][nifas_sakit]" placeholder="ibu nifas sakit" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["nifas_sakit"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_kematian_nifas" class="col-sm-3 control-label">Kematian ibu nifas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_kematian_nifas" name="data[detail][keluarga][kualitas_ibu_hamil][kematian_nifas]" placeholder="kematian ibu nifas" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["kematian_nifas"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_nifas_sehat" class="col-sm-3 control-label">Ibu nifas sehat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_nifas_sehat" name="data[detail][keluarga][kualitas_ibu_hamil][nifas_sehat]" placeholder="ibu nifas sehat" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["nifas_sehat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_ibu_hamil_kematian_melahirkan" class="col-sm-3 control-label">Kematian ibu saat melahirkan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_ibu_hamil_kematian_melahirkan" name="data[detail][keluarga][kualitas_ibu_hamil][kematian_melahirkan]" placeholder="kematian ibu saat melahirkan" value="<?php echo $ddk->detail["keluarga"]["kualitas_ibu_hamil"]["kematian_melahirkan"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Kualitas Bayi dalam Keluarga (jika ada/pernah ada)</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_bayi_keguguran" class="col-sm-3 control-label">Keguguran kandungan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_bayi_keguguran" name="data[detail][keluarga][kualitas_bayi][keguguran]" placeholder="keguguran kandungan" value="<?php echo $ddk->detail["keluarga"]["kualitas_bayi"]["keguguran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_bayi_lahir_normal" class="col-sm-3 control-label">Bayi lahir hidup normal</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_bayi_lahir_normal" name="data[detail][keluarga][kualitas_bayi][lahir_normal]" placeholder="bayi lahir hidup normal" value="<?php echo $ddk->detail["keluarga"]["kualitas_bayi"]["lahir_normal"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_bayi_lahir_cacat" class="col-sm-3 control-label">Bayi lahir hidup cacat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_bayi_lahir_cacat" name="data[detail][keluarga][kualitas_bayi][lahir_cacat]" placeholder="bayi lahir hidup cacat" value="<?php echo $ddk->detail["keluarga"]["kualitas_bayi"]["lahir_cacat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_bayi_lahir_mati" class="col-sm-3 control-label">Bayi lahir mati</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_bayi_lahir_mati" name="data[detail][keluarga][kualitas_bayi][lahir_mati]" placeholder="bayi lahir mati" value="<?php echo $ddk->detail["keluarga"]["kualitas_bayi"]["lahir_mati"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_bayi_lahir_berat_kurang" class="col-sm-3 control-label">Bayi lahir berat kurang dari 2,5 kg</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_bayi_lahir_berat_kurang" name="data[detail][keluarga][kualitas_bayi][lahir_berat_kurang]" placeholder="bayi lahir berat kurang dari 2,5 kg" value="<?php echo $ddk->detail["keluarga"]["kualitas_bayi"]["lahir_berat_kurang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_bayi_lahir_berat_lebih" class="col-sm-3 control-label">Bayi lahir berat lebih dari 4 kg</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_bayi_lahir_berat_lebih" name="data[detail][keluarga][kualitas_bayi][lahir_berat_lebih]" placeholder="bayi lahir berat lebih dari 4 kg" value="<?php echo $ddk->detail["keluarga"]["kualitas_bayi"]["lahir_berat_lebih"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_bayi_kelainan" class="col-sm-3 control-label">Bayi 0-5 tahun hidup yang menderita kelainan organ tubuh, fisik dan mental</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_bayi_kelainan" name="data[detail][keluarga][kualitas_bayi][kelainan]" placeholder="bayi 0-5 tahun hidup yang menderita kelainan organ tubuh, fisik dan mental" value="<?php echo $ddk->detail["keluarga"]["kualitas_bayi"]["kelainan"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Kualitas Persalinan dalam Keluarga (jika ada/pernah ada)</strong></h4>
				<h4>Tempat Persalinan</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_rumah_sakit_umum" class="col-sm-3 control-label">Tempat persalinan Rumah Sakit Umum</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_rumah_sakit_umum" name="data[detail][keluarga][kualitas_persalinan][tempat][rumah_sakit_umum]" placeholder="tempat persalinan rumah sakit umum" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["rumah_sakit_umum"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_rumah_bersalin" class="col-sm-3 control-label">Tempat persalinan Rumah Bersalin</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_rumah_bersalin" name="data[detail][keluarga][kualitas_persalinan][tempat][rumah_bersalin]" placeholder="tempat persalinan rumah bersalin" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["rumah_bersalin"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_puskesmas" class="col-sm-3 control-label">Tempat persalinan Puskesmas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_puskesmas" name="data[detail][keluarga][kualitas_persalinan][tempat][puskesmas]" placeholder="tempat persalinan puskesmas" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["puskesmas"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_polindes" class="col-sm-3 control-label">Tempat persalinan Polindes</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_polindes" name="data[detail][keluarga][kualitas_persalinan][tempat][polindes]" placeholder="tempat persalinan polindes" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["polindes"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_balai_kesehatan_ibu_anak" class="col-sm-3 control-label">Tempat persalinan Balai Kesehatan Ibu Anak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_balai_kesehatan_ibu_anak" name="data[detail][keluarga][kualitas_persalinan][tempat][balai_kesehatan_ibu_anak]" placeholder="tempat persalinan balai kesehatan ibu anak" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["balai_kesehatan_ibu_anak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_rumah_praktek_bidan" class="col-sm-3 control-label">Tempat persalinan rumah praktek bidan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_rumah_praktek_bidan" name="data[detail][keluarga][kualitas_persalinan][tempat][rumah_praktek_bidan]" placeholder="tempat persalinan rumah praktek bidan" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["rumah_praktek_bidan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_tempat_praktek_dokter" class="col-sm-3 control-label">Tempat praktek dokter</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_tempat_praktek_dokter" name="data[detail][keluarga][kualitas_persalinan][tempat][tempat_praktek_dokter]" placeholder="tempat praktek dokter" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["tempat_praktek_dokter"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_rumah_dukun" class="col-sm-3 control-label">Rumah dukun</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_rumah_dukun" name="data[detail][keluarga][kualitas_persalinan][tempat][rumah_dukun]" placeholder="rumah dukun" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["rumah_dukun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_rumah_sendiri" class="col-sm-3 control-label">Rumah sendiri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_rumah_sendiri" name="data[detail][keluarga][kualitas_persalinan][tempat][rumah_sendiri]" placeholder="rumah sendiri" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["rumah_sendiri"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_tempat_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_tempat_lainnya" name="data[detail][keluarga][kualitas_persalinan][tempat][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_tempat_lainnya" name="data[detail][keluarga][kualitas_persalinan][tempat][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["tempat"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<div class="col-md-12">
				<h4>Pertolongan Persalinan</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_dokter" class="col-sm-3 control-label">Jumlah Persalinan ditolong Dokter</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_dokter" name="data[detail][keluarga][kualitas_persalinan][pertolongan][dokter]" placeholder="jumlah persalinan ditolong dokter" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["pertolongan"]["dokter"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_bidan" class="col-sm-3 control-label">Jumlah persalinan ditolong bidan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_bidan" name="data[detail][keluarga][kualitas_persalinan][pertolongan][bidan]" placeholder="jumlah persalinan ditolong bidan" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["pertolongan"]["bidan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_perawat" class="col-sm-3 control-label">Jumlah persalinan ditolong perawat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_perawat" name="data[detail][keluarga][kualitas_persalinan][pertolongan][perawat]" placeholder="jumlah persalinan ditolong perawat" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["pertolongan"]["perawat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_dukun_bersalin" class="col-sm-3 control-label">Jumlah persalinan ditolong dukun bersalin</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_dukun_bersalin" name="data[detail][keluarga][kualitas_persalinan][pertolongan][dukun_bersalin]" placeholder="jumlah persalinan ditolong dukun bersalin" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["pertolongan"]["dukun_bersalin"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_keluarga" class="col-sm-3 control-label">Jumlah persalinan ditolong keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_keluarga" name="data[detail][keluarga][kualitas_persalinan][pertolongan][keluarga]" placeholder="jumlah persalinan ditolong keluarga" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["pertolongan"]["keluarga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kualitas_persalinan_pertolongan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_pertolongan_lainnya" name="data[detail][keluarga][kualitas_persalinan][pertolongan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["pertolongan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_kualitas_persalinan_pertolongan_lainnya" name="data[detail][keluarga][kualitas_persalinan][pertolongan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["kualitas_persalinan"]["pertolongan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Cakupan Imunisasi</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_imunisasi_dpt1" class="col-sm-3 control-label">DPT-1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_imunisasi_dpt1" name="data[detail][keluarga][imunisasi][dpt1]" placeholder="dpt-1" value="<?php echo $ddk->detail["keluarga"]["imunisasi"]["dpt1"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_imunisasi_bcg" class="col-sm-3 control-label">BCG</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_imunisasi_bcg" name="data[detail][keluarga][imunisasi][bcg]" placeholder="bcg" value="<?php echo $ddk->detail["keluarga"]["imunisasi"]["bcg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_imunisasi_polio1" class="col-sm-3 control-label">Polio-1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_imunisasi_polio1" name="data[detail][keluarga][imunisasi][polio1]" placeholder="polio -1" value="<?php echo $ddk->detail["keluarga"]["imunisasi"]["polio1"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_imunisasi_dpt2" class="col-sm-3 control-label">DPT-2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_imunisasi_dpt2" name="data[detail][keluarga][imunisasi][dpt2]" placeholder="dpt-2" value="<?php echo $ddk->detail["keluarga"]["imunisasi"]["dpt2"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_imunisasi_polio2" class="col-sm-3 control-label">Polio-2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_imunisasi_polio2" name="data[detail][keluarga][imunisasi][polio2]" placeholder="polio-2" value="<?php echo $ddk->detail["keluarga"]["imunisasi"]["polio2"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_imunisasi_polio3" class="col-sm-3 control-label">Polio-3</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_imunisasi_polio3" name="data[detail][keluarga][imunisasi][polio3]" placeholder="polio-3" value="<?php echo $ddk->detail["keluarga"]["imunisasi"]["polio3"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_imunisasi_dpt3" class="col-sm-3 control-label">DPT-3</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_imunisasi_dpt3" name="data[detail][keluarga][imunisasi][dpt3]" placeholder="dpt-3" value="<?php echo $ddk->detail["keluarga"]["imunisasi"]["dpt3"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_imunisasi_campak" class="col-sm-3 control-label">Campak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_imunisasi_campak" name="data[detail][keluarga][imunisasi][campak]" placeholder="campak" value="<?php echo $ddk->detail["keluarga"]["imunisasi"]["campak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_imunisasi_cacar" class="col-sm-3 control-label">Cacar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_imunisasi_cacar" name="data[detail][keluarga][imunisasi][cacar]" placeholder="cacar" value="<?php echo $ddk->detail["keluarga"]["imunisasi"]["cacar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_imunisasi_semua" class="col-sm-3 control-label">Sudah Semua</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_imunisasi_semua" name="data[detail][keluarga][imunisasi][semua]" placeholder="sudah semua" value="<?php echo $ddk->detail["keluarga"]["imunisasi"]["semua"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Penderita Sakit dan Kelainan dalam Keluarga (jika ada/pernah)</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_muntaber" class="col-sm-3 control-label">Muntaber</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_muntaber" name="data[detail][keluarga][penderita_sakit][muntaber]" placeholder="muntaber" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["muntaber"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_demam_berdarah" class="col-sm-3 control-label">Demam Berdarah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_demam_berdarah" name="data[detail][keluarga][penderita_sakit][demam_berdarah]" placeholder="demam berdarah" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["demam_berdarah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_kolera" class="col-sm-3 control-label">Kolera</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_kolera" name="data[detail][keluarga][penderita_sakit][kolera]" placeholder="kolera" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["kolera"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_polio" class="col-sm-3 control-label">Polio</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_polio" name="data[detail][keluarga][penderita_sakit][polio]" placeholder="polio" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["polio"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_cikungunya" class="col-sm-3 control-label">Cikungunya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_cikungunya" name="data[detail][keluarga][penderita_sakit][cikungunya]" placeholder="cikungunya" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["cikungunya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_flu_burung" class="col-sm-3 control-label">Flu Burung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_flu_burung" name="data[detail][keluarga][penderita_sakit][flu_burung]" placeholder="flu burung" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["flu_burung"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_busung_lapar" class="col-sm-3 control-label">Busung Lapar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_busung_lapar" name="data[detail][keluarga][penderita_sakit][busung_lapar]" placeholder="busung lapar" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["busung_lapar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_kelaparan" class="col-sm-3 control-label">Kelaparan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_kelaparan" name="data[detail][keluarga][penderita_sakit][kelaparan]" placeholder="kelaparan" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["kelaparan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_kulit_bersisik" class="col-sm-3 control-label">Kulit Bersisik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_kulit_bersisik" name="data[detail][keluarga][penderita_sakit][kulit_bersisik]" placeholder="kulit bersisik" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["kulit_bersisik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_kelainan_fisik" class="col-sm-3 control-label">Kelainan fisik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_kelainan_fisik" name="data[detail][keluarga][penderita_sakit][kelainan_fisik]" placeholder="kelainan fisik" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["kelainan_fisik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_kelainan_mental" class="col-sm-3 control-label">Kelainan mental</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_kelainan_mental" name="data[detail][keluarga][penderita_sakit][kelainan_mental]" placeholder="kelainan mental" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["kelainan_mental"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_lainnya1" class="col-sm-3 control-label">Lainnya 1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_lainnya1" name="data[detail][keluarga][penderita_sakit][lainnya1][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["lainnya1"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_penderita_sakit_lainnya1" name="data[detail][keluarga][penderita_sakit][lainnya1][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["lainnya1"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_lainnya2" class="col-sm-3 control-label">Lainnya 2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_lainnya2" name="data[detail][keluarga][penderita_sakit][lainnya2][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["lainnya2"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_penderita_sakit_lainnya2" name="data[detail][keluarga][penderita_sakit][lainnya2][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["lainnya2"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penderita_sakit_lainnya3" class="col-sm-3 control-label">Lainnya 3</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penderita_sakit_lainnya3" name="data[detail][keluarga][penderita_sakit][lainnya3][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["lainnya3"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_penderita_sakit_lainnya3" name="data[detail][keluarga][penderita_sakit][lainnya3][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["penderita_sakit"]["lainnya3"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Perilaku hidup bersih dan sehat dalam Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_perilaku_sehat_wc_permanen" class="col-sm-3 control-label">Memiliki WC yang permanen/semipermanen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_perilaku_sehat_wc_permanen" name="data[detail][keluarga][perilaku_sehat][wc_permanen]" placeholder="memiliki wc yang permanen/semipermanen" value="<?php echo $ddk->detail["keluarga"]["perilaku_sehat"]["wc_permanen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_perilaku_sehat_wc_darurat" class="col-sm-3 control-label">Memiliki WC yang darurat/kurang memenuhi standar kesehatan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_perilaku_sehat_wc_darurat" name="data[detail][keluarga][perilaku_sehat][wc_darurat]" placeholder="memiliki wc yang darurat/kurang memenuhi standar kesehatan" value="<?php echo $ddk->detail["keluarga"]["perilaku_sehat"]["wc_darurat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_perilaku_sehat_sungai" class="col-sm-3 control-label">Biasa buang air besar di sungai/parit/kebun/hutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_perilaku_sehat_sungai" name="data[detail][keluarga][perilaku_sehat][sungai]" placeholder="biasa buang air besar di sungai/parit/kebun/hutan" value="<?php echo $ddk->detail["keluarga"]["perilaku_sehat"]["sungai"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_perilaku_sehat_mck_umum" class="col-sm-3 control-label">Menggunakan fasilitas MCK umum</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_perilaku_sehat_mck_umum" name="data[detail][keluarga][perilaku_sehat][mck_umum]" placeholder="menggunakan fasilitas mck umum" value="<?php echo $ddk->detail["keluarga"]["perilaku_sehat"]["mck_umum"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Pola makan Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pola_makan_sehari1" class="col-sm-3 control-label">Kebiasaan makan dalam sehari 1 kali</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pola_makan_sehari1" name="data[detail][keluarga][pola_makan][sehari1]" placeholder="kebiasaan makan dalam sehari 1 kali" value="<?php echo $ddk->detail["keluarga"]["pola_makan"]["sehari1"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pola_makan_sehari2" class="col-sm-3 control-label">Kebiasaan makan sehari 2 kali</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pola_makan_sehari2" name="data[detail][keluarga][pola_makan][sehari2]" placeholder="kebiasaan makan sehari 2 kali" value="<?php echo $ddk->detail["keluarga"]["pola_makan"]["sehari2"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pola_makan_sehari3" class="col-sm-3 control-label">Kebiasaan makan sehari 3 kali</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pola_makan_sehari3" name="data[detail][keluarga][pola_makan][sehari3]" placeholder="kebiasaan makan sehari 3 kali" value="<?php echo $ddk->detail["keluarga"]["pola_makan"]["sehari3"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pola_makan_seharild3" class="col-sm-3 control-label">Kebiasaan makan sehari lebih dari 3 kali</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pola_makan_seharild3" name="data[detail][keluarga][pola_makan][seharild3]" placeholder="kebiasaan makan sehari lebih dari 3 kali" value="<?php echo $ddk->detail["keluarga"]["pola_makan"]["seharild3"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pola_makan_seharibt1" class="col-sm-3 control-label">Belum tentu sehari makan 1 kali</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pola_makan_seharibt1" name="data[detail][keluarga][pola_makan][seharibt1]" placeholder="belum tentu sehari makan 1 kali" value="<?php echo $ddk->detail["keluarga"]["pola_makan"]["seharibt1"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pola_makan_lainnya1" class="col-sm-3 control-label">Lainnya 1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pola_makan_lainnya1" name="data[detail][keluarga][pola_makan][lainnya1][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["pola_makan"]["lainnya1"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_pola_makan_lainnya1" name="data[detail][keluarga][pola_makan][lainnya1][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["pola_makan"]["lainnya1"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pola_makan_lainnya2" class="col-sm-3 control-label">Lainnya 2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pola_makan_lainnya2" name="data[detail][keluarga][pola_makan][lainnya2][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["pola_makan"]["lainnya2"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_pola_makan_lainnya2" name="data[detail][keluarga][pola_makan][lainnya2][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["pola_makan"]["lainnya2"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Kebiasaan berobat bila sakit dalam keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kebiasaan_berobat_dukun_terlatih" class="col-sm-3 control-label">Dukun Terlatih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kebiasaan_berobat_dukun_terlatih" name="data[detail][keluarga][kebiasaan_berobat][dukun_terlatih]" placeholder="dukun terlatih" value="<?php echo $ddk->detail["keluarga"]["kebiasaan_berobat"]["dukun_terlatih"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kebiasaan_berobat_dokter" class="col-sm-3 control-label">Dokter/puskesmas/mantri kesehatan/perawat/ bidan/posyandu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kebiasaan_berobat_dokter" name="data[detail][keluarga][kebiasaan_berobat][dokter]" placeholder="dokter/puskesmas/mantri kesehatan/perawat/ bidan/posyandu" value="<?php echo $ddk->detail["keluarga"]["kebiasaan_berobat"]["dokter"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kebiasaan_berobat_obat_tradisional_dukun" class="col-sm-3 control-label">Obat tradisional dari dukun pengobatan alternatif</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kebiasaan_berobat_obat_tradisional_dukun" name="data[detail][keluarga][kebiasaan_berobat][obat_tradisional_dukun]" placeholder="obat tradisional dari dukun pengobatan alternatif" value="<?php echo $ddk->detail["keluarga"]["kebiasaan_berobat"]["obat_tradisional_dukun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kebiasaan_berobat_paranormal" class="col-sm-3 control-label">Paranormal</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kebiasaan_berobat_paranormal" name="data[detail][keluarga][kebiasaan_berobat][paranormal]" placeholder="paranormal" value="<?php echo $ddk->detail["keluarga"]["kebiasaan_berobat"]["paranormal"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kebiasaan_berobat_obat_tradisional_keluarga" class="col-sm-3 control-label">Obat tradisional dari keluarga sendiri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kebiasaan_berobat_obat_tradisional_keluarga" name="data[detail][keluarga][kebiasaan_berobat][obat_tradisional_keluarga]" placeholder="obat tradisional dari keluarga sendiri" value="<?php echo $ddk->detail["keluarga"]["kebiasaan_berobat"]["obat_tradisional_keluarga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kebiasaan_berobat_tidak_diobati" class="col-sm-3 control-label">Tidak diobati</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kebiasaan_berobat_tidak_diobati" name="data[detail][keluarga][kebiasaan_berobat][tidak_diobati]" placeholder="tidak diobati" value="<?php echo $ddk->detail["keluarga"]["kebiasaan_berobat"]["tidak_diobati"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kebiasaan_berobat_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kebiasaan_berobat_lainnya" name="data[detail][keluarga][kebiasaan_berobat][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["kebiasaan_berobat"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_kebiasaan_berobat_lainnya" name="data[detail][keluarga][kebiasaan_berobat][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["kebiasaan_berobat"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Status Gizi Balita dalam Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_gizi_balita_bergizi_buruk" class="col-sm-3 control-label">Balita bergizi buruk</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_gizi_balita_bergizi_buruk" name="data[detail][keluarga][gizi_balita][bergizi_buruk]" placeholder="balita bergizi buruk" value="<?php echo $ddk->detail["keluarga"]["gizi_balita"]["bergizi_buruk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_gizi_balita_bergizi_baik" class="col-sm-3 control-label">Balita bergizi baik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_gizi_balita_bergizi_baik" name="data[detail][keluarga][gizi_balita][bergizi_baik]" placeholder="balita bergizi baik" value="<?php echo $ddk->detail["keluarga"]["gizi_balita"]["bergizi_baik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_gizi_balita_bergizi_kurang" class="col-sm-3 control-label">Balita bergizi kurang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_gizi_balita_bergizi_kurang" name="data[detail][keluarga][gizi_balita][bergizi_kurang]" placeholder="balita bergizi kurang" value="<?php echo $ddk->detail["keluarga"]["gizi_balita"]["bergizi_kurang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_gizi_balita_bergizi_lebih" class="col-sm-3 control-label">Balita bergizi lebih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_gizi_balita_bergizi_lebih" name="data[detail][keluarga][gizi_balita][bergizi_lebih]" placeholder="balita bergizi lebih" value="<?php echo $ddk->detail["keluarga"]["gizi_balita"]["bergizi_lebih"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Jenis Penyakit yang diderita Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_jantung" class="col-sm-3 control-label">Jantung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_jantung" name="data[detail][keluarga][penyakit_keluarga][jantung]" placeholder="jantung" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["jantung"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_lever" class="col-sm-3 control-label">Lever</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_lever" name="data[detail][keluarga][penyakit_keluarga][lever]" placeholder="lever" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["lever"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_paru" class="col-sm-3 control-label">Paru-paru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_paru" name="data[detail][keluarga][penyakit_keluarga][paru]" placeholder="paru-paru" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["paru"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_kanker" class="col-sm-3 control-label">Kanker</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_kanker" name="data[detail][keluarga][penyakit_keluarga][kanker]" placeholder="kanker" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["kanker"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_stroke" class="col-sm-3 control-label">Stroke</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_stroke" name="data[detail][keluarga][penyakit_keluarga][stroke]" placeholder="stroke" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["stroke"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_diabetes" class="col-sm-3 control-label">Diabetes Melitus</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_diabetes" name="data[detail][keluarga][penyakit_keluarga][diabetes]" placeholder="diabetes melitus" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["diabetes"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_ginjal" class="col-sm-3 control-label">Ginjal</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_ginjal" name="data[detail][keluarga][penyakit_keluarga][ginjal]" placeholder="ginjal" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["ginjal"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_malaria" class="col-sm-3 control-label">Malaria</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_malaria" name="data[detail][keluarga][penyakit_keluarga][malaria]" placeholder="malaria" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["malaria"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_lepra" class="col-sm-3 control-label">Lepra/Kusta</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_lepra" name="data[detail][keluarga][penyakit_keluarga][lepra]" placeholder="lepra/kusta" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["lepra"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_hiv" class="col-sm-3 control-label">HIV/AIDS</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_hiv" name="data[detail][keluarga][penyakit_keluarga][hiv]" placeholder="hiv/aids" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["hiv"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_gila" class="col-sm-3 control-label">Gila/stress</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_gila" name="data[detail][keluarga][penyakit_keluarga][gila]" placeholder="gila/stress" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["gila"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_tbc" class="col-sm-3 control-label">TBC</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_tbc" name="data[detail][keluarga][penyakit_keluarga][tbc]" placeholder="tbc" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["tbc"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_asma" class="col-sm-3 control-label">Asma</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_asma" name="data[detail][keluarga][penyakit_keluarga][asma]" placeholder="asma" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["asma"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_lainnya1" class="col-sm-3 control-label">Lainnya 1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_lainnya1" name="data[detail][keluarga][penyakit_keluarga][lainnya1][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["lainnya1"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_lainnya1" name="data[detail][keluarga][penyakit_keluarga][lainnya1][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["lainnya1"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_lainnya2" class="col-sm-3 control-label">Lainnya 2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_lainnya2" name="data[detail][keluarga][penyakit_keluarga][lainnya2][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["lainnya2"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_lainnya2" name="data[detail][keluarga][penyakit_keluarga][lainnya2][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["lainnya2"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penyakit_keluarga_lainnya3" class="col-sm-3 control-label">Lainnya 3</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_lainnya3" name="data[detail][keluarga][penyakit_keluarga][lainnya3][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["lainnya3"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_penyakit_keluarga_lainnya3" name="data[detail][keluarga][penyakit_keluarga][lainnya3][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->detail["keluarga"]["penyakit_keluarga"]["lainnya3"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Kerukunan</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kerukunan_luka_sara" class="col-sm-3 control-label">Korban luka dalam keluarga akibat konflik Sara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kerukunan_luka_sara" name="data[detail][keluarga][kerukunan][luka_sara]" placeholder="Korban luka dalam keluarga akibat konflik Sara" value="<?php echo $ddk->detail["keluarga"]["kerukunan"]["luka_sara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kerukunan_meninggal_sara" class="col-sm-3 control-label">Korban meninggal dalam keluarga akibat konflik Sara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kerukunan_meninggal_sara" name="data[detail][keluarga][kerukunan][meninggal_sara]" placeholder="Korban meninggal dalam keluarga akibat konflik Sara" value="<?php echo $ddk->detail["keluarga"]["kerukunan"]["meninggal_sara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kerukunan_janda_duda_sara" class="col-sm-3 control-label">Janda/duda dalam keluarga akibat konflik Sara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kerukunan_janda_duda_sara" name="data[detail][keluarga][kerukunan][janda_duda_sara]" placeholder="Janda/duda dalam keluarga akibat konflik Sara" value="<?php echo $ddk->detail["keluarga"]["kerukunan"]["janda_duda_sara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kerukunan_yatim_piatu_sara" class="col-sm-3 control-label">Anak yatim/piatu dalam keluarga akibat konflik Sara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kerukunan_yatim_piatu_sara" name="data[detail][keluarga][kerukunan][yatim_piatu_sara]" placeholder="Anak yatim/piatu dalam keluarga akibat konflik Sara" value="<?php echo $ddk->detail["keluarga"]["kerukunan"]["yatim_piatu_sara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kerukunan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kerukunan_lainnya" name="data[detail][keluarga][kerukunan][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["kerukunan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_kerukunan_lainnya" name="data[detail][keluarga][kerukunan][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["kerukunan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Perkelahian</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_perkelahian_meninggal" class="col-sm-3 control-label">Korban jiwa akibat perkelahian dalam keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_perkelahian_meninggal" name="data[detail][keluarga][perkelahian][meninggal]" placeholder="Korban jiwa akibat perkelahian dalam keluarga" value="<?php echo $ddk->detail["keluarga"]["perkelahian"]["meninggal"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_perkelahian_luka" class="col-sm-3 control-label">Korban luka parah akibat perkelahian dalam keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_perkelahian_luka" name="data[detail][keluarga][perkelahian][luka]" placeholder="Korban luka parah akibat perkelahian dalam keluarga" value="<?php echo $ddk->detail["keluarga"]["perkelahian"]["luka"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_perkelahian_lainnya1" class="col-sm-3 control-label">Lainnya 1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_perkelahian_lainnya1" name="data[detail][keluarga][perkelahian][lainnya1][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["perkelahian"]["lainnya1"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_perkelahian_lainnya1" name="data[detail][keluarga][perkelahian][lainnya1][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["perkelahian"]["lainnya1"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_perkelahian_lainnya2" class="col-sm-3 control-label">Lainnya 2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_perkelahian_lainnya2" name="data[detail][keluarga][perkelahian][lainnya2][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["perkelahian"]["lainnya2"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_perkelahian_lainnya2" name="data[detail][keluarga][perkelahian][lainnya2][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["perkelahian"]["lainnya2"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Pencurian</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pencurian_korban_keluarga" class="col-sm-3 control-label">Korban pencurian, perampokan dalam keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pencurian_korban_keluarga" name="data[detail][keluarga][pencurian][korban_keluarga]" placeholder="Korban pencurian, perampokan dalam keluarga" value="<?php echo $ddk->detail["keluarga"]["pencurian"]["korban_keluarga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pencurian_lainnya1" class="col-sm-3 control-label">Lainnya 1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pencurian_lainnya1" name="data[detail][keluarga][pencurian][lainnya1][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["pencurian"]["lainnya1"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_pencurian_lainnya1" name="data[detail][keluarga][pencurian][lainnya1][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["pencurian"]["lainnya1"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pencurian_lainnya2" class="col-sm-3 control-label">Lainnya 2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pencurian_lainnya2" name="data[detail][keluarga][pencurian][lainnya2][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["pencurian"]["lainnya2"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_pencurian_lainnya2" name="data[detail][keluarga][pencurian][lainnya2][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["pencurian"]["lainnya2"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Penjarahan</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penjarahan_penjarahan_keluarga" class="col-sm-3 control-label">Korban penjarahan yang pelakunya anggota keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penjarahan_penjarahan_keluarga" name="data[detail][keluarga][penjarahan][penjarahan_keluarga]" placeholder="Korban penjarahan yang pelakunya anggota keluarga" value="<?php echo $ddk->detail["keluarga"]["penjarahan"]["penjarahan_keluarga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penjarahan_penjarahan_luar" class="col-sm-3 control-label">Korban penjarahan yang pelakunya bukan anggota keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penjarahan_penjarahan_luar" name="data[detail][keluarga][penjarahan][penjarahan_luar]" placeholder="Korban penjarahan yang pelakunya bukan anggota keluarga" value="<?php echo $ddk->detail["keluarga"]["penjarahan"]["penjarahan_luar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penjarahan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penjarahan_lainnya" name="data[detail][keluarga][penjarahan][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["penjarahan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_penjarahan_lainnya" name="data[detail][keluarga][penjarahan][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["penjarahan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Perjudian</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_perjudian_keluarga" class="col-sm-3 control-label">Anggota keluarga yang memiliki kebiasaan berjudi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_perjudian_keluarga" name="data[detail][keluarga][perjudian][keluarga]" placeholder="Anggota keluarga yang memiliki kebiasaan berjudi" value="<?php echo $ddk->detail["keluarga"]["perjudian"]["keluarga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_perjudian_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_perjudian_lainnya" name="data[detail][keluarga][perjudian][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["perjudian"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_perjudian_lainnya" name="data[detail][keluarga][perjudian][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["perjudian"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Pemakaian Miras dan Narkoba</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_miras_narkoba_miras" class="col-sm-3 control-label">Anggota keluarga mengkonsumsi Miras yang dilarang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_miras_narkoba_miras" name="data[detail][keluarga][miras_narkoba][miras]" placeholder="Anggota keluarga mengkonsumsi Miras yang dilarang" value="<?php echo $ddk->detail["keluarga"]["miras_narkoba"]["miras"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_miras_narkoba_narkoba" class="col-sm-3 control-label">Anggota keluarga yang mengkonsumsi Narkoba</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_miras_narkoba_narkoba" name="data[detail][keluarga][miras_narkoba][narkoba]" placeholder="Anggota keluarga yang mengkonsumsi Narkoba" value="<?php echo $ddk->detail["keluarga"]["miras_narkoba"]["narkoba"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_miras_narkoba_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_miras_narkoba_lainnya" name="data[detail][keluarga][miras_narkoba][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["miras_narkoba"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_miras_narkoba_lainnya" name="data[detail][keluarga][miras_narkoba][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["miras_narkoba"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Pembunuhan</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pembunuhan_pelaku_keluarga" class="col-sm-3 control-label">Korban pembunuhan dalam keluarga yang pelakunya anggota keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pembunuhan_pelaku_keluarga" name="data[detail][keluarga][pembunuhan][pelaku_keluarga]" placeholder="Korban pembunuhan dalam keluarga yang pelakunya anggota keluarga" value="<?php echo $ddk->detail["keluarga"]["pembunuhan"]["pelaku_keluarga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pembunuhan_pelaku_luar" class="col-sm-3 control-label">Korban pembunuhan dalam keluarga yang pelakunya bukan anggota keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pembunuhan_pelaku_luar" name="data[detail][keluarga][pembunuhan][pelaku_luar]" placeholder="Korban pembunuhan dalam keluarga yang pelakunya bukan anggota keluarga" value="<?php echo $ddk->detail["keluarga"]["pembunuhan"]["pelaku_luar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_pembunuhan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_pembunuhan_lainnya" name="data[detail][keluarga][pembunuhan][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["pembunuhan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_pembunuhan_lainnya" name="data[detail][keluarga][pembunuhan][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["pembunuhan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Penculikan</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penculikan_pelaku_keluarga" class="col-sm-3 control-label">Korban penculikan yang pelakunya anggota keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penculikan_pelaku_keluarga" name="data[detail][keluarga][penculikan][pelaku_keluarga]" placeholder="Korban penculikan yang pelakunya anggota keluarga" value="<?php echo $ddk->detail["keluarga"]["penculikan"]["pelaku_keluarga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penculikan_pelaku_luar" class="col-sm-3 control-label">Korban penculikan yang pelakunya bukan anggota keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penculikan_pelaku_luar" name="data[detail][keluarga][penculikan][pelaku_luar]" placeholder="Korban penculikan yang pelakunya bukan anggota keluarga" value="<?php echo $ddk->detail["keluarga"]["penculikan"]["pelaku_luar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penculikan_lainnya1" class="col-sm-3 control-label">Lainnya 1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penculikan_lainnya1" name="data[detail][keluarga][penculikan][lainnya1][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["penculikan"]["lainnya1"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_penculikan_lainnya1" name="data[detail][keluarga][penculikan][lainnya1][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["penculikan"]["lainnya1"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_penculikan_lainnya2" class="col-sm-3 control-label">Lainnya 2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_penculikan_lainnya2" name="data[detail][keluarga][penculikan][lainnya2][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["penculikan"]["lainnya2"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_penculikan_lainnya2" name="data[detail][keluarga][penculikan][lainnya2][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["penculikan"]["lainnya2"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Kejahatan Seksual</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_seksual_perkosaan_keluarga" class="col-sm-3 control-label">Korban perkosaan/pelecehan seksual yang pelakunya anggota keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_seksual_pelaku_perkosaan_keluarga" name="data[detail][keluarga][seksual][perkosaan_keluarga]" placeholder="Korban perkosaan/pelecehan seksual yang pelakunya anggota keluarga" value="<?php echo $ddk->detail["keluarga"]["seksual"]["perkosaan_keluarga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_seksual_perkosaan_luar" class="col-sm-3 control-label">Korban perkosaan/pelecehan seksual yang pelakunya bukan anggota keluarga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_seksual_pelaku_perkosaan_luar" name="data[detail][keluarga][seksual][perkosaan_luar]" placeholder="Korban perkosaan/pelecehan seksual yang pelakunya bukan anggota keluarga" value="<?php echo $ddk->detail["keluarga"]["seksual"]["perkosaan_luar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_seksual_hln_sah" class="col-sm-3 control-label">Korban kehamilan di luar nikah yang sah menurut hukum adat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_seksual_pelaku_hln_sah" name="data[detail][keluarga][seksual][hln_sah]" placeholder="Korban kehamilan di luar nikah yang sah menurut hukum adat" value="<?php echo $ddk->detail["keluarga"]["seksual"]["hln_sah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_seksual_htn" class="col-sm-3 control-label">Korban kehamilan yang tidak dinikahi pelakunya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_seksual_pelaku_htn" name="data[detail][keluarga][seksual][htn]" placeholder="Korban kehamilan yang tidak dinikahi pelakunya" value="<?php echo $ddk->detail["keluarga"]["seksual"]["htn"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_seksual_hbs" class="col-sm-3 control-label">Korban kehamilan yang tidak/belum disahkan secara hukum agama dan hukum negara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_seksual_pelaku_hbs" name="data[detail][keluarga][seksual][hbs]" placeholder="Korban kehamilan yang tidak/belum disahkan secara hukum agama dan hukum negara" value="<?php echo $ddk->detail["keluarga"]["seksual"]["hbs"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_seksual_lainnya1" class="col-sm-3 control-label">Lainnya 1</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_seksual_lainnya1" name="data[detail][keluarga][seksual][lainnya1][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["seksual"]["lainnya1"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_seksual_lainnya1" name="data[detail][keluarga][seksual][lainnya1][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["seksual"]["lainnya1"]["jumlah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_seksual_lainnya2" class="col-sm-3 control-label">Lainnya 2</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_seksual_lainnya2" name="data[detail][keluarga][seksual][lainnya2][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["seksual"]["lainnya2"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_seksual_lainnya2" name="data[detail][keluarga][seksual][lainnya2][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["seksual"]["lainnya2"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Kekerasan Dalam Keluarga / Rumah Tangga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_peradot" class="col-sm-3 control-label">Adanya pertengkaran dalam keluarga antara anak dan orang tua</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_peradot" name="data[detail][keluarga][kekerasan][peradot]" placeholder="Adanya pertengkaran dalam keluarga antara anak dan orang tua" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["peradot"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_perada" class="col-sm-3 control-label">Adanya pertengkaran dalam keluarga antara anak dan anak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_perada" name="data[detail][keluarga][kekerasan][perada]" placeholder="Adanya pertengkaran dalam keluarga antara anak dan anak" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["perada"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_peradiot" class="col-sm-3 control-label">Adanya pertengkaran dalam keluarga antara ayah dan ibu/orang tua</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_peradiot" name="data[detail][keluarga][kekerasan][peradiot]" placeholder="Adanya pertengkaran dalam keluarga antara ayah dan ibu/orang tua" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["peradiot"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_peradp" class="col-sm-3 control-label">Adanya pertengkaran dalam keluarga antara anak dan pembantu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_peradp" name="data[detail][keluarga][kekerasan][peradp]" placeholder="Adanya pertengkaran dalam keluarga antara anak dan pembantu" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["peradp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_peradakl" class="col-sm-3 control-label">Adanya pertengkaran dalam keluarga antara anak dan anggota keluarga lain</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_peradakl" name="data[detail][keluarga][kekerasan][peradakl]" placeholder="Adanya pertengkaran dalam keluarga antara anak dan anggota keluarga lain" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["peradakl"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_pemadot" class="col-sm-3 control-label">Adanya pemukulan/tindakan fisik antara anak dengan orang tua</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_pemadot" name="data[detail][keluarga][kekerasan][pemadot]" placeholder="Adanya pemukulan/tindakan fisik antara anak dengan orang tua" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["pemadot"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_pemotda" class="col-sm-3 control-label">Adanya pemukulan/tindakan fisik antara orang tua dengan anak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_pemotda" name="data[detail][keluarga][kekerasan][pemotda]" placeholder="Adanya pemukulan/tindakan fisik antara orang tua dengan anak" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["pemotda"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_pemadkl" class="col-sm-3 control-label">Adanya pemukulan/tindakan fisik antara anak dengan anggota keluarga lain</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_pemadkl" name="data[detail][keluarga][kekerasan][pemadkl]" placeholder="Adanya pemukulan/tindakan fisik antara anak dengan anggota keluarga lain" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["pemadkl"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_pemotot" class="col-sm-3 control-label">Adanya pemukulan/tindakan fisik antara orang tua dengan orang tua</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_pemotot" name="data[detail][keluarga][kekerasan][pemotot]" placeholder="Adanya pemukulan/tindakan fisik antara orang tua dengan orang tua" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["pemotot"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_pemadp" class="col-sm-3 control-label">Adanya pemukulan/tindakan fisik antara anak dengan pembantu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_pemadp" name="data[detail][keluarga][kekerasan][pemadp]" placeholder="Adanya pemukulan/tindakan fisik antara anak dengan pembantu" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["pemadp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_pemotdp" class="col-sm-3 control-label">Adanya pemukulan/tindakan fisik antara orang tua dengan pembantu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_pelaku_pemotdp" name="data[detail][keluarga][kekerasan][pemotdp]" placeholder="Adanya pemukulan/tindakan fisik antara orang tua dengan pembantu" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["pemotdp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kekerasan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kekerasan_lainnya" name="data[detail][keluarga][kekerasan][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_kekerasan_lainnya" name="data[detail][keluarga][kekerasan][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["kekerasan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Masalah Kesejahteraan Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_mengemis" class="col-sm-3 control-label">Ada anggota keluarga yang mengemis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_mengemis" name="data[detail][keluarga][kesejahteraan][mengemis]" placeholder="Ada anggota keluarga yang mengemis" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["mengemis"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_tidur_luar" class="col-sm-3 control-label">Ada anggota keluarga yang bermalam/tidur di jalanan/emperan toko/ kolong jembatan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_tidur_luar" name="data[detail][keluarga][kesejahteraan][tidur_luar]" placeholder="Ada anggota keluarga yang bermalam/tidur di jalanan/emperan toko/ kolong jembatan" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["tidur_luar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_lansia" class="col-sm-3 control-label">Ada anggota keluarga yang termasuk manusia lanjut usia (di atas 60 thn)</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_lansia" name="data[detail][keluarga][kesejahteraan][lansia]" placeholder="Ada anggota keluarga yang termasuk manusia lanjut usia (di atas 60 thn)" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["lansia"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_anak_mengemis" class="col-sm-3 control-label">Ada anak anggota keluarga yang mengemis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_anak_mengemis" name="data[detail][keluarga][kesejahteraan][anak_mengemis]" placeholder="Ada anak anggota keluarga yang mengemis" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["anak_mengemis"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_anak_pengamen" class="col-sm-3 control-label">Ada anak dan anggota keluarga yang menjadi pengamen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_anak_pengamen" name="data[detail][keluarga][kesejahteraan][anak_pengamen]" placeholder="Ada anak dan anggota keluarga yang menjadi pengamen" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["anak_pengamen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_stress" class="col-sm-3 control-label">Ada anggota keluarga yang gila/stres</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_stress" name="data[detail][keluarga][kesejahteraan][stress]" placeholder="Ada anggota keluarga yang gila/stres" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["stress"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_cacat_fisik" class="col-sm-3 control-label">Ada anggota keluarga yang cacat fisik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_cacat_fisik" name="data[detail][keluarga][kesejahteraan][cacat_fisik]" placeholder="Ada anggota keluarga yang cacat fisik" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["cacat_fisik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_cacat_mental" class="col-sm-3 control-label">Ada anggota keluarga yang cacat mental</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_cacat_mental" name="data[detail][keluarga][kesejahteraan][cacat_mental]" placeholder="Ada anggota keluarga yang cacat mental" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["cacat_mental"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_kelainan_kulit" class="col-sm-3 control-label">Ada anggota keluarga yang kelainan kulit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_kelainan_kulit" name="data[detail][keluarga][kesejahteraan][kelainan_kulit]" placeholder="Ada anggota keluarga yang kelainan kulit" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["kelainan_kulit"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_keluarga_pengamen" class="col-sm-3 control-label">Ada anggota keluarga yang menjadi pengamen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_keluarga_pengamen" name="data[detail][keluarga][kesejahteraan][keluarga_pengamen]" placeholder="Ada anggota keluarga yang menjadi pengamen" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["keluarga_pengamen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_yatim" class="col-sm-3 control-label">Anggota keluarga yatim/piatu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_yatim" name="data[detail][keluarga][kesejahteraan][yatim]" placeholder="Anggota keluarga yatim/piatu" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["yatim"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_janda" class="col-sm-3 control-label">Keluarga janda</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_janda" name="data[detail][keluarga][kesejahteraan][janda]" placeholder="Keluarga janda" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["janda"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_duda" class="col-sm-3 control-label">Keluarga duda</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_duda" name="data[detail][keluarga][kesejahteraan][duda]" placeholder="Keluarga duda" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["duda"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_sungai" class="col-sm-3 control-label">Tinggal di bantaran sungai</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_sungai" name="data[detail][keluarga][kesejahteraan][sungai]" placeholder="Tinggal di bantaran sungai" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["sungai"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_jalur_hijau" class="col-sm-3 control-label">Tinggal di jalur hijau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_jalur_hijau" name="data[detail][keluarga][kesejahteraan][jalur_hijau]" placeholder="Tinggal di jalur hijau" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["jalur_hijau"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_rel" class="col-sm-3 control-label">Tinggal di kawasan jalur rel kereta api</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_rel" name="data[detail][keluarga][kesejahteraan][rel]" placeholder="Tinggal di kawasan jalur rel kereta api" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["rel"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_sutet" class="col-sm-3 control-label">Tinggal di kawasan jalur sutet</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_sutet" name="data[detail][keluarga][kesejahteraan][sutet]" placeholder="Tinggal di kawasan jalur sutet" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["sutet"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_kumuh" class="col-sm-3 control-label">Tinggal di kawasan kumuh dan padat pemukiman</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_kumuh" name="data[detail][keluarga][kesejahteraan][kumuh]" placeholder="Tinggal di kawasan kumuh dan padat pemukiman" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["kumuh"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_menganggur" class="col-sm-3 control-label">Ada anggota keluarga yang menganggur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_menganggur" name="data[detail][keluarga][kesejahteraan][menganggur]" placeholder="Ada anggota keluarga yang menganggur" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["menganggur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_anak_kerja" class="col-sm-3 control-label">Ada anak yang membantu orang tua mendapatkan penghasilan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_anak_kerja" name="data[detail][keluarga][kesejahteraan][anak_kerja]" placeholder="Ada anak yang membantu orang tua mendapatkan penghasilan" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["anak_kerja"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_kepala_perempuan" class="col-sm-3 control-label">Kepala keluarga perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_kepala_perempuan" name="data[detail][keluarga][kesejahteraan][kepala_perempuan]" placeholder="Kepala keluarga perempuan" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["kepala_perempuan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_eks_narapidana" class="col-sm-3 control-label">Ada anggota keluarga eks narapidana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_eks_narapidana" name="data[detail][keluarga][kesejahteraan][eks_narapidana]" placeholder="Ada anggota keluarga eks narapidana" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["eks_narapidana"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_banjir" class="col-sm-3 control-label">Tinggal di desa/kelurahan rawan banjir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_banjir" name="data[detail][keluarga][kesejahteraan][banjir]" placeholder="Tinggal di desa/kelurahan rawan banjir" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["banjir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_tsunami" class="col-sm-3 control-label">Tinggal di daerah rawan bencana tsunami</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_tsunami" name="data[detail][keluarga][kesejahteraan][tsunami]" placeholder="Tinggal di daerah rawan bencana tsunami" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["tsunami"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_gunung_meletus" class="col-sm-3 control-label">Tinggal di desa/kelurahan rawan gunung meletus</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_gunung_meletus" name="data[detail][keluarga][kesejahteraan][gunung_meletus]" placeholder="Tinggal di desa/kelurahan rawan gunung meletus" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["gunung_meletus"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_gempa" class="col-sm-3 control-label">Tinggal di jalur rawan gempa bumi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_gempa" name="data[detail][keluarga][kesejahteraan][gempa]" placeholder="Tinggal di jalur rawan gempa bumi" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["gempa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_longsor" class="col-sm-3 control-label">Tinggal di kawasan rawan tanah longsor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_longsor" name="data[detail][keluarga][kesejahteraan][longsor]" placeholder="Tinggal di kawasan rawan tanah longsor" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["longsor"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_kebakaran" class="col-sm-3 control-label">Tinggal di kawasan rawan kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_kebakaran" name="data[detail][keluarga][kesejahteraan][kebakaran]" placeholder="Tinggal di kawasan rawan kebakaran" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["kebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_kelaparan" class="col-sm-3 control-label">Tinggal di desa/kelurahan rawan kelaparan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_kelaparan" name="data[detail][keluarga][kesejahteraan][kelaparan]" placeholder="Tinggal di desa/kelurahan rawan kelaparan" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["kelaparan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_air_bersih" class="col-sm-3 control-label">Tinggal di desa/kelurahan rawan air bersih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_air_bersih" name="data[detail][keluarga][kesejahteraan][air_bersih]" placeholder="Tinggal di desa/kelurahan rawan air bersih" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["air_bersih"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_kekeringan" class="col-sm-3 control-label">Tinggal di desa/kelurahan rawan kekeringan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_kekeringan" name="data[detail][keluarga][kesejahteraan][kekeringan]" placeholder="Tinggal di desa/kelurahan rawan kekeringan" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["kekeringan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_gagal_panen" class="col-sm-3 control-label">Tinggal di desa/kelurahan rawan gagal tanam/panen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_gagal_panen" name="data[detail][keluarga][kesejahteraan][gagal_panen]" placeholder="Tinggal di desa/kelurahan rawan gagal tanam/panen" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["gagal_panen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_tandus" class="col-sm-3 control-label">Tinggal di daerah kawasan kering, tandus & kritis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_pelaku_tandus" name="data[detail][keluarga][kesejahteraan][tandus]" placeholder="Tinggal di daerah kawasan kering, tandus & kritis" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["tandus"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="keluarga_kesejahteraan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="keluarga_kesejahteraan_lainnya" name="data[detail][keluarga][kesejahteraan][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="keluarga_kesejahteraan_lainnya" name="data[detail][keluarga][kesejahteraan][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->detail["keluarga"]["kesejahteraan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Data Anggota Keluarga 1</strong></h4>
				<h4>Biodata</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_no_urut" class="col-sm-3 control-label">Nomor Urut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_no_urut" name="data[anggota][0][no_urut]" placeholder="Nomor Urut" value="<?php echo $ddk->anggota[0]["no_urut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_nik" class="col-sm-3 control-label">Nomor Induk Kependudukan (NIK)</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_nik" name="data[anggota][0][nik]" placeholder="Nomor Induk Kependudukan (NIK)" value="<?php echo $ddk->anggota[0]["nik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_nama" class="col-sm-3 control-label">Nama Lengkap</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_nama" name="data[anggota][0][nama]" placeholder="Nama Lengkap" value="<?php echo $ddk->anggota[0]["nama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_no_akte" class="col-sm-3 control-label">Nomor Akte Kelahiran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_no_akte" name="data[anggota][0][no_akte]" placeholder="Nomor Akte Kelahiran" value="<?php echo $ddk->anggota[0]["no_akte"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_jenis_kelamin" class="col-sm-3 control-label">Jenis Kelamin</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][0][jenis_kelamin]" id="anggota1_jenis_kelamin">
					<option value="laki" <?php echo $ddk->anggota[0]["jenis_kelamin"] == "laki" ? "selected" : ""; ?>>Laki-laki</option>
					<option value="perempuan" <?php echo $ddk->anggota[0]["jenis_kelamin"] == "perempuan" ? "selected" : ""; ?>>Perempuan</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_hubungan" class="col-sm-3 control-label">Hubungan dengan Kepala Keluarga</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][0][hubungan]" id="anggota1_hubungan">
					<option value="istri" <?php echo $ddk->anggota[0]["hubungan"] == "istri" ? "selected" : ""; ?>>Istri</option>
					<option value="suami" <?php echo $ddk->anggota[0]["hubungan"] == "suami" ? "selected" : ""; ?>>Suami</option>
					<option value="anak" <?php echo $ddk->anggota[0]["hubungan"] == "anak" ? "selected" : ""; ?>>Anak</option>
					<option value="cucu" <?php echo $ddk->anggota[0]["hubungan"] == "cucu" ? "selected" : ""; ?>>Cucu</option>
					<option value="mertua" <?php echo $ddk->anggota[0]["hubungan"] == "mertua" ? "selected" : ""; ?>>Mertua</option>
					<option value="menantu" <?php echo $ddk->anggota[0]["hubungan"] == "menantu" ? "selected" : ""; ?>>Menantu</option>
					<option value="keponakan" <?php echo $ddk->anggota[0]["hubungan"] == "keponakan" ? "selected" : ""; ?>>Keponakan</option>
					<option value="lainnya" <?php echo $ddk->anggota[0]["hubungan"] == "lainnya" ? "selected" : ""; ?>>Lainnya</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_tempat_lahir" class="col-sm-3 control-label">Tempat Lahir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_tempat_lahir" name="data[anggota][0][tempat_lahir]" placeholder="Tempat Lahir" value="<?php echo $ddk->anggota[0]["tempat_lahir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_tanggal_lahir" class="col-sm-3 control-label">Tanggal Lahir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="anggota1_tanggal_lahir" name="data[anggota][0][tanggal_lahir]" placeholder="Tanggal Lahir" value="<?php echo $ddk->anggota[0]["tanggal_lahir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_tanggal_pencatatan" class="col-sm-3 control-label">Tanggal Pencatatan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="anggota1_tanggal_pencatatan" name="data[anggota][0][tanggal_pencatatan]" placeholder="Tanggal Pencatatan" value="<?php echo $ddk->anggota[0]["tanggal_pencatatan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_status_kawin" class="col-sm-3 control-label">Status Perkawinan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][0][status_kawin]" id="anggota1_status_kawin">
					<option value="kawin" <?php echo $ddk->anggota[0]["status_kawin"] == "kawin" ? "selected" : ""; ?>>Kawin</option>
					<option value="belum" <?php echo $ddk->anggota[0]["status_kawin"] == "belum" ? "selected" : ""; ?>>Belum Kawin</option>
					<option value="pernah" <?php echo $ddk->anggota[0]["status_kawin"] == "pernah" ? "selected" : ""; ?>>Pernah Kawin</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_agama" class="col-sm-3 control-label">Agama dan Aliran Kepercayaan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][0][agama]" id="anggota1_agama">
					<option value="islam" <?php echo $ddk->anggota[0]["agama"] == "islam" ? "selected" : ""; ?>>Islam</option>
					<option value="protestan" <?php echo $ddk->anggota[0]["agama"] == "protestan" ? "selected" : ""; ?>>Protestan</option>
					<option value="katolik" <?php echo $ddk->anggota[0]["agama"] == "katolik" ? "selected" : ""; ?>>Katolik</option>
					<option value="hindu" <?php echo $ddk->anggota[0]["agama"] == "hindu" ? "selected" : ""; ?>>Hindu</option>
					<option value="budha" <?php echo $ddk->anggota[0]["agama"] == "budha" ? "selected" : ""; ?>>Budha</option>
					<option value="kong hu chu" <?php echo $ddk->anggota[0]["agama"] == "kong hu chu" ? "selected" : ""; ?>>Kong Hu Chu</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_darah" class="col-sm-3 control-label">Golongan Darah</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][0][darah]" id="anggota1_darah">
					<option value="O" <?php echo $ddk->anggota[0]["darah"] == "O" ? "selected" : ""; ?>>O</option>
					<option value="A" <?php echo $ddk->anggota[0]["darah"] == "A" ? "selected" : ""; ?>>A</option>
					<option value="B" <?php echo $ddk->anggota[0]["darah"] == "B" ? "selected" : ""; ?>>B</option>
					<option value="AB" <?php echo $ddk->anggota[0]["darah"] == "AB" ? "selected" : ""; ?>>AB</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kewarganegaraan" class="col-sm-3 control-label">Kewarganegaraan/Etnis/Suku</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kewarganegaraan" name="data[anggota][0][kewarganegaraan]" placeholder="Kewarganegaraan/Etnis/Suku" value="<?php echo $ddk->anggota[0]["kewarganegaraan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pendidikan" class="col-sm-3 control-label">Pendidikan Umum Terakhir</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][0][pendidikan]" id="anggota1_pendidikan">
					<option value="SD" <?php echo $ddk->anggota[0]["pendidikan"] == "SD" ? "selected" : ""; ?>>SD</option>
					<option value="SMP" <?php echo $ddk->anggota[0]["pendidikan"] == "SMP" ? "selected" : ""; ?>>SMP</option>
					<option value="SMA" <?php echo $ddk->anggota[0]["pendidikan"] == "SMA" ? "selected" : ""; ?>>SMA</option>
					<option value="Diploma" <?php echo $ddk->anggota[0]["pendidikan"] == "Diploma" ? "selected" : ""; ?>>Diploma</option>
					<option value="S1" <?php echo $ddk->anggota[0]["pendidikan"] == "S1" ? "selected" : ""; ?>>S1</option>
					<option value="S2" <?php echo $ddk->anggota[0]["pendidikan"] == "S2" ? "selected" : ""; ?>>S2</option>
					<option value="S3" <?php echo $ddk->anggota[0]["pendidikan"] == "S3" ? "selected" : ""; ?>>S3</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pekerjaan" class="col-sm-3 control-label">Mata Pencaharian Pokok/Pekerjaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pekerjaan" name="data[anggota][0][pekerjaan]" placeholder="Mata Pencaharian Pokok/Pekerjaan" value="<?php echo $ddk->anggota[0]["pekerjaan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_nama_ortu" class="col-sm-3 control-label">Nama Bapak / Ibu Kandung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_nama_ortu" name="data[anggota][0][nama_ortu]" placeholder="Nama Bapak / Ibu Kandung" value="<?php echo $ddk->anggota[0]["nama_ortu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kb" class="col-sm-3 control-label">Akseptor KB</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][0][kb]" id="anggota1_kb">
					<option value="Pil" <?php echo $ddk->anggota[0]["kb"] == "Pil" ? "selected" : ""; ?>>Pil</option>
					<option value="Spiral" <?php echo $ddk->anggota[0]["kb"] == "Spiral" ? "selected" : ""; ?>>Spiral</option>
					<option value="Suntik" <?php echo $ddk->anggota[0]["kb"] == "Suntik" ? "selected" : ""; ?>>Suntik</option>
					<option value="Susuk" <?php echo $ddk->anggota[0]["kb"] == "Susuk" ? "selected" : ""; ?>>Susuk</option>
					<option value="Kondom" <?php echo $ddk->anggota[0]["kb"] == "Kondom" ? "selected" : ""; ?>>Kondom</option>
					<option value="Vaksetomi" <?php echo $ddk->anggota[0]["kb"] == "Vaksetomi" ? "selected" : ""; ?>>Vaksetomi</option>
					<option value="Tubektomi" <?php echo $ddk->anggota[0]["kb"] == "Tubektomi" ? "selected" : ""; ?>>Tubektomi</option>
				</select>
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Cacat Menurut Jenis</strong></h4>
				<h4>Cacat Fisik</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_cacat_fisik_tuli" class="col-sm-3 control-label">Tuna rungu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_cacat_fisik_tuli" name="data[anggota][0][cacat_fisik][tuli]" placeholder="Tuna rungu" value="<?php echo $ddk->anggota[0]["cacat_fisik"]["tuli"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_cacat_fisik_bisu" class="col-sm-3 control-label">Tuna wicara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_cacat_fisik_bisu" name="data[anggota][0][cacat_fisik][bisu]" placeholder="Tuna wicara" value="<?php echo $ddk->anggota[0]["cacat_fisik"]["bisu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_cacat_fisik_buta" class="col-sm-3 control-label">Tuna netra</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_cacat_fisik_buta" name="data[anggota][0][cacat_fisik][buta]" placeholder="Tuna netra" value="<?php echo $ddk->anggota[0]["cacat_fisik"]["buta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_cacat_fisik_lumpuh" class="col-sm-3 control-label">Lumpuh</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_cacat_fisik_lumpuh" name="data[anggota][0][cacat_fisik][lumpuh]" placeholder="Lumpuh" value="<?php echo $ddk->anggota[0]["cacat_fisik"]["lumpuh"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_cacat_fisik_sumbing" class="col-sm-3 control-label">Sumbing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_cacat_fisik_sumbing" name="data[anggota][0][cacat_fisik][sumbing]" placeholder="Sumbing" value="<?php echo $ddk->anggota[0]["cacat_fisik"]["sumbing"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_cacat_fisik_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_cacat_fisik_lainnya" name="data[anggota][0][cacat_fisik][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[0]["cacat_fisik"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_cacat_fisik_lainnya" name="data[anggota][0][cacat_fisik][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[0]["cacat_fisik"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4>Cacat Mental</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_cacat_mental_idiot" class="col-sm-3 control-label">Idiot</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_cacat_mental_idiot" name="data[anggota][0][cacat_mental][idiot]" placeholder="Idiot" value="<?php echo $ddk->anggota[0]["cacat_mental"]["idiot"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_cacat_mental_gila" class="col-sm-3 control-label">Gila</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_cacat_mental_gila" name="data[anggota][0][cacat_mental][gila]" placeholder="Gila" value="<?php echo $ddk->anggota[0]["cacat_mental"]["gila"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_cacat_mental_stress" class="col-sm-3 control-label">Stress</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_cacat_mental_stress" name="data[anggota][0][cacat_mental][stress]" placeholder="Stress" value="<?php echo $ddk->anggota[0]["cacat_mental"]["stress"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_cacat_mental_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_cacat_mental_lainnya" name="data[anggota][0][cacat_mental][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[0]["cacat_mental"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_cacat_mental_lainnya" name="data[anggota][0][cacat_mental][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[0]["cacat_mental"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Kedudukan Anggota Keluarga sebagai Wajib Pajak dan Retribusi</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pajak_retribusi_pbb" class="col-sm-3 control-label">Wajib Pajak Bumi dan Bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pajak_retribusi_pbb" name="data[anggota][0][pajak_retribusi][pbb]" placeholder="Wajib Pajak Bumi dan Bangunan" value="<?php echo $ddk->anggota[0]["pajak_retribusi"]["pbb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pajak_retribusi_ppp" class="col-sm-3 control-label">Wajib Pajak Penghasilan Perorangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pajak_retribusi_ppp" name="data[anggota][0][pajak_retribusi][ppp]" placeholder="Wajib Pajak Penghasilan Perorangan" value="<?php echo $ddk->anggota[0]["pajak_retribusi"]["ppp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pajak_retribusi_pb" class="col-sm-3 control-label">Wajib Pajak Badan/Perusahaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pajak_retribusi_pb" name="data[anggota][0][pajak_retribusi][pb]" placeholder="Wajib Pajak Badan/Perusahaan" value="<?php echo $ddk->anggota[0]["pajak_retribusi"]["pb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pajak_retribusi_pkb" class="col-sm-3 control-label">Wajib Pajak Kendaraan Bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pajak_retribusi_pkb" name="data[anggota][0][pajak_retribusi][pkb]" placeholder="Wajib Pajak Kendaraan Bermotor" value="<?php echo $ddk->anggota[0]["pajak_retribusi"]["pkb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pajak_retribusi_kebersihan" class="col-sm-3 control-label">Wajib Retribusi Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pajak_retribusi_kebersihan" name="data[anggota][0][pajak_retribusi][kebersihan]" placeholder="Wajib Retribusi Kebersihan" value="<?php echo $ddk->anggota[0]["pajak_retribusi"]["kebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pajak_retribusi_keamanan" class="col-sm-3 control-label">Wajib Retribusi Keamanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pajak_retribusi_keamanan" name="data[anggota][0][pajak_retribusi][keamanan]" placeholder="Wajib Retribusi Keamanan" value="<?php echo $ddk->anggota[0]["pajak_retribusi"]["keamanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pajak_retribusi_iuran" class="col-sm-3 control-label">Wajib iuran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pajak_retribusi_iuran" name="data[anggota][0][pajak_retribusi][iuran]" placeholder="Wajib iuran" value="<?php echo $ddk->anggota[0]["pajak_retribusi"]["iuran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pajak_retribusi_pungutan" class="col-sm-3 control-label">Wajib pungutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pajak_retribusi_pungutan" name="data[anggota][0][pajak_retribusi][pungutan]" placeholder="Wajib pungutan" value="<?php echo $ddk->anggota[0]["pajak_retribusi"]["pungutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pajak_retribusi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pajak_retribusi_lainnya" name="data[anggota][0][pajak_retribusi][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[0]["pajak_retribusi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_pajak_retribusi_lainnya" name="data[anggota][0][pajak_retribusi][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[0]["pajak_retribusi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Lembaga Pemerintahan Yang Diikuti Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pemerintahan_kepala_desa" class="col-sm-3 control-label">Kepala Desa/Lurah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pemerintahan_kepala_desa" name="data[anggota][0][pemerintahan][kepala_desa]" placeholder="Kepala Desa/Lurah" value="<?php echo $ddk->anggota[0]["pemerintahan"]["kepala_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pemerintahan_sekretaris_desa" class="col-sm-3 control-label">Sekretaris Desa/Kelurahan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pemerintahan_sekretaris_desa" name="data[anggota][0][pemerintahan][sekretaris_desa]" placeholder="Sekretaris Desa/Kelurahan" value="<?php echo $ddk->anggota[0]["pemerintahan"]["sekretaris_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pemerintahan_kepala_urusan" class="col-sm-3 control-label">Kepala Urusan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pemerintahan_kepala_urusan" name="data[anggota][0][pemerintahan][kepala_urusan]" placeholder="Kepala Urusan" value="<?php echo $ddk->anggota[0]["pemerintahan"]["kepala_urusan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pemerintahan_kepala_dusun" class="col-sm-3 control-label">Kepala Dusun/Lingkungan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pemerintahan_kepala_dusun" name="data[anggota][0][pemerintahan][kepala_dusun]" placeholder="Kepala Dusun/Lingkungan" value="<?php echo $ddk->anggota[0]["pemerintahan"]["kepala_dusun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pemerintahan_staf_desa" class="col-sm-3 control-label">Staf Desa/Kelurahan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pemerintahan_staf_desa" name="data[anggota][0][pemerintahan][staf_desa]" placeholder="Staf Desa/Kelurahan" value="<?php echo $ddk->anggota[0]["pemerintahan"]["staf_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pemerintahan_ketua_bpd" class="col-sm-3 control-label">Ketua BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pemerintahan_ketua_bpd" name="data[anggota][0][pemerintahan][ketua_bpd]" placeholder="Ketua BPD" value="<?php echo $ddk->anggota[0]["pemerintahan"]["ketua_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pemerintahan_wakil_ketua_bpd" class="col-sm-3 control-label">Wakil Ketua BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pemerintahan_wakil_ketua_bpd" name="data[anggota][0][pemerintahan][wakil_ketua_bpd]" placeholder="Wakil Ketua BPD" value="<?php echo $ddk->anggota[0]["pemerintahan"]["wakil_ketua_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pemerintahan_sekretaris_bpd" class="col-sm-3 control-label">Sekretaris BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pemerintahan_sekretaris_bpd" name="data[anggota][0][pemerintahan][sekretaris_bpd]" placeholder="Sekretaris BPD" value="<?php echo $ddk->anggota[0]["pemerintahan"]["sekretaris_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pemerintahan_anggota_bpd" class="col-sm-3 control-label">Anggota BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pemerintahan_anggota_bpd" name="data[anggota][0][pemerintahan][anggota_bpd]" placeholder="Anggota BPD" value="<?php echo $ddk->anggota[0]["pemerintahan"]["anggota_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_pemerintahan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_pemerintahan_lainnya" name="data[anggota][0][pemerintahan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[0]["pemerintahan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_pemerintahan_lainnya" name="data[anggota][0][pemerintahan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[0]["pemerintahan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Lembaga Kemasyarakatan Yang Diikuti Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_prt" class="col-sm-3 control-label">Pengurus RT</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_prt" name="data[anggota][0][kemasyarakatan][prt]" placeholder="Pengurus RT" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["prt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aprt" class="col-sm-3 control-label">Anggota Pengurus RT</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aprt" name="data[anggota][0][kemasyarakatan][aprt]" placeholder="Anggota Pengurus RT" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aprt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_prw" class="col-sm-3 control-label">Pengurus RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_prw" name="data[anggota][0][kemasyarakatan][prw]" placeholder="Pengurus RW" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["prw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aprw" class="col-sm-3 control-label">Anggota Pengurus RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aprw" name="data[anggota][0][kemasyarakatan][aprw]" placeholder="Anggota Pengurus RW" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aprw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_plkmdklpm" class="col-sm-3 control-label">Pengurus LKMD/K/LPM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_plkmdklpm" name="data[anggota][0][kemasyarakatan][plkmdklpm]" placeholder="Pengurus LKMD/K/LPM" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["plkmdklpm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_alkmdklpm" class="col-sm-3 control-label">Anggota LKMD/K/LPM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_alkmdklpm" name="data[anggota][0][kemasyarakatan][alkmdklpm]" placeholder="Anggota LKMD/K/LPM" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["alkmdklpm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_ppkk" class="col-sm-3 control-label">Pengurus PKK</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_ppkk" name="data[anggota][0][kemasyarakatan][ppkk]" placeholder="Pengurus PKK" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["ppkk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_apkk" class="col-sm-3 control-label">Anggota PKK</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_apkk" name="data[anggota][0][kemasyarakatan][apkk]" placeholder="Anggota PKK" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["apkk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pla" class="col-sm-3 control-label">Pengurus Lembaga Adat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pla" name="data[anggota][0][kemasyarakatan][pla]" placeholder="Pengurus Lembaga Adat" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pla"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pkt" class="col-sm-3 control-label">Pengurus Karang Taruna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pkt" name="data[anggota][0][kemasyarakatan][pkt]" placeholder="Pengurus Karang Taruna" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pkt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_akt" class="col-sm-3 control-label">Anggota Karang Taruna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_akt" name="data[anggota][0][kemasyarakatan][akt]" placeholder="Anggota Karang Taruna" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["akt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_phl" class="col-sm-3 control-label">Pengurus Hansip/Linmas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_phl" name="data[anggota][0][kemasyarakatan][phl]" placeholder="Pengurus Hansip/Linmas" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["phl"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pp" class="col-sm-3 control-label">Pengurus Poskamling</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pp" name="data[anggota][0][kemasyarakatan][pp]" placeholder="Pengurus Poskamling" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pop" class="col-sm-3 control-label">Pengurus Organisasi Perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pop" name="data[anggota][0][kemasyarakatan][pop]" placeholder="Pengurus Organisasi Perempuan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aop" class="col-sm-3 control-label">Anggota Organisasi Perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aop" name="data[anggota][0][kemasyarakatan][aop]" placeholder="Anggota Organisasi Perempuan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pob" class="col-sm-3 control-label">Pengurus Organisasi Bapak-bapak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pob" name="data[anggota][0][kemasyarakatan][pob]" placeholder="Pengurus Organisasi Bapak-bapak" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pob"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aob" class="col-sm-3 control-label">Anggota Organisasi Bapak-bapak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aob" name="data[anggota][0][kemasyarakatan][aob]" placeholder="Anggota Organisasi Bapak-bapak" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aob"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pok" class="col-sm-3 control-label">Pengurus Organisasi keagamaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pok" name="data[anggota][0][kemasyarakatan][pok]" placeholder="Pengurus Organisasi keagamaan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aok" class="col-sm-3 control-label">Anggota Organisasi keagamaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aok" name="data[anggota][0][kemasyarakatan][aok]" placeholder="Anggota Organisasi keagamaan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_popw" class="col-sm-3 control-label">Pengurus Organisasi profesi wartawan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_popw" name="data[anggota][0][kemasyarakatan][popw]" placeholder="Pengurus Organisasi profesi wartawan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["popw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aopw" class="col-sm-3 control-label">Anggota Organisasi profesi wartawan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aopw" name="data[anggota][0][kemasyarakatan][aopw]" placeholder="Anggota Organisasi profesi wartawan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aopw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pposyandu" class="col-sm-3 control-label">Pengurus Posyandu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pposyandu" name="data[anggota][0][kemasyarakatan][pposyandu]" placeholder="Pengurus Posyandu" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pposyandu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pposyantekdes" class="col-sm-3 control-label">Pengurus Posyantekdes</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pposyantekdes" name="data[anggota][0][kemasyarakatan][pposyantekdes]" placeholder="Pengurus Posyantekdes" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pposyantekdes"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_poktan" class="col-sm-3 control-label">Pengurus Organisasi Kelompok Tani/Nelayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_poktan" name="data[anggota][0][kemasyarakatan][poktan]" placeholder="Pengurus Organisasi Kelompok Tani/Nelayan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["poktan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aoktan" class="col-sm-3 control-label">Anggota Organisasi Kelompok Tani/Nelayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aoktan" name="data[anggota][0][kemasyarakatan][aoktan]" placeholder="Anggota Organisasi Kelompok Tani/Nelayan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aoktan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_plgr" class="col-sm-3 control-label">Pengurus Lembaga Gotong royong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_plgr" name="data[anggota][0][kemasyarakatan][plgr]" placeholder="Pengurus Lembaga Gotong royong" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["plgr"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_algr" class="col-sm-3 control-label">Anggota Lembaga Gotong royong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_algr" name="data[anggota][0][kemasyarakatan][algr]" placeholder="Anggota Lembaga Gotong royong" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["algr"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_popg" class="col-sm-3 control-label">Pengurus Organisasi Profesi guru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_popg" name="data[anggota][0][kemasyarakatan][popg]" placeholder="Pengurus Organisasi Profesi guru" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["popg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aopg" class="col-sm-3 control-label">Anggota Organisasi Profesi guru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aopg" name="data[anggota][0][kemasyarakatan][aopg]" placeholder="Anggota Organisasi Profesi guru" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aopg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_popdtm" class="col-sm-3 control-label">Pengurus Organisasi profesi dokter/tenaga medis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_popdtm" name="data[anggota][0][kemasyarakatan][popdtm]" placeholder="Pengurus Organisasi profesi dokter/tenaga medis" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["popdtm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aoptm" class="col-sm-3 control-label">Anggota Organisasi profesi/tenaga medis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aoptm" name="data[anggota][0][kemasyarakatan][aoptm]" placeholder="Anggota Organisasi profesi/tenaga medis" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aoptm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_popensiun" class="col-sm-3 control-label">Pengurus organisasi pensiunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_popensiun" name="data[anggota][0][kemasyarakatan][popensiun]" placeholder="Pengurus organisasi pensiunan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["popensiun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aopensiun" class="col-sm-3 control-label">Anggota organisasi pensiunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aopensiun" name="data[anggota][0][kemasyarakatan][aopensiun]" placeholder="Anggota organisasi pensiunan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aopensiun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_popp" class="col-sm-3 control-label">Pengurus organisasi pemirsa/pendengar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_popp" name="data[anggota][0][kemasyarakatan][popp]" placeholder="Pengurus organisasi pemirsa/pendengar" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["popp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aopp" class="col-sm-3 control-label">Anggota organisasi pemirsa/pendengar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aopp" name="data[anggota][0][kemasyarakatan][aopp]" placeholder="Anggota organisasi pemirsa/pendengar" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aopp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_plpa" class="col-sm-3 control-label">Pengurus lembaga pencinta alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_plpa" name="data[anggota][0][kemasyarakatan][plpa]" placeholder="Pengurus lembaga pencinta alam" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["plpa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_alpa" class="col-sm-3 control-label">Anggota organisasi pencinta alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_alpa" name="data[anggota][0][kemasyarakatan][alpa]" placeholder="Anggota organisasi pencinta alam" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["alpa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_popip" class="col-sm-3 control-label">Pengurus organisasi pengembangan ilmu pengetahuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_popip" name="data[anggota][0][kemasyarakatan][popip]" placeholder="Pengurus organisasi pengembangan ilmu pengetahuan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["popip"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_aopip" class="col-sm-3 control-label">Anggota organisasi pengembangan ilmu pengetaahuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_aopip" name="data[anggota][0][kemasyarakatan][aopip]" placeholder="Anggota organisasi pengembangan ilmu pengetaahuan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["aopip"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pemyaya" class="col-sm-3 control-label">Pemilik yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pemyaya" name="data[anggota][0][kemasyarakatan][pemyaya]" placeholder="Pemilik yayasan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pemyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_penyaya" class="col-sm-3 control-label">Pengurus yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_penyaya" name="data[anggota][0][kemasyarakatan][penyaya]" placeholder="Pengurus yayasan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["penyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_angyaya" class="col-sm-3 control-label">Anggota yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_angyaya" name="data[anggota][0][kemasyarakatan][angyaya]" placeholder="Anggota yayasan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["angyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pkebersihan" class="col-sm-3 control-label">Pengurus Satgas Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pkebersihan" name="data[anggota][0][kemasyarakatan][pkebersihan]" placeholder="Pengurus Satgas Kebersihan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pkebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_akebersihan" class="col-sm-3 control-label">Anggota Satgas Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_akebersihan" name="data[anggota][0][kemasyarakatan][akebersihan]" placeholder="Anggota Satgas Kebersihan" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["akebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_pkebakaran" class="col-sm-3 control-label">Pengurus Satgas Kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_pkebakaran" name="data[anggota][0][kemasyarakatan][pkebakaran]" placeholder="Pengurus Satgas Kebakaran" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["pkebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_akebakaran" class="col-sm-3 control-label">Anggota Satgas Kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_akebakaran" name="data[anggota][0][kemasyarakatan][akebakaran]" placeholder="Anggota Satgas Kebakaran" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["akebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_ppb" class="col-sm-3 control-label">Pengurus Posko Penanggulangan Bencana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_ppb" name="data[anggota][0][kemasyarakatan][ppb]" placeholder="Pengurus Posko Penanggulangan Bencana" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["ppb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_atpb" class="col-sm-3 control-label">Anggota Tim Penanggulangan Bencana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_atpb" name="data[anggota][0][kemasyarakatan][atpb]" placeholder="Anggota Tim Penanggulangan Bencana" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["atpb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_kemasyarakatan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_lainnya" name="data[anggota][0][kemasyarakatan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_kemasyarakatan_lainnya" name="data[anggota][0][kemasyarakatan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[0]["kemasyarakatan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Lembaga Ekonomi Yang Dimiliki Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_koperasi" class="col-sm-3 control-label">Koperasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_koperasi" name="data[anggota][0][ekonomi][koperasi]" placeholder="Koperasi" value="<?php echo $ddk->anggota[0]["ekonomi"]["koperasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_unit_usaha_simpan_pinjam" class="col-sm-3 control-label">Unit Usaha Simpan Pinjam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_unit_usaha_simpan_pinjam" name="data[anggota][0][ekonomi][unit_usaha_simpan_pinjam]" placeholder="Unit Usaha Simpan Pinjam" value="<?php echo $ddk->anggota[0]["ekonomi"]["unit_usaha_simpan_pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_industri_kerajinan_tangan" class="col-sm-3 control-label">Industri Kerajinan Tangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_industri_kerajinan_tangan" name="data[anggota][0][ekonomi][industri_kerajinan_tangan]" placeholder="Industri Kerajinan Tangan" value="<?php echo $ddk->anggota[0]["ekonomi"]["industri_kerajinan_tangan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_industri_pakaian" class="col-sm-3 control-label">Industri Pakaian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_industri_pakaian" name="data[anggota][0][ekonomi][industri_pakaian]" placeholder="Industri Pakaian" value="<?php echo $ddk->anggota[0]["ekonomi"]["industri_pakaian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_industri_usaha_makanan" class="col-sm-3 control-label">Industri Usaha Makanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_industri_usaha_makanan" name="data[anggota][0][ekonomi][industri_usaha_makanan]" placeholder="Industri Usaha Makanan" value="<?php echo $ddk->anggota[0]["ekonomi"]["industri_usaha_makanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_industri_alat_rumah_tangga" class="col-sm-3 control-label">Industri Alat Rumah Tangga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_industri_alat_rumah_tangga" name="data[anggota][0][ekonomi][industri_alat_rumah_tangga]" placeholder="Industri Alat Rumah Tangga" value="<?php echo $ddk->anggota[0]["ekonomi"]["industri_alat_rumah_tangga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_industri_usaha_bahan_bangunan" class="col-sm-3 control-label">Industri Usaha Bahan Bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_industri_usaha_bahan_bangunan" name="data[anggota][0][ekonomi][industri_usaha_bahan_bangunan]" placeholder="Industri Usaha Bahan Bangunan" value="<?php echo $ddk->anggota[0]["ekonomi"]["industri_usaha_bahan_bangunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_industri_alat_pertanian" class="col-sm-3 control-label">Industri Alat Pertanian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_industri_alat_pertanian" name="data[anggota][0][ekonomi][industri_alat_pertanian]" placeholder="Industri Alat Pertanian" value="<?php echo $ddk->anggota[0]["ekonomi"]["industri_alat_pertanian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_restoran" class="col-sm-3 control-label">Restoran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_restoran" name="data[anggota][0][ekonomi][restoran]" placeholder="Restoran" value="<?php echo $ddk->anggota[0]["ekonomi"]["restoran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_toko__swalayan" class="col-sm-3 control-label">Toko/ Swalayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_toko__swalayan" name="data[anggota][0][ekonomi][toko__swalayan]" placeholder="Toko/ Swalayan" value="<?php echo $ddk->anggota[0]["ekonomi"]["toko__swalayan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_warung_kelontongan_kios" class="col-sm-3 control-label">Warung Kelontongan/Kios</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_warung_kelontongan_kios" name="data[anggota][0][ekonomi][warung_kelontongan_kios]" placeholder="Warung Kelontongan/Kios" value="<?php echo $ddk->anggota[0]["ekonomi"]["warung_kelontongan_kios"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_angkutan_darat" class="col-sm-3 control-label">Angkutan Darat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_angkutan_darat" name="data[anggota][0][ekonomi][angkutan_darat]" placeholder="Angkutan Darat" value="<?php echo $ddk->anggota[0]["ekonomi"]["angkutan_darat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_angkutan_sungai" class="col-sm-3 control-label">Angkutan Sungai</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_angkutan_sungai" name="data[anggota][0][ekonomi][angkutan_sungai]" placeholder="Angkutan Sungai" value="<?php echo $ddk->anggota[0]["ekonomi"]["angkutan_sungai"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_angkutan_laut" class="col-sm-3 control-label">Angkutan Laut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_angkutan_laut" name="data[anggota][0][ekonomi][angkutan_laut]" placeholder="Angkutan Laut" value="<?php echo $ddk->anggota[0]["ekonomi"]["angkutan_laut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_angkutan_udara" class="col-sm-3 control-label">Angkutan Udara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_angkutan_udara" name="data[anggota][0][ekonomi][angkutan_udara]" placeholder="Angkutan Udara" value="<?php echo $ddk->anggota[0]["ekonomi"]["angkutan_udara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_jasa_ekspedisi_pengiriman_barang" class="col-sm-3 control-label">Jasa Ekspedisi/Pengiriman Barang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_jasa_ekspedisi_pengiriman_barang" name="data[anggota][0][ekonomi][jasa_ekspedisi_pengiriman_barang]" placeholder="Jasa Ekspedisi/Pengiriman Barang" value="<?php echo $ddk->anggota[0]["ekonomi"]["jasa_ekspedisi_pengiriman_barang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_pasar_harian" class="col-sm-3 control-label">Usaha Pasar Harian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_pasar_harian" name="data[anggota][0][ekonomi][usaha_pasar_harian]" placeholder="Usaha Pasar Harian" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_pasar_harian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_pasar_mingguan" class="col-sm-3 control-label">Usaha Pasar Mingguan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_pasar_mingguan" name="data[anggota][0][ekonomi][usaha_pasar_mingguan]" placeholder="Usaha Pasar Mingguan" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_pasar_mingguan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_pasar_ternak" class="col-sm-3 control-label">Usaha Pasar Ternak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_pasar_ternak" name="data[anggota][0][ekonomi][usaha_pasar_ternak]" placeholder="Usaha Pasar Ternak" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_pasar_ternak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_pasar_hasil_bumi_dan_tambang" class="col-sm-3 control-label">Usaha Pasar Hasil Bumi Dan Tambang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_pasar_hasil_bumi_dan_tambang" name="data[anggota][0][ekonomi][usaha_pasar_hasil_bumi_dan_tambang]" placeholder="Usaha Pasar Hasil Bumi Dan Tambang" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_pasar_hasil_bumi_dan_tambang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_perdagangan_antar_pulau" class="col-sm-3 control-label">Usaha Perdagangan Antar Pulau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_perdagangan_antar_pulau" name="data[anggota][0][ekonomi][usaha_perdagangan_antar_pulau]" placeholder="Usaha Perdagangan Antar Pulau" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_perdagangan_antar_pulau"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_pengijon" class="col-sm-3 control-label">Pengijon</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_pengijon" name="data[anggota][0][ekonomi][pengijon]" placeholder="Pengijon" value="<?php echo $ddk->anggota[0]["ekonomi"]["pengijon"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_pedagang_pengumpul_tengkulak" class="col-sm-3 control-label">Pedagang Pengumpul/Tengkulak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_pedagang_pengumpul_tengkulak" name="data[anggota][0][ekonomi][pedagang_pengumpul_tengkulak]" placeholder="Pedagang Pengumpul/Tengkulak" value="<?php echo $ddk->anggota[0]["ekonomi"]["pedagang_pengumpul_tengkulak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_peternakan" class="col-sm-3 control-label">Usaha Peternakan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_peternakan" name="data[anggota][0][ekonomi][usaha_peternakan]" placeholder="Usaha Peternakan" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_peternakan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_perikanan" class="col-sm-3 control-label">Usaha Perikanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_perikanan" name="data[anggota][0][ekonomi][usaha_perikanan]" placeholder="Usaha Perikanan" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_perikanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_perkebunan" class="col-sm-3 control-label">Usaha Perkebunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_perkebunan" name="data[anggota][0][ekonomi][usaha_perkebunan]" placeholder="Usaha Perkebunan" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_perkebunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_kelompok_simpan_pinjam" class="col-sm-3 control-label">Kelompok Simpan Pinjam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_kelompok_simpan_pinjam" name="data[anggota][0][ekonomi][kelompok_simpan_pinjam]" placeholder="Kelompok Simpan Pinjam" value="<?php echo $ddk->anggota[0]["ekonomi"]["kelompok_simpan_pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_minuman" class="col-sm-3 control-label">Usaha Minuman</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_minuman" name="data[anggota][0][ekonomi][usaha_minuman]" placeholder="Usaha Minuman" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_minuman"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_industri_farmasi" class="col-sm-3 control-label">Industri Farmasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_industri_farmasi" name="data[anggota][0][ekonomi][industri_farmasi]" placeholder="Industri Farmasi" value="<?php echo $ddk->anggota[0]["ekonomi"]["industri_farmasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_industri_karoseri" class="col-sm-3 control-label">Industri Karoseri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_industri_karoseri" name="data[anggota][0][ekonomi][industri_karoseri]" placeholder="Industri Karoseri" value="<?php echo $ddk->anggota[0]["ekonomi"]["industri_karoseri"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_penitipan_kendaraan_bermotor" class="col-sm-3 control-label">Penitipan Kendaraan Bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_penitipan_kendaraan_bermotor" name="data[anggota][0][ekonomi][penitipan_kendaraan_bermotor]" placeholder="Penitipan Kendaraan Bermotor" value="<?php echo $ddk->anggota[0]["ekonomi"]["penitipan_kendaraan_bermotor"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_industri_perakitan_elektronik" class="col-sm-3 control-label">Industri Perakitan Elektronik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_industri_perakitan_elektronik" name="data[anggota][0][ekonomi][industri_perakitan_elektronik]" placeholder="Industri Perakitan Elektronik" value="<?php echo $ddk->anggota[0]["ekonomi"]["industri_perakitan_elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_pengolahan_kayu" class="col-sm-3 control-label">Pengolahan Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_pengolahan_kayu" name="data[anggota][0][ekonomi][pengolahan_kayu]" placeholder="Pengolahan Kayu" value="<?php echo $ddk->anggota[0]["ekonomi"]["pengolahan_kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_bioskop" class="col-sm-3 control-label">Bioskop</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_bioskop" name="data[anggota][0][ekonomi][bioskop]" placeholder="Bioskop" value="<?php echo $ddk->anggota[0]["ekonomi"]["bioskop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_film_keliling" class="col-sm-3 control-label">Film Keliling</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_film_keliling" name="data[anggota][0][ekonomi][film_keliling]" placeholder="Film Keliling" value="<?php echo $ddk->anggota[0]["ekonomi"]["film_keliling"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_sandiwara_drama" class="col-sm-3 control-label">Sandiwara/Drama</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_sandiwara_drama" name="data[anggota][0][ekonomi][sandiwara_drama]" placeholder="Sandiwara/Drama" value="<?php echo $ddk->anggota[0]["ekonomi"]["sandiwara_drama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_group_lawak" class="col-sm-3 control-label">Group Lawak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_group_lawak" name="data[anggota][0][ekonomi][group_lawak]" placeholder="Group Lawak" value="<?php echo $ddk->anggota[0]["ekonomi"]["group_lawak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_jaipongan" class="col-sm-3 control-label">Jaipongan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_jaipongan" name="data[anggota][0][ekonomi][jaipongan]" placeholder="Jaipongan" value="<?php echo $ddk->anggota[0]["ekonomi"]["jaipongan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_wayang_orang_golek" class="col-sm-3 control-label">Wayang Orang/Golek</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_wayang_orang_golek" name="data[anggota][0][ekonomi][wayang_orang_golek]" placeholder="Wayang Orang/Golek" value="<?php echo $ddk->anggota[0]["ekonomi"]["wayang_orang_golek"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_group_musik_band" class="col-sm-3 control-label">Group Musik/Band</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_group_musik_band" name="data[anggota][0][ekonomi][group_musik_band]" placeholder="Group Musik/Band" value="<?php echo $ddk->anggota[0]["ekonomi"]["group_musik_band"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_group_vokal_paduan_suara" class="col-sm-3 control-label">Group Vokal/Paduan Suara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_group_vokal_paduan_suara" name="data[anggota][0][ekonomi][group_vokal_paduan_suara]" placeholder="Group Vokal/Paduan Suara" value="<?php echo $ddk->anggota[0]["ekonomi"]["group_vokal_paduan_suara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_persewaan_tenaga_listrik" class="col-sm-3 control-label">Usaha Persewaan Tenaga Listrik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_persewaan_tenaga_listrik" name="data[anggota][0][ekonomi][usaha_persewaan_tenaga_listrik]" placeholder="Usaha Persewaan Tenaga Listrik" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_persewaan_tenaga_listrik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_pengecer_gas_dan_bahan_bakar_minyak" class="col-sm-3 control-label">Usaha Pengecer Gas Dan Bahan Bakar Minyak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_pengecer_gas_dan_bahan_bakar_minyak" name="data[anggota][0][ekonomi][usaha_pengecer_gas_dan_bahan_bakar_minyak]" placeholder="Usaha Pengecer Gas Dan Bahan Bakar Minyak" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_pengecer_gas_dan_bahan_bakar_minyak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_air_minum_dalam_kemasan" class="col-sm-3 control-label">Usaha Air Minum Dalam Kemasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_air_minum_dalam_kemasan" name="data[anggota][0][ekonomi][usaha_air_minum_dalam_kemasan]" placeholder="Usaha Air Minum Dalam Kemasan" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_air_minum_dalam_kemasan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_tukang_kayu" class="col-sm-3 control-label">Tukang Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_tukang_kayu" name="data[anggota][0][ekonomi][tukang_kayu]" placeholder="Tukang Kayu" value="<?php echo $ddk->anggota[0]["ekonomi"]["tukang_kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_tukang_batu" class="col-sm-3 control-label">Tukang Batu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_tukang_batu" name="data[anggota][0][ekonomi][tukang_batu]" placeholder="Tukang Batu" value="<?php echo $ddk->anggota[0]["ekonomi"]["tukang_batu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_tukang_jahit_bordir" class="col-sm-3 control-label">Tukang Jahit/Bordir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_tukang_jahit_bordir" name="data[anggota][0][ekonomi][tukang_jahit_bordir]" placeholder="Tukang Jahit/Bordir" value="<?php echo $ddk->anggota[0]["ekonomi"]["tukang_jahit_bordir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_tukang_cukur" class="col-sm-3 control-label">Tukang Cukur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_tukang_cukur" name="data[anggota][0][ekonomi][tukang_cukur]" placeholder="Tukang Cukur" value="<?php echo $ddk->anggota[0]["ekonomi"]["tukang_cukur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_tukang_service_elektronik" class="col-sm-3 control-label">Tukang Service Elektronik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_tukang_service_elektronik" name="data[anggota][0][ekonomi][tukang_service_elektronik]" placeholder="Tukang Service Elektronik" value="<?php echo $ddk->anggota[0]["ekonomi"]["tukang_service_elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_tukang_besi" class="col-sm-3 control-label">Tukang Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_tukang_besi" name="data[anggota][0][ekonomi][tukang_besi]" placeholder="Tukang Besi" value="<?php echo $ddk->anggota[0]["ekonomi"]["tukang_besi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_tukang_pijat_urut" class="col-sm-3 control-label">Tukang Pijat/Urut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_tukang_pijat_urut" name="data[anggota][0][ekonomi][tukang_pijat_urut]" placeholder="Tukang Pijat/Urut" value="<?php echo $ddk->anggota[0]["ekonomi"]["tukang_pijat_urut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_tukang_sumur" class="col-sm-3 control-label">Tukang Sumur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_tukang_sumur" name="data[anggota][0][ekonomi][tukang_sumur]" placeholder="Tukang Sumur" value="<?php echo $ddk->anggota[0]["ekonomi"]["tukang_sumur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_notaris" class="col-sm-3 control-label">Notaris</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_notaris" name="data[anggota][0][ekonomi][notaris]" placeholder="Notaris" value="<?php echo $ddk->anggota[0]["ekonomi"]["notaris"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_pengacara_advokat" class="col-sm-3 control-label">Pengacara/Advokat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_pengacara_advokat" name="data[anggota][0][ekonomi][pengacara_advokat]" placeholder="Pengacara/Advokat" value="<?php echo $ddk->anggota[0]["ekonomi"]["pengacara_advokat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_konsultan_manajemen" class="col-sm-3 control-label">Konsultan Manajemen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_konsultan_manajemen" name="data[anggota][0][ekonomi][konsultan_manajemen]" placeholder="Konsultan Manajemen" value="<?php echo $ddk->anggota[0]["ekonomi"]["konsultan_manajemen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_konsultan_teknis" class="col-sm-3 control-label">Konsultan Teknis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_konsultan_teknis" name="data[anggota][0][ekonomi][konsultan_teknis]" placeholder="Konsultan Teknis" value="<?php echo $ddk->anggota[0]["ekonomi"]["konsultan_teknis"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_pejabat_pembuat_akta_tanah" class="col-sm-3 control-label">Pejabat Pembuat Akta Tanah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_pejabat_pembuat_akta_tanah" name="data[anggota][0][ekonomi][pejabat_pembuat_akta_tanah]" placeholder="Pejabat Pembuat Akta Tanah" value="<?php echo $ddk->anggota[0]["ekonomi"]["pejabat_pembuat_akta_tanah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_losmen" class="col-sm-3 control-label">Losmen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_losmen" name="data[anggota][0][ekonomi][losmen]" placeholder="Losmen" value="<?php echo $ddk->anggota[0]["ekonomi"]["losmen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_wisma" class="col-sm-3 control-label">Wisma</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_wisma" name="data[anggota][0][ekonomi][wisma]" placeholder="Wisma" value="<?php echo $ddk->anggota[0]["ekonomi"]["wisma"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_asrama" class="col-sm-3 control-label">Asrama</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_asrama" name="data[anggota][0][ekonomi][asrama]" placeholder="Asrama" value="<?php echo $ddk->anggota[0]["ekonomi"]["asrama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_persewaan_kamar" class="col-sm-3 control-label">Persewaan Kamar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_persewaan_kamar" name="data[anggota][0][ekonomi][persewaan_kamar]" placeholder="Persewaan Kamar" value="<?php echo $ddk->anggota[0]["ekonomi"]["persewaan_kamar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_kontrakan_rumah" class="col-sm-3 control-label">Kontrakan Rumah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_kontrakan_rumah" name="data[anggota][0][ekonomi][kontrakan_rumah]" placeholder="Kontrakan Rumah" value="<?php echo $ddk->anggota[0]["ekonomi"]["kontrakan_rumah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_mess" class="col-sm-3 control-label">Mess</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_mess" name="data[anggota][0][ekonomi][mess]" placeholder="Mess" value="<?php echo $ddk->anggota[0]["ekonomi"]["mess"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_hotel" class="col-sm-3 control-label">Hotel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_hotel" name="data[anggota][0][ekonomi][hotel]" placeholder="Hotel" value="<?php echo $ddk->anggota[0]["ekonomi"]["hotel"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_home_stay" class="col-sm-3 control-label">Home Stay</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_home_stay" name="data[anggota][0][ekonomi][home_stay]" placeholder="Home Stay" value="<?php echo $ddk->anggota[0]["ekonomi"]["home_stay"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_villa" class="col-sm-3 control-label">Villa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_villa" name="data[anggota][0][ekonomi][villa]" placeholder="Villa" value="<?php echo $ddk->anggota[0]["ekonomi"]["villa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_town_house" class="col-sm-3 control-label">Town House</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_town_house" name="data[anggota][0][ekonomi][town_house]" placeholder="Town House" value="<?php echo $ddk->anggota[0]["ekonomi"]["town_house"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_asuransi" class="col-sm-3 control-label">Usaha Asuransi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_asuransi" name="data[anggota][0][ekonomi][usaha_asuransi]" placeholder="Usaha Asuransi" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_asuransi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_lembaga_keuangan_bukan_bank" class="col-sm-3 control-label">Lembaga Keuangan Bukan Bank</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_lembaga_keuangan_bukan_bank" name="data[anggota][0][ekonomi][lembaga_keuangan_bukan_bank]" placeholder="Lembaga Keuangan Bukan Bank" value="<?php echo $ddk->anggota[0]["ekonomi"]["lembaga_keuangan_bukan_bank"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_lembaga_perkreditan_rakyat" class="col-sm-3 control-label">Lembaga Perkreditan Rakyat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_lembaga_perkreditan_rakyat" name="data[anggota][0][ekonomi][lembaga_perkreditan_rakyat]" placeholder="Lembaga Perkreditan Rakyat" value="<?php echo $ddk->anggota[0]["ekonomi"]["lembaga_perkreditan_rakyat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_pegadaian" class="col-sm-3 control-label">Pegadaian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_pegadaian" name="data[anggota][0][ekonomi][pegadaian]" placeholder="Pegadaian" value="<?php echo $ddk->anggota[0]["ekonomi"]["pegadaian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_bank_perkreditan_rakyat" class="col-sm-3 control-label">Bank Perkreditan Rakyat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_bank_perkreditan_rakyat" name="data[anggota][0][ekonomi][bank_perkreditan_rakyat]" placeholder="Bank Perkreditan Rakyat" value="<?php echo $ddk->anggota[0]["ekonomi"]["bank_perkreditan_rakyat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_penyewaan_alat_pesta" class="col-sm-3 control-label">Usaha Penyewaan Alat Pesta</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_penyewaan_alat_pesta" name="data[anggota][0][ekonomi][usaha_penyewaan_alat_pesta]" placeholder="Usaha Penyewaan Alat Pesta" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_penyewaan_alat_pesta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_usaha_pengolahan_dan_penjualan_hasil_hutan" class="col-sm-3 control-label">Usaha Pengolahan dan Penjualan Hasil Hutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_usaha_pengolahan_dan_penjualan_hasil_hutan" name="data[anggota][0][ekonomi][usaha_pengolahan_dan_penjualan_hasil_hutan]" placeholder="Usaha Pengolahan dan Penjualan Hasil Hutan" value="<?php echo $ddk->anggota[0]["ekonomi"]["usaha_pengolahan_dan_penjualan_hasil_hutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_ekonomi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_ekonomi_lainnya" name="data[anggota][0][ekonomi][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[0]["ekonomi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_ekonomi_lainnya" name="data[anggota][0][ekonomi][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[0]["ekonomi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<h4><strong>Produksi bahan galian yang dimiliki anggota keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_batu_kali" class="col-sm-3 control-label">Batu kali</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_batu_kali" name="data[anggota][0][galian][batu_kali][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["batu_kali"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_kali" name="data[anggota][0][galian][batu_kali][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["batu_kali"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_kali" name="data[anggota][0][galian][batu_kali][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["batu_kali"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_kali" name="data[anggota][0][galian][batu_kali][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["batu_kali"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_batu_kapur" class="col-sm-3 control-label">Batu kapur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_batu_kapur" name="data[anggota][0][galian][batu_kapur][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["batu_kapur"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_kapur" name="data[anggota][0][galian][batu_kapur][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["batu_kapur"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_kapur" name="data[anggota][0][galian][batu_kapur][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["batu_kapur"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_kapur" name="data[anggota][0][galian][batu_kapur][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["batu_kapur"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_pasir" class="col-sm-3 control-label">Pasir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_pasir" name="data[anggota][0][galian][pasir][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["pasir"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir" name="data[anggota][0][galian][pasir][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["pasir"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir" name="data[anggota][0][galian][pasir][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["pasir"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir" name="data[anggota][0][galian][pasir][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["pasir"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_emas" class="col-sm-3 control-label">Emas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_emas" name="data[anggota][0][galian][emas][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["emas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_emas" name="data[anggota][0][galian][emas][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["emas"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_emas" name="data[anggota][0][galian][emas][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["emas"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_emas" name="data[anggota][0][galian][emas][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["emas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_kuningan" class="col-sm-3 control-label">Kuningan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_kuningan" name="data[anggota][0][galian][kuningan][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["kuningan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_kuningan" name="data[anggota][0][galian][kuningan][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["kuningan"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_kuningan" name="data[anggota][0][galian][kuningan][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["kuningan"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_kuningan" name="data[anggota][0][galian][kuningan][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["kuningan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_aluminium" class="col-sm-3 control-label">Aluminium</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_aluminium" name="data[anggota][0][galian][aluminium][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["aluminium"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_aluminium" name="data[anggota][0][galian][aluminium][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["aluminium"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_aluminium" name="data[anggota][0][galian][aluminium][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["aluminium"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_aluminium" name="data[anggota][0][galian][aluminium][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["aluminium"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_perunggu" class="col-sm-3 control-label">Perunggu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_perunggu" name="data[anggota][0][galian][perunggu][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["perunggu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_perunggu" name="data[anggota][0][galian][perunggu][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["perunggu"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_perunggu" name="data[anggota][0][galian][perunggu][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["perunggu"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_perunggu" name="data[anggota][0][galian][perunggu][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["perunggu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_belerang" class="col-sm-3 control-label">Belerang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_belerang" name="data[anggota][0][galian][belerang][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["belerang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_belerang" name="data[anggota][0][galian][belerang][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["belerang"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_belerang" name="data[anggota][0][galian][belerang][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["belerang"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_belerang" name="data[anggota][0][galian][belerang][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["belerang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_batu_marmer" class="col-sm-3 control-label">Batu marmer</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_batu_marmer" name="data[anggota][0][galian][batu_marmer][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["batu_marmer"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_marmer" name="data[anggota][0][galian][batu_marmer][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["batu_marmer"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_marmer" name="data[anggota][0][galian][batu_marmer][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["batu_marmer"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_marmer" name="data[anggota][0][galian][batu_marmer][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["batu_marmer"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_batu_cadas" class="col-sm-3 control-label">Batu cadas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_batu_cadas" name="data[anggota][0][galian][batu_cadas][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["batu_cadas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_cadas" name="data[anggota][0][galian][batu_cadas][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["batu_cadas"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_cadas" name="data[anggota][0][galian][batu_cadas][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["batu_cadas"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_cadas" name="data[anggota][0][galian][batu_cadas][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["batu_cadas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_batu_apung" class="col-sm-3 control-label">Batu apung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_batu_apung" name="data[anggota][0][galian][batu_apung][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["batu_apung"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_apung" name="data[anggota][0][galian][batu_apung][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["batu_apung"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_apung" name="data[anggota][0][galian][batu_apung][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["batu_apung"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_apung" name="data[anggota][0][galian][batu_apung][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["batu_apung"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_pasir_kwarsa" class="col-sm-3 control-label">Pasir kwarsa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_pasir_kwarsa" name="data[anggota][0][galian][pasir_kwarsa][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["pasir_kwarsa"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir_kwarsa" name="data[anggota][0][galian][pasir_kwarsa][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["pasir_kwarsa"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir_kwarsa" name="data[anggota][0][galian][pasir_kwarsa][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["pasir_kwarsa"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir_kwarsa" name="data[anggota][0][galian][pasir_kwarsa][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["pasir_kwarsa"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_batubara" class="col-sm-3 control-label">Batubara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_batubara" name="data[anggota][0][galian][batubara][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["batubara"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batubara" name="data[anggota][0][galian][batubara][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["batubara"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batubara" name="data[anggota][0][galian][batubara][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["batubara"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batubara" name="data[anggota][0][galian][batubara][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["batubara"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_batu_granit" class="col-sm-3 control-label">Batu Granit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_batu_granit" name="data[anggota][0][galian][batu_granit][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["batu_granit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_granit" name="data[anggota][0][galian][batu_granit][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["batu_granit"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_granit" name="data[anggota][0][galian][batu_granit][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["batu_granit"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_granit" name="data[anggota][0][galian][batu_granit][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["batu_granit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_batu_gamping" class="col-sm-3 control-label">Batu Gamping</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_batu_gamping" name="data[anggota][0][galian][batu_gamping][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["batu_gamping"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_gamping" name="data[anggota][0][galian][batu_gamping][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["batu_gamping"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_gamping" name="data[anggota][0][galian][batu_gamping][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["batu_gamping"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_gamping" name="data[anggota][0][galian][batu_gamping][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["batu_gamping"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_mangan" class="col-sm-3 control-label">Mangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_mangan" name="data[anggota][0][galian][mangan][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["mangan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_mangan" name="data[anggota][0][galian][mangan][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["mangan"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_mangan" name="data[anggota][0][galian][mangan][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["mangan"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_mangan" name="data[anggota][0][galian][mangan][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["mangan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_batu_trass" class="col-sm-3 control-label">Batu Trass</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_batu_trass" name="data[anggota][0][galian][batu_trass][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["batu_trass"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_trass" name="data[anggota][0][galian][batu_trass][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["batu_trass"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_trass" name="data[anggota][0][galian][batu_trass][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["batu_trass"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_trass" name="data[anggota][0][galian][batu_trass][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["batu_trass"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_batu_putih" class="col-sm-3 control-label">Batu Putih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_batu_putih" name="data[anggota][0][galian][batu_putih][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["batu_putih"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_putih" name="data[anggota][0][galian][batu_putih][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["batu_putih"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_putih" name="data[anggota][0][galian][batu_putih][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["batu_putih"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_batu_putih" name="data[anggota][0][galian][batu_putih][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["batu_putih"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_pasir_batu" class="col-sm-3 control-label">Pasir Batu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_pasir_batu" name="data[anggota][0][galian][pasir_batu][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["pasir_batu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir_batu" name="data[anggota][0][galian][pasir_batu][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["pasir_batu"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir_batu" name="data[anggota][0][galian][pasir_batu][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["pasir_batu"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir_batu" name="data[anggota][0][galian][pasir_batu][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["pasir_batu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_pasir_besi" class="col-sm-3 control-label">Pasir Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_pasir_besi" name="data[anggota][0][galian][pasir_besi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["pasir_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir_besi" name="data[anggota][0][galian][pasir_besi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["pasir_besi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir_besi" name="data[anggota][0][galian][pasir_besi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["pasir_besi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_pasir_besi" name="data[anggota][0][galian][pasir_besi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["pasir_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_gips" class="col-sm-3 control-label">Gips</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_gips" name="data[anggota][0][galian][gips][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["gips"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_gips" name="data[anggota][0][galian][gips][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["gips"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_gips" name="data[anggota][0][galian][gips][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["gips"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_gips" name="data[anggota][0][galian][gips][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["gips"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_minyak_bumi" class="col-sm-3 control-label">Minyak Bumi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_minyak_bumi" name="data[anggota][0][galian][minyak_bumi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["minyak_bumi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_minyak_bumi" name="data[anggota][0][galian][minyak_bumi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["minyak_bumi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_minyak_bumi" name="data[anggota][0][galian][minyak_bumi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["minyak_bumi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_minyak_bumi" name="data[anggota][0][galian][minyak_bumi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["minyak_bumi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_gas_alam" class="col-sm-3 control-label">Gas Alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_gas_alam" name="data[anggota][0][galian][gas_alam][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["gas_alam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_gas_alam" name="data[anggota][0][galian][gas_alam][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["gas_alam"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_gas_alam" name="data[anggota][0][galian][gas_alam][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["gas_alam"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_gas_alam" name="data[anggota][0][galian][gas_alam][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["gas_alam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_perak" class="col-sm-3 control-label">Perak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_perak" name="data[anggota][0][galian][perak][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["perak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_perak" name="data[anggota][0][galian][perak][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["perak"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_perak" name="data[anggota][0][galian][perak][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["perak"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_perak" name="data[anggota][0][galian][perak][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["perak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_timah" class="col-sm-3 control-label">Timah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_timah" name="data[anggota][0][galian][timah][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["timah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_timah" name="data[anggota][0][galian][timah][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["timah"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_timah" name="data[anggota][0][galian][timah][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["timah"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_timah" name="data[anggota][0][galian][timah][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["timah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_tembaga" class="col-sm-3 control-label">Tembaga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_tembaga" name="data[anggota][0][galian][tembaga][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["tembaga"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_tembaga" name="data[anggota][0][galian][tembaga][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["tembaga"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_tembaga" name="data[anggota][0][galian][tembaga][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["tembaga"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_tembaga" name="data[anggota][0][galian][tembaga][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["tembaga"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_biji_besi" class="col-sm-3 control-label">Biji Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_biji_besi" name="data[anggota][0][galian][biji_besi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["biji_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_biji_besi" name="data[anggota][0][galian][biji_besi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["biji_besi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_biji_besi" name="data[anggota][0][galian][biji_besi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["biji_besi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_biji_besi" name="data[anggota][0][galian][biji_besi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["biji_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_uranium" class="col-sm-3 control-label">Uranium</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_uranium" name="data[anggota][0][galian][uranium][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["uranium"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_uranium" name="data[anggota][0][galian][uranium][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["uranium"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_uranium" name="data[anggota][0][galian][uranium][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["uranium"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_uranium" name="data[anggota][0][galian][uranium][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["uranium"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_bouxit" class="col-sm-3 control-label">Bouxit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_bouxit" name="data[anggota][0][galian][bouxit][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["bouxit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_bouxit" name="data[anggota][0][galian][bouxit][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["bouxit"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_bouxit" name="data[anggota][0][galian][bouxit][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["bouxit"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_bouxit" name="data[anggota][0][galian][bouxit][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["bouxit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_garam" class="col-sm-3 control-label">Garam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_garam" name="data[anggota][0][galian][garam][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["garam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_garam" name="data[anggota][0][galian][garam][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["garam"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_garam" name="data[anggota][0][galian][garam][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["garam"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_garam" name="data[anggota][0][galian][garam][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["garam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_nikel" class="col-sm-3 control-label">Nikel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_nikel" name="data[anggota][0][galian][nikel][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["nikel"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_nikel" name="data[anggota][0][galian][nikel][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["nikel"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_nikel" name="data[anggota][0][galian][nikel][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["nikel"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_nikel" name="data[anggota][0][galian][nikel][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["nikel"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota1_galian_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota1_galian_lainnya" name="data[anggota][0][galian][lainnya][keterangan]" placeholder="Keterangan" value="<?php echo $ddk->anggota[0]["galian"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_lainnya" name="data[anggota][0][galian][lainnya][opsi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[0]["galian"]["lainnya"]["opsi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_lainnya" name="data[anggota][0][galian][lainnya][opsi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[0]["galian"]["lainnya"]["opsi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_lainnya" name="data[anggota][0][galian][lainnya][opsi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[0]["galian"]["lainnya"]["opsi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota1_galian_lainnya" name="data[anggota][0][galian][lainnya][opsi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[0]["galian"]["lainnya"]["opsi"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Data Anggota Keluarga 2</strong></h4>
				<h4>Biodata</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_no_urut" class="col-sm-3 control-label">Nomor Urut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_no_urut" name="data[anggota][1][no_urut]" placeholder="Nomor Urut" value="<?php echo $ddk->anggota[1]["no_urut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_nik" class="col-sm-3 control-label">Nomor Induk Kependudukan (NIK)</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_nik" name="data[anggota][1][nik]" placeholder="Nomor Induk Kependudukan (NIK)" value="<?php echo $ddk->anggota[1]["nik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_nama" class="col-sm-3 control-label">Nama Lengkap</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_nama" name="data[anggota][1][nama]" placeholder="Nama Lengkap" value="<?php echo $ddk->anggota[1]["nama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_no_akte" class="col-sm-3 control-label">Nomor Akte Kelahiran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_no_akte" name="data[anggota][1][no_akte]" placeholder="Nomor Akte Kelahiran" value="<?php echo $ddk->anggota[1]["no_akte"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_jenis_kelamin" class="col-sm-3 control-label">Jenis Kelamin</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][1][jenis_kelamin]" id="anggota2_jenis_kelamin">
					<option value="laki" <?php echo $ddk->anggota[1]["jenis_kelamin"] == "laki" ? "selected" : ""; ?>>Laki-laki</option>
					<option value="perempuan" <?php echo $ddk->anggota[1]["jenis_kelamin"] == "perempuan" ? "selected" : ""; ?>>Perempuan</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_hubungan" class="col-sm-3 control-label">Hubungan dengan Kepala Keluarga</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][1][hubungan]" id="anggota2_hubungan">
					<option value="istri" <?php echo $ddk->anggota[1]["hubungan"] == "istri" ? "selected" : ""; ?>>Istri</option>
					<option value="suami" <?php echo $ddk->anggota[1]["hubungan"] == "suami" ? "selected" : ""; ?>>Suami</option>
					<option value="anak" <?php echo $ddk->anggota[1]["hubungan"] == "anak" ? "selected" : ""; ?>>Anak</option>
					<option value="cucu" <?php echo $ddk->anggota[1]["hubungan"] == "cucu" ? "selected" : ""; ?>>Cucu</option>
					<option value="mertua" <?php echo $ddk->anggota[1]["hubungan"] == "mertua" ? "selected" : ""; ?>>Mertua</option>
					<option value="menantu" <?php echo $ddk->anggota[1]["hubungan"] == "menantu" ? "selected" : ""; ?>>Menantu</option>
					<option value="keponakan" <?php echo $ddk->anggota[1]["hubungan"] == "keponakan" ? "selected" : ""; ?>>Keponakan</option>
					<option value="lainnya" <?php echo $ddk->anggota[1]["hubungan"] == "lainnya" ? "selected" : ""; ?>>Lainnya</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_tempat_lahir" class="col-sm-3 control-label">Tempat Lahir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_tempat_lahir" name="data[anggota][1][tempat_lahir]" placeholder="Tempat Lahir" value="<?php echo $ddk->anggota[1]["tempat_lahir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_tanggal_lahir" class="col-sm-3 control-label">Tanggal Lahir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="anggota2_tanggal_lahir" name="data[anggota][1][tanggal_lahir]" placeholder="Tanggal Lahir">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_tanggal_pencatatan" class="col-sm-3 control-label">Tanggal Pencatatan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="anggota2_tanggal_pencatatan" name="data[anggota][1][tanggal_pencatatan]" placeholder="Tanggal Pencatatan">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_status_kawin" class="col-sm-3 control-label">Status Perkawinan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][1][status_kawin]" id="anggota2_status_kawin">
					<option value="kawin" <?php echo $ddk->anggota[1]["status_kawin"] == "kawin" ? "selected" : ""; ?>>Kawin</option>
					<option value="belum" <?php echo $ddk->anggota[1]["status_kawin"] == "belum" ? "selected" : ""; ?>>Belum Kawin</option>
					<option value="pernah" <?php echo $ddk->anggota[1]["status_kawin"] == "pernah" ? "selected" : ""; ?>>Pernah Kawin</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_agama" class="col-sm-3 control-label">Agama dan Aliran Kepercayaan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][1][agama]" id="anggota2_agama">
					<option value="islam" <?php echo $ddk->anggota[1]["agama"] == "islam" ? "selected" : ""; ?>>Islam</option>
					<option value="protestan" <?php echo $ddk->anggota[1]["agama"] == "protestan" ? "selected" : ""; ?>>Protestan</option>
					<option value="katolik" <?php echo $ddk->anggota[1]["agama"] == "katolik" ? "selected" : ""; ?>>Katolik</option>
					<option value="hindu" <?php echo $ddk->anggota[1]["agama"] == "hindu" ? "selected" : ""; ?>>Hindu</option>
					<option value="budha" <?php echo $ddk->anggota[1]["agama"] == "budha" ? "selected" : ""; ?>>Budha</option>
					<option value="kong hu chu" <?php echo $ddk->anggota[1]["agama"] == "kong hu chu" ? "selected" : ""; ?>>Kong Hu Chu</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_darah" class="col-sm-3 control-label">Golongan Darah</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][1][darah]" id="anggota2_darah">
					<option value="O" <?php echo $ddk->anggota[1]["darah"] == "O" ? "selected" : ""; ?>>O</option>
					<option value="A" <?php echo $ddk->anggota[1]["darah"] == "A" ? "selected" : ""; ?>>A</option>
					<option value="B" <?php echo $ddk->anggota[1]["darah"] == "B" ? "selected" : ""; ?>>B</option>
					<option value="AB" <?php echo $ddk->anggota[1]["darah"] == "AB" ? "selected" : ""; ?>>AB</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kewarganegaraan" class="col-sm-3 control-label">Kewarganegaraan/Etnis/Suku</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kewarganegaraan" name="data[anggota][1][kewarganegaraan]" placeholder="Kewarganegaraan/Etnis/Suku" value="<?php echo $ddk->anggota[1]["kewarganegaraan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pendidikan" class="col-sm-3 control-label">Pendidikan Umum Terakhir</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][1][pendidikan]" id="anggota2_pendidikan">
					<option value="SD" <?php echo $ddk->anggota[1]["pendidikan"] == "SD" ? "selected" : ""; ?>>SD</option>
					<option value="SMP" <?php echo $ddk->anggota[1]["pendidikan"] == "SMP" ? "selected" : ""; ?>>SMP</option>
					<option value="SMA" <?php echo $ddk->anggota[1]["pendidikan"] == "SMA" ? "selected" : ""; ?>>SMA</option>
					<option value="Diploma" <?php echo $ddk->anggota[1]["pendidikan"] == "Diploma" ? "selected" : ""; ?>>Diploma</option>
					<option value="S1" <?php echo $ddk->anggota[1]["pendidikan"] == "S1" ? "selected" : ""; ?>>S1</option>
					<option value="S2" <?php echo $ddk->anggota[1]["pendidikan"] == "S2" ? "selected" : ""; ?>>S2</option>
					<option value="S3" <?php echo $ddk->anggota[1]["pendidikan"] == "S3" ? "selected" : ""; ?>>S3</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pekerjaan" class="col-sm-3 control-label">Mata Pencaharian Pokok/Pekerjaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pekerjaan" name="data[anggota][1][pekerjaan]" placeholder="Mata Pencaharian Pokok/Pekerjaan" value="<?php echo $ddk->anggota[1]["pekerjaan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_nama_ortu" class="col-sm-3 control-label">Nama Bapak / Ibu Kandung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_nama_ortu" name="data[anggota][1][nama_ortu]" placeholder="Nama Bapak / Ibu Kandung" value="<?php echo $ddk->anggota[1]["nama_ortu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kb" class="col-sm-3 control-label">Akseptor KB</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][1][kb]" id="anggota2_kb">
					<option value="Pil" <?php echo $ddk->anggota[1]["kb"] == "Pil" ? "selected" : ""; ?>>Pil</option>
					<option value="Spiral" <?php echo $ddk->anggota[1]["kb"] == "Spiral" ? "selected" : ""; ?>>Spiral</option>
					<option value="Suntik" <?php echo $ddk->anggota[1]["kb"] == "Suntik" ? "selected" : ""; ?>>Suntik</option>
					<option value="Susuk" <?php echo $ddk->anggota[1]["kb"] == "Susuk" ? "selected" : ""; ?>>Susuk</option>
					<option value="Kondom" <?php echo $ddk->anggota[1]["kb"] == "Kondom" ? "selected" : ""; ?>>Kondom</option>
					<option value="Vaksetomi" <?php echo $ddk->anggota[1]["kb"] == "Vaksetomi" ? "selected" : ""; ?>>Vaksetomi</option>
					<option value="Tubektomi" <?php echo $ddk->anggota[1]["kb"] == "Tubektomi" ? "selected" : ""; ?>>Tubektomi</option>
				</select>
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Cacat Menurut Jenis</strong></h4>
				<h4>Cacat Fisik</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_cacat_fisik_tuli" class="col-sm-3 control-label">Tuna rungu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_cacat_fisik_tuli" name="data[anggota][1][cacat_fisik][tuli]" placeholder="Tuna rungu" value="<?php echo $ddk->anggota[1]["cacat_fisik"]["tuli"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_cacat_fisik_bisu" class="col-sm-3 control-label">Tuna wicara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_cacat_fisik_bisu" name="data[anggota][1][cacat_fisik][bisu]" placeholder="Tuna wicara" value="<?php echo $ddk->anggota[1]["cacat_fisik"]["bisu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_cacat_fisik_buta" class="col-sm-3 control-label">Tuna netra</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_cacat_fisik_buta" name="data[anggota][1][cacat_fisik][buta]" placeholder="Tuna netra" value="<?php echo $ddk->anggota[1]["cacat_fisik"]["buta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_cacat_fisik_lumpuh" class="col-sm-3 control-label">Lumpuh</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_cacat_fisik_lumpuh" name="data[anggota][1][cacat_fisik][lumpuh]" placeholder="Lumpuh" value="<?php echo $ddk->anggota[1]["cacat_fisik"]["lumpuh"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_cacat_fisik_sumbing" class="col-sm-3 control-label">Sumbing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_cacat_fisik_sumbing" name="data[anggota][1][cacat_fisik][sumbing]" placeholder="Sumbing" value="<?php echo $ddk->anggota[1]["cacat_fisik"]["sumbing"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_cacat_fisik_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_cacat_fisik_lainnya" name="data[anggota][1][cacat_fisik][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[1]["cacat_fisik"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_cacat_fisik_lainnya" name="data[anggota][1][cacat_fisik][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[1]["cacat_fisik"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4>Cacat Mental</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_cacat_mental_idiot" class="col-sm-3 control-label">Idiot</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_cacat_mental_idiot" name="data[anggota][1][cacat_mental][idiot]" placeholder="Idiot" value="<?php echo $ddk->anggota[1]["cacat_mental"]["idiot"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_cacat_mental_gila" class="col-sm-3 control-label">Gila</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_cacat_mental_gila" name="data[anggota][1][cacat_mental][gila]" placeholder="Gila" value="<?php echo $ddk->anggota[1]["cacat_mental"]["gila"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_cacat_mental_stress" class="col-sm-3 control-label">Stress</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_cacat_mental_stress" name="data[anggota][1][cacat_mental][stress]" placeholder="Stress" value="<?php echo $ddk->anggota[1]["cacat_mental"]["stress"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_cacat_mental_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_cacat_mental_lainnya" name="data[anggota][1][cacat_mental][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[1]["cacat_mental"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_cacat_mental_lainnya" name="data[anggota][1][cacat_mental][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[1]["cacat_mental"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Kedudukan Anggota Keluarga sebagai Wajib Pajak dan Retribusi</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pajak_retribusi_pbb" class="col-sm-3 control-label">Wajib Pajak Bumi dan Bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pajak_retribusi_pbb" name="data[anggota][1][pajak_retribusi][pbb]" placeholder="Wajib Pajak Bumi dan Bangunan" value="<?php echo $ddk->anggota[1]["pajak_retribusi"]["pbb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pajak_retribusi_ppp" class="col-sm-3 control-label">Wajib Pajak Penghasilan Perorangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pajak_retribusi_ppp" name="data[anggota][1][pajak_retribusi][ppp]" placeholder="Wajib Pajak Penghasilan Perorangan" value="<?php echo $ddk->anggota[1]["pajak_retribusi"]["ppp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pajak_retribusi_pb" class="col-sm-3 control-label">Wajib Pajak Badan/Perusahaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pajak_retribusi_pb" name="data[anggota][1][pajak_retribusi][pb]" placeholder="Wajib Pajak Badan/Perusahaan" value="<?php echo $ddk->anggota[1]["pajak_retribusi"]["pb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pajak_retribusi_pkb" class="col-sm-3 control-label">Wajib Pajak Kendaraan Bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pajak_retribusi_pkb" name="data[anggota][1][pajak_retribusi][pkb]" placeholder="Wajib Pajak Kendaraan Bermotor" value="<?php echo $ddk->anggota[1]["pajak_retribusi"]["pkb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pajak_retribusi_kebersihan" class="col-sm-3 control-label">Wajib Retribusi Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pajak_retribusi_kebersihan" name="data[anggota][1][pajak_retribusi][kebersihan]" placeholder="Wajib Retribusi Kebersihan" value="<?php echo $ddk->anggota[1]["pajak_retribusi"]["kebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pajak_retribusi_keamanan" class="col-sm-3 control-label">Wajib Retribusi Keamanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pajak_retribusi_keamanan" name="data[anggota][1][pajak_retribusi][keamanan]" placeholder="Wajib Retribusi Keamanan" value="<?php echo $ddk->anggota[1]["pajak_retribusi"]["keamanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pajak_retribusi_iuran" class="col-sm-3 control-label">Wajib iuran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pajak_retribusi_iuran" name="data[anggota][1][pajak_retribusi][iuran]" placeholder="Wajib iuran" value="<?php echo $ddk->anggota[1]["pajak_retribusi"]["iuran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pajak_retribusi_pungutan" class="col-sm-3 control-label">Wajib pungutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pajak_retribusi_pungutan" name="data[anggota][1][pajak_retribusi][pungutan]" placeholder="Wajib pungutan" value="<?php echo $ddk->anggota[1]["pajak_retribusi"]["pungutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pajak_retribusi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pajak_retribusi_lainnya" name="data[anggota][1][pajak_retribusi][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[1]["pajak_retribusi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_pajak_retribusi_lainnya" name="data[anggota][1][pajak_retribusi][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[1]["pajak_retribusi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Pemerintahan Yang Diikuti Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pemerintahan_kepala_desa" class="col-sm-3 control-label">Kepala Desa/Lurah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pemerintahan_kepala_desa" name="data[anggota][1][pemerintahan][kepala_desa]" placeholder="Kepala Desa/Lurah" value="<?php echo $ddk->anggota[1]["pemerintahan"]["kepala_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pemerintahan_sekretaris_desa" class="col-sm-3 control-label">Sekretaris Desa/Kelurahan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pemerintahan_sekretaris_desa" name="data[anggota][1][pemerintahan][sekretaris_desa]" placeholder="Sekretaris Desa/Kelurahan" value="<?php echo $ddk->anggota[1]["pemerintahan"]["sekretaris_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pemerintahan_kepala_urusan" class="col-sm-3 control-label">Kepala Urusan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pemerintahan_kepala_urusan" name="data[anggota][1][pemerintahan][kepala_urusan]" placeholder="Kepala Urusan" value="<?php echo $ddk->anggota[1]["pemerintahan"]["kepala_urusan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pemerintahan_kepala_dusun" class="col-sm-3 control-label">Kepala Dusun/Lingkungan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pemerintahan_kepala_dusun" name="data[anggota][1][pemerintahan][kepala_dusun]" placeholder="Kepala Dusun/Lingkungan" value="<?php echo $ddk->anggota[1]["pemerintahan"]["kepala_dusun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pemerintahan_staf_desa" class="col-sm-3 control-label">Staf Desa/Kelurahan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pemerintahan_staf_desa" name="data[anggota][1][pemerintahan][staf_desa]" placeholder="Staf Desa/Kelurahan" value="<?php echo $ddk->anggota[1]["pemerintahan"]["staf_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pemerintahan_ketua_bpd" class="col-sm-3 control-label">Ketua BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pemerintahan_ketua_bpd" name="data[anggota][1][pemerintahan][ketua_bpd]" placeholder="Ketua BPD" value="<?php echo $ddk->anggota[1]["pemerintahan"]["ketua_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pemerintahan_wakil_ketua_bpd" class="col-sm-3 control-label">Wakil Ketua BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pemerintahan_wakil_ketua_bpd" name="data[anggota][1][pemerintahan][wakil_ketua_bpd]" placeholder="Wakil Ketua BPD" value="<?php echo $ddk->anggota[1]["pemerintahan"]["wakil_ketua_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pemerintahan_sekretaris_bpd" class="col-sm-3 control-label">Sekretaris BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pemerintahan_sekretaris_bpd" name="data[anggota][1][pemerintahan][sekretaris_bpd]" placeholder="Sekretaris BPD" value="<?php echo $ddk->anggota[1]["pemerintahan"]["sekretaris_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pemerintahan_anggota_bpd" class="col-sm-3 control-label">Anggota BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pemerintahan_anggota_bpd" name="data[anggota][1][pemerintahan][anggota_bpd]" placeholder="Anggota BPD" value="<?php echo $ddk->anggota[1]["pemerintahan"]["anggota_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_pemerintahan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_pemerintahan_lainnya" name="data[anggota][1][pemerintahan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[1]["pemerintahan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_pemerintahan_lainnya" name="data[anggota][1][pemerintahan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[1]["pemerintahan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Kemasyarakatan Yang Diikuti Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_prt" class="col-sm-3 control-label">Pengurus RT</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_prt" name="data[anggota][1][kemasyarakatan][prt]" placeholder="Pengurus RT" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["prt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aprt" class="col-sm-3 control-label">Anggota Pengurus RT</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aprt" name="data[anggota][1][kemasyarakatan][aprt]" placeholder="Anggota Pengurus RT" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aprt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_prw" class="col-sm-3 control-label">Pengurus RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_prw" name="data[anggota][1][kemasyarakatan][prw]" placeholder="Pengurus RW" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["prw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aprw" class="col-sm-3 control-label">Anggota Pengurus RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aprw" name="data[anggota][1][kemasyarakatan][aprw]" placeholder="Anggota Pengurus RW" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aprw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_plkmdklpm" class="col-sm-3 control-label">Pengurus LKMD/K/LPM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_plkmdklpm" name="data[anggota][1][kemasyarakatan][plkmdklpm]" placeholder="Pengurus LKMD/K/LPM" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["plkmdklpm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_alkmdklpm" class="col-sm-3 control-label">Anggota LKMD/K/LPM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_alkmdklpm" name="data[anggota][1][kemasyarakatan][alkmdklpm]" placeholder="Anggota LKMD/K/LPM" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["alkmdklpm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_ppkk" class="col-sm-3 control-label">Pengurus PKK</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_ppkk" name="data[anggota][1][kemasyarakatan][ppkk]" placeholder="Pengurus PKK" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["ppkk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_apkk" class="col-sm-3 control-label">Anggota PKK</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_apkk" name="data[anggota][1][kemasyarakatan][apkk]" placeholder="Anggota PKK" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["apkk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pla" class="col-sm-3 control-label">Pengurus Lembaga Adat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pla" name="data[anggota][1][kemasyarakatan][pla]" placeholder="Pengurus Lembaga Adat" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pla"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pkt" class="col-sm-3 control-label">Pengurus Karang Taruna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pkt" name="data[anggota][1][kemasyarakatan][pkt]" placeholder="Pengurus Karang Taruna" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pkt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_akt" class="col-sm-3 control-label">Anggota Karang Taruna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_akt" name="data[anggota][1][kemasyarakatan][akt]" placeholder="Anggota Karang Taruna" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["akt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_phl" class="col-sm-3 control-label">Pengurus Hansip/Linmas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_phl" name="data[anggota][1][kemasyarakatan][phl]" placeholder="Pengurus Hansip/Linmas" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["phl"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pp" class="col-sm-3 control-label">Pengurus Poskamling</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pp" name="data[anggota][1][kemasyarakatan][pp]" placeholder="Pengurus Poskamling" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pop" class="col-sm-3 control-label">Pengurus Organisasi Perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pop" name="data[anggota][1][kemasyarakatan][pop]" placeholder="Pengurus Organisasi Perempuan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aop" class="col-sm-3 control-label">Anggota Organisasi Perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aop" name="data[anggota][1][kemasyarakatan][aop]" placeholder="Anggota Organisasi Perempuan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pob" class="col-sm-3 control-label">Pengurus Organisasi Bapak-bapak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pob" name="data[anggota][1][kemasyarakatan][pob]" placeholder="Pengurus Organisasi Bapak-bapak" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pob"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aob" class="col-sm-3 control-label">Anggota Organisasi Bapak-bapak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aob" name="data[anggota][1][kemasyarakatan][aob]" placeholder="Anggota Organisasi Bapak-bapak" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aob"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pok" class="col-sm-3 control-label">Pengurus Organisasi keagamaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pok" name="data[anggota][1][kemasyarakatan][pok]" placeholder="Pengurus Organisasi keagamaan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aok" class="col-sm-3 control-label">Anggota Organisasi keagamaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aok" name="data[anggota][1][kemasyarakatan][aok]" placeholder="Anggota Organisasi keagamaan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_popw" class="col-sm-3 control-label">Pengurus Organisasi profesi wartawan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_popw" name="data[anggota][1][kemasyarakatan][popw]" placeholder="Pengurus Organisasi profesi wartawan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["popw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aopw" class="col-sm-3 control-label">Anggota Organisasi profesi wartawan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aopw" name="data[anggota][1][kemasyarakatan][aopw]" placeholder="Anggota Organisasi profesi wartawan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aopw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pposyandu" class="col-sm-3 control-label">Pengurus Posyandu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pposyandu" name="data[anggota][1][kemasyarakatan][pposyandu]" placeholder="Pengurus Posyandu" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pposyandu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pposyantekdes" class="col-sm-3 control-label">Pengurus Posyantekdes</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pposyantekdes" name="data[anggota][1][kemasyarakatan][pposyantekdes]" placeholder="Pengurus Posyantekdes" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pposyantekdes"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_poktan" class="col-sm-3 control-label">Pengurus Organisasi Kelompok Tani/Nelayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_poktan" name="data[anggota][1][kemasyarakatan][poktan]" placeholder="Pengurus Organisasi Kelompok Tani/Nelayan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["poktan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aoktan" class="col-sm-3 control-label">Anggota Organisasi Kelompok Tani/Nelayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aoktan" name="data[anggota][1][kemasyarakatan][aoktan]" placeholder="Anggota Organisasi Kelompok Tani/Nelayan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aoktan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_plgr" class="col-sm-3 control-label">Pengurus Lembaga Gotong royong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_plgr" name="data[anggota][1][kemasyarakatan][plgr]" placeholder="Pengurus Lembaga Gotong royong" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["plgr"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_algr" class="col-sm-3 control-label">Anggota Lembaga Gotong royong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_algr" name="data[anggota][1][kemasyarakatan][algr]" placeholder="Anggota Lembaga Gotong royong" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["algr"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_popg" class="col-sm-3 control-label">Pengurus Organisasi Profesi guru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_popg" name="data[anggota][1][kemasyarakatan][popg]" placeholder="Pengurus Organisasi Profesi guru" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["popg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aopg" class="col-sm-3 control-label">Anggota Organisasi Profesi guru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aopg" name="data[anggota][1][kemasyarakatan][aopg]" placeholder="Anggota Organisasi Profesi guru" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aopg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_popdtm" class="col-sm-3 control-label">Pengurus Organisasi profesi dokter/tenaga medis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_popdtm" name="data[anggota][1][kemasyarakatan][popdtm]" placeholder="Pengurus Organisasi profesi dokter/tenaga medis" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["popdtm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aoptm" class="col-sm-3 control-label">Anggota Organisasi profesi/tenaga medis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aoptm" name="data[anggota][1][kemasyarakatan][aoptm]" placeholder="Anggota Organisasi profesi/tenaga medis" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aoptm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_popensiun" class="col-sm-3 control-label">Pengurus organisasi pensiunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_popensiun" name="data[anggota][1][kemasyarakatan][popensiun]" placeholder="Pengurus organisasi pensiunan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["popensiun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aopensiun" class="col-sm-3 control-label">Anggota organisasi pensiunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aopensiun" name="data[anggota][1][kemasyarakatan][aopensiun]" placeholder="Anggota organisasi pensiunan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aopensiun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_popp" class="col-sm-3 control-label">Pengurus organisasi pemirsa/pendengar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_popp" name="data[anggota][1][kemasyarakatan][popp]" placeholder="Pengurus organisasi pemirsa/pendengar" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["popp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aopp" class="col-sm-3 control-label">Anggota organisasi pemirsa/pendengar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aopp" name="data[anggota][1][kemasyarakatan][aopp]" placeholder="Anggota organisasi pemirsa/pendengar" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aopp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_plpa" class="col-sm-3 control-label">Pengurus lembaga pencinta alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_plpa" name="data[anggota][1][kemasyarakatan][plpa]" placeholder="Pengurus lembaga pencinta alam" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["plpa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_alpa" class="col-sm-3 control-label">Anggota organisasi pencinta alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_alpa" name="data[anggota][1][kemasyarakatan][alpa]" placeholder="Anggota organisasi pencinta alam" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["alpa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_popip" class="col-sm-3 control-label">Pengurus organisasi pengembangan ilmu pengetahuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_popip" name="data[anggota][1][kemasyarakatan][popip]" placeholder="Pengurus organisasi pengembangan ilmu pengetahuan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["popip"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_aopip" class="col-sm-3 control-label">Anggota organisasi pengembangan ilmu pengetaahuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_aopip" name="data[anggota][1][kemasyarakatan][aopip]" placeholder="Anggota organisasi pengembangan ilmu pengetaahuan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["aopip"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pemyaya" class="col-sm-3 control-label">Pemilik yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pemyaya" name="data[anggota][1][kemasyarakatan][pemyaya]" placeholder="Pemilik yayasan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pemyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_penyaya" class="col-sm-3 control-label">Pengurus yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_penyaya" name="data[anggota][1][kemasyarakatan][penyaya]" placeholder="Pengurus yayasan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["penyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_angyaya" class="col-sm-3 control-label">Anggota yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_angyaya" name="data[anggota][1][kemasyarakatan][angyaya]" placeholder="Anggota yayasan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["angyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pkebersihan" class="col-sm-3 control-label">Pengurus Satgas Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pkebersihan" name="data[anggota][1][kemasyarakatan][pkebersihan]" placeholder="Pengurus Satgas Kebersihan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pkebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_akebersihan" class="col-sm-3 control-label">Anggota Satgas Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_akebersihan" name="data[anggota][1][kemasyarakatan][akebersihan]" placeholder="Anggota Satgas Kebersihan" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["akebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_pkebakaran" class="col-sm-3 control-label">Pengurus Satgas Kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_pkebakaran" name="data[anggota][1][kemasyarakatan][pkebakaran]" placeholder="Pengurus Satgas Kebakaran" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["pkebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_akebakaran" class="col-sm-3 control-label">Anggota Satgas Kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_akebakaran" name="data[anggota][1][kemasyarakatan][akebakaran]" placeholder="Anggota Satgas Kebakaran" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["akebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_ppb" class="col-sm-3 control-label">Pengurus Posko Penanggulangan Bencana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_ppb" name="data[anggota][1][kemasyarakatan][ppb]" placeholder="Pengurus Posko Penanggulangan Bencana" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["ppb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_atpb" class="col-sm-3 control-label">Anggota Tim Penanggulangan Bencana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_atpb" name="data[anggota][1][kemasyarakatan][atpb]" placeholder="Anggota Tim Penanggulangan Bencana" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["atpb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_kemasyarakatan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_lainnya" name="data[anggota][1][kemasyarakatan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_kemasyarakatan_lainnya" name="data[anggota][1][kemasyarakatan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[1]["kemasyarakatan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Ekonomi Yang Dimiliki Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_koperasi" class="col-sm-3 control-label">Koperasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_koperasi" name="data[anggota][1][ekonomi][koperasi]" placeholder="Koperasi" value="<?php echo $ddk->anggota[1]["ekonomi"]["koperasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_unit_usaha_simpan_pinjam" class="col-sm-3 control-label">Unit Usaha Simpan Pinjam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_unit_usaha_simpan_pinjam" name="data[anggota][1][ekonomi][unit_usaha_simpan_pinjam]" placeholder="Unit Usaha Simpan Pinjam" value="<?php echo $ddk->anggota[1]["ekonomi"]["unit_usaha_simpan_pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_industri_kerajinan_tangan" class="col-sm-3 control-label">Industri Kerajinan Tangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_industri_kerajinan_tangan" name="data[anggota][1][ekonomi][industri_kerajinan_tangan]" placeholder="Industri Kerajinan Tangan" value="<?php echo $ddk->anggota[1]["ekonomi"]["industri_kerajinan_tangan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_industri_pakaian" class="col-sm-3 control-label">Industri Pakaian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_industri_pakaian" name="data[anggota][1][ekonomi][industri_pakaian]" placeholder="Industri Pakaian" value="<?php echo $ddk->anggota[1]["ekonomi"]["industri_pakaian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_industri_usaha_makanan" class="col-sm-3 control-label">Industri Usaha Makanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_industri_usaha_makanan" name="data[anggota][1][ekonomi][industri_usaha_makanan]" placeholder="Industri Usaha Makanan" value="<?php echo $ddk->anggota[1]["ekonomi"]["industri_usaha_makanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_industri_alat_rumah_tangga" class="col-sm-3 control-label">Industri Alat Rumah Tangga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_industri_alat_rumah_tangga" name="data[anggota][1][ekonomi][industri_alat_rumah_tangga]" placeholder="Industri Alat Rumah Tangga" value="<?php echo $ddk->anggota[1]["ekonomi"]["industri_alat_rumah_tangga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_industri_usaha_bahan_bangunan" class="col-sm-3 control-label">Industri Usaha Bahan Bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_industri_usaha_bahan_bangunan" name="data[anggota][1][ekonomi][industri_usaha_bahan_bangunan]" placeholder="Industri Usaha Bahan Bangunan" value="<?php echo $ddk->anggota[1]["ekonomi"]["industri_usaha_bahan_bangunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_industri_alat_pertanian" class="col-sm-3 control-label">Industri Alat Pertanian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_industri_alat_pertanian" name="data[anggota][1][ekonomi][industri_alat_pertanian]" placeholder="Industri Alat Pertanian" value="<?php echo $ddk->anggota[1]["ekonomi"]["industri_alat_pertanian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_restoran" class="col-sm-3 control-label">Restoran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_restoran" name="data[anggota][1][ekonomi][restoran]" placeholder="Restoran" value="<?php echo $ddk->anggota[1]["ekonomi"]["restoran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_toko__swalayan" class="col-sm-3 control-label">Toko/ Swalayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_toko__swalayan" name="data[anggota][1][ekonomi][toko__swalayan]" placeholder="Toko/ Swalayan" value="<?php echo $ddk->anggota[1]["ekonomi"]["toko__swalayan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_warung_kelontongan_kios" class="col-sm-3 control-label">Warung Kelontongan/Kios</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_warung_kelontongan_kios" name="data[anggota][1][ekonomi][warung_kelontongan_kios]" placeholder="Warung Kelontongan/Kios" value="<?php echo $ddk->anggota[1]["ekonomi"]["warung_kelontongan_kios"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_angkutan_darat" class="col-sm-3 control-label">Angkutan Darat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_angkutan_darat" name="data[anggota][1][ekonomi][angkutan_darat]" placeholder="Angkutan Darat" value="<?php echo $ddk->anggota[1]["ekonomi"]["angkutan_darat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_angkutan_sungai" class="col-sm-3 control-label">Angkutan Sungai</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_angkutan_sungai" name="data[anggota][1][ekonomi][angkutan_sungai]" placeholder="Angkutan Sungai" value="<?php echo $ddk->anggota[1]["ekonomi"]["angkutan_sungai"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_angkutan_laut" class="col-sm-3 control-label">Angkutan Laut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_angkutan_laut" name="data[anggota][1][ekonomi][angkutan_laut]" placeholder="Angkutan Laut" value="<?php echo $ddk->anggota[1]["ekonomi"]["angkutan_laut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_angkutan_udara" class="col-sm-3 control-label">Angkutan Udara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_angkutan_udara" name="data[anggota][1][ekonomi][angkutan_udara]" placeholder="Angkutan Udara" value="<?php echo $ddk->anggota[1]["ekonomi"]["angkutan_udara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_jasa_ekspedisi_pengiriman_barang" class="col-sm-3 control-label">Jasa Ekspedisi/Pengiriman Barang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_jasa_ekspedisi_pengiriman_barang" name="data[anggota][1][ekonomi][jasa_ekspedisi_pengiriman_barang]" placeholder="Jasa Ekspedisi/Pengiriman Barang" value="<?php echo $ddk->anggota[1]["ekonomi"]["jasa_ekspedisi_pengiriman_barang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_pasar_harian" class="col-sm-3 control-label">Usaha Pasar Harian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_pasar_harian" name="data[anggota][1][ekonomi][usaha_pasar_harian]" placeholder="Usaha Pasar Harian" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_pasar_harian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_pasar_mingguan" class="col-sm-3 control-label">Usaha Pasar Mingguan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_pasar_mingguan" name="data[anggota][1][ekonomi][usaha_pasar_mingguan]" placeholder="Usaha Pasar Mingguan" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_pasar_mingguan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_pasar_ternak" class="col-sm-3 control-label">Usaha Pasar Ternak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_pasar_ternak" name="data[anggota][1][ekonomi][usaha_pasar_ternak]" placeholder="Usaha Pasar Ternak" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_pasar_ternak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_pasar_hasil_bumi_dan_tambang" class="col-sm-3 control-label">Usaha Pasar Hasil Bumi Dan Tambang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_pasar_hasil_bumi_dan_tambang" name="data[anggota][1][ekonomi][usaha_pasar_hasil_bumi_dan_tambang]" placeholder="Usaha Pasar Hasil Bumi Dan Tambang" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_pasar_hasil_bumi_dan_tambang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_perdagangan_antar_pulau" class="col-sm-3 control-label">Usaha Perdagangan Antar Pulau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_perdagangan_antar_pulau" name="data[anggota][1][ekonomi][usaha_perdagangan_antar_pulau]" placeholder="Usaha Perdagangan Antar Pulau" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_perdagangan_antar_pulau"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_pengijon" class="col-sm-3 control-label">Pengijon</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_pengijon" name="data[anggota][1][ekonomi][pengijon]" placeholder="Pengijon" value="<?php echo $ddk->anggota[1]["ekonomi"]["pengijon"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_pedagang_pengumpul_tengkulak" class="col-sm-3 control-label">Pedagang Pengumpul/Tengkulak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_pedagang_pengumpul_tengkulak" name="data[anggota][1][ekonomi][pedagang_pengumpul_tengkulak]" placeholder="Pedagang Pengumpul/Tengkulak" value="<?php echo $ddk->anggota[1]["ekonomi"]["pedagang_pengumpul_tengkulak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_peternakan" class="col-sm-3 control-label">Usaha Peternakan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_peternakan" name="data[anggota][1][ekonomi][usaha_peternakan]" placeholder="Usaha Peternakan" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_peternakan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_perikanan" class="col-sm-3 control-label">Usaha Perikanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_perikanan" name="data[anggota][1][ekonomi][usaha_perikanan]" placeholder="Usaha Perikanan" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_perikanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_perkebunan" class="col-sm-3 control-label">Usaha Perkebunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_perkebunan" name="data[anggota][1][ekonomi][usaha_perkebunan]" placeholder="Usaha Perkebunan" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_perkebunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_kelompok_simpan_pinjam" class="col-sm-3 control-label">Kelompok Simpan Pinjam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_kelompok_simpan_pinjam" name="data[anggota][1][ekonomi][kelompok_simpan_pinjam]" placeholder="Kelompok Simpan Pinjam" value="<?php echo $ddk->anggota[1]["ekonomi"]["kelompok_simpan_pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_minuman" class="col-sm-3 control-label">Usaha Minuman</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_minuman" name="data[anggota][1][ekonomi][usaha_minuman]" placeholder="Usaha Minuman" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_minuman"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_industri_farmasi" class="col-sm-3 control-label">Industri Farmasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_industri_farmasi" name="data[anggota][1][ekonomi][industri_farmasi]" placeholder="Industri Farmasi" value="<?php echo $ddk->anggota[1]["ekonomi"]["industri_farmasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_industri_karoseri" class="col-sm-3 control-label">Industri Karoseri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_industri_karoseri" name="data[anggota][1][ekonomi][industri_karoseri]" placeholder="Industri Karoseri" value="<?php echo $ddk->anggota[1]["ekonomi"]["industri_karoseri"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_penitipan_kendaraan_bermotor" class="col-sm-3 control-label">Penitipan Kendaraan Bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_penitipan_kendaraan_bermotor" name="data[anggota][1][ekonomi][penitipan_kendaraan_bermotor]" placeholder="Penitipan Kendaraan Bermotor" value="<?php echo $ddk->anggota[1]["ekonomi"]["penitipan_kendaraan_bermotor"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_industri_perakitan_elektronik" class="col-sm-3 control-label">Industri Perakitan Elektronik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_industri_perakitan_elektronik" name="data[anggota][1][ekonomi][industri_perakitan_elektronik]" placeholder="Industri Perakitan Elektronik" value="<?php echo $ddk->anggota[1]["ekonomi"]["industri_perakitan_elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_pengolahan_kayu" class="col-sm-3 control-label">Pengolahan Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_pengolahan_kayu" name="data[anggota][1][ekonomi][pengolahan_kayu]" placeholder="Pengolahan Kayu" value="<?php echo $ddk->anggota[1]["ekonomi"]["pengolahan_kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_bioskop" class="col-sm-3 control-label">Bioskop</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_bioskop" name="data[anggota][1][ekonomi][bioskop]" placeholder="Bioskop" value="<?php echo $ddk->anggota[1]["ekonomi"]["bioskop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_film_keliling" class="col-sm-3 control-label">Film Keliling</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_film_keliling" name="data[anggota][1][ekonomi][film_keliling]" placeholder="Film Keliling" value="<?php echo $ddk->anggota[1]["ekonomi"]["film_keliling"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_sandiwara_drama" class="col-sm-3 control-label">Sandiwara/Drama</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_sandiwara_drama" name="data[anggota][1][ekonomi][sandiwara_drama]" placeholder="Sandiwara/Drama" value="<?php echo $ddk->anggota[1]["ekonomi"]["sandiwara_drama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_group_lawak" class="col-sm-3 control-label">Group Lawak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_group_lawak" name="data[anggota][1][ekonomi][group_lawak]" placeholder="Group Lawak" value="<?php echo $ddk->anggota[1]["ekonomi"]["group_lawak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_jaipongan" class="col-sm-3 control-label">Jaipongan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_jaipongan" name="data[anggota][1][ekonomi][jaipongan]" placeholder="Jaipongan" value="<?php echo $ddk->anggota[1]["ekonomi"]["jaipongan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_wayang_orang_golek" class="col-sm-3 control-label">Wayang Orang/Golek</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_wayang_orang_golek" name="data[anggota][1][ekonomi][wayang_orang_golek]" placeholder="Wayang Orang/Golek" value="<?php echo $ddk->anggota[1]["ekonomi"]["wayang_orang_golek"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_group_musik_band" class="col-sm-3 control-label">Group Musik/Band</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_group_musik_band" name="data[anggota][1][ekonomi][group_musik_band]" placeholder="Group Musik/Band" value="<?php echo $ddk->anggota[1]["ekonomi"]["group_musik_band"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_group_vokal_paduan_suara" class="col-sm-3 control-label">Group Vokal/Paduan Suara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_group_vokal_paduan_suara" name="data[anggota][1][ekonomi][group_vokal_paduan_suara]" placeholder="Group Vokal/Paduan Suara" value="<?php echo $ddk->anggota[1]["ekonomi"]["group_vokal_paduan_suara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_persewaan_tenaga_listrik" class="col-sm-3 control-label">Usaha Persewaan Tenaga Listrik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_persewaan_tenaga_listrik" name="data[anggota][1][ekonomi][usaha_persewaan_tenaga_listrik]" placeholder="Usaha Persewaan Tenaga Listrik" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_persewaan_tenaga_listrik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_pengecer_gas_dan_bahan_bakar_minyak" class="col-sm-3 control-label">Usaha Pengecer Gas Dan Bahan Bakar Minyak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_pengecer_gas_dan_bahan_bakar_minyak" name="data[anggota][1][ekonomi][usaha_pengecer_gas_dan_bahan_bakar_minyak]" placeholder="Usaha Pengecer Gas Dan Bahan Bakar Minyak" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_pengecer_gas_dan_bahan_bakar_minyak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_air_minum_dalam_kemasan" class="col-sm-3 control-label">Usaha Air Minum Dalam Kemasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_air_minum_dalam_kemasan" name="data[anggota][1][ekonomi][usaha_air_minum_dalam_kemasan]" placeholder="Usaha Air Minum Dalam Kemasan" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_air_minum_dalam_kemasan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_tukang_kayu" class="col-sm-3 control-label">Tukang Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_tukang_kayu" name="data[anggota][1][ekonomi][tukang_kayu]" placeholder="Tukang Kayu" value="<?php echo $ddk->anggota[1]["ekonomi"]["tukang_kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_tukang_batu" class="col-sm-3 control-label">Tukang Batu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_tukang_batu" name="data[anggota][1][ekonomi][tukang_batu]" placeholder="Tukang Batu" value="<?php echo $ddk->anggota[1]["ekonomi"]["tukang_batu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_tukang_jahit_bordir" class="col-sm-3 control-label">Tukang Jahit/Bordir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_tukang_jahit_bordir" name="data[anggota][1][ekonomi][tukang_jahit_bordir]" placeholder="Tukang Jahit/Bordir" value="<?php echo $ddk->anggota[1]["ekonomi"]["tukang_jahit_bordir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_tukang_cukur" class="col-sm-3 control-label">Tukang Cukur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_tukang_cukur" name="data[anggota][1][ekonomi][tukang_cukur]" placeholder="Tukang Cukur" value="<?php echo $ddk->anggota[1]["ekonomi"]["tukang_cukur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_tukang_service_elektronik" class="col-sm-3 control-label">Tukang Service Elektronik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_tukang_service_elektronik" name="data[anggota][1][ekonomi][tukang_service_elektronik]" placeholder="Tukang Service Elektronik" value="<?php echo $ddk->anggota[1]["ekonomi"]["tukang_service_elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_tukang_besi" class="col-sm-3 control-label">Tukang Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_tukang_besi" name="data[anggota][1][ekonomi][tukang_besi]" placeholder="Tukang Besi" value="<?php echo $ddk->anggota[1]["ekonomi"]["tukang_besi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_tukang_pijat_urut" class="col-sm-3 control-label">Tukang Pijat/Urut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_tukang_pijat_urut" name="data[anggota][1][ekonomi][tukang_pijat_urut]" placeholder="Tukang Pijat/Urut" value="<?php echo $ddk->anggota[1]["ekonomi"]["tukang_pijat_urut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_tukang_sumur" class="col-sm-3 control-label">Tukang Sumur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_tukang_sumur" name="data[anggota][1][ekonomi][tukang_sumur]" placeholder="Tukang Sumur" value="<?php echo $ddk->anggota[1]["ekonomi"]["tukang_sumur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_notaris" class="col-sm-3 control-label">Notaris</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_notaris" name="data[anggota][1][ekonomi][notaris]" placeholder="Notaris" value="<?php echo $ddk->anggota[1]["ekonomi"]["notaris"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_pengacara_advokat" class="col-sm-3 control-label">Pengacara/Advokat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_pengacara_advokat" name="data[anggota][1][ekonomi][pengacara_advokat]" placeholder="Pengacara/Advokat" value="<?php echo $ddk->anggota[1]["ekonomi"]["pengacara_advokat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_konsultan_manajemen" class="col-sm-3 control-label">Konsultan Manajemen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_konsultan_manajemen" name="data[anggota][1][ekonomi][konsultan_manajemen]" placeholder="Konsultan Manajemen" value="<?php echo $ddk->anggota[1]["ekonomi"]["konsultan_manajemen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_konsultan_teknis" class="col-sm-3 control-label">Konsultan Teknis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_konsultan_teknis" name="data[anggota][1][ekonomi][konsultan_teknis]" placeholder="Konsultan Teknis" value="<?php echo $ddk->anggota[1]["ekonomi"]["konsultan_teknis"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_pejabat_pembuat_akta_tanah" class="col-sm-3 control-label">Pejabat Pembuat Akta Tanah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_pejabat_pembuat_akta_tanah" name="data[anggota][1][ekonomi][pejabat_pembuat_akta_tanah]" placeholder="Pejabat Pembuat Akta Tanah" value="<?php echo $ddk->anggota[1]["ekonomi"]["pejabat_pembuat_akta_tanah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_losmen" class="col-sm-3 control-label">Losmen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_losmen" name="data[anggota][1][ekonomi][losmen]" placeholder="Losmen" value="<?php echo $ddk->anggota[1]["ekonomi"]["losmen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_wisma" class="col-sm-3 control-label">Wisma</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_wisma" name="data[anggota][1][ekonomi][wisma]" placeholder="Wisma" value="<?php echo $ddk->anggota[1]["ekonomi"]["wisma"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_asrama" class="col-sm-3 control-label">Asrama</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_asrama" name="data[anggota][1][ekonomi][asrama]" placeholder="Asrama" value="<?php echo $ddk->anggota[1]["ekonomi"]["asrama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_persewaan_kamar" class="col-sm-3 control-label">Persewaan Kamar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_persewaan_kamar" name="data[anggota][1][ekonomi][persewaan_kamar]" placeholder="Persewaan Kamar" value="<?php echo $ddk->anggota[1]["ekonomi"]["persewaan_kamar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_kontrakan_rumah" class="col-sm-3 control-label">Kontrakan Rumah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_kontrakan_rumah" name="data[anggota][1][ekonomi][kontrakan_rumah]" placeholder="Kontrakan Rumah" value="<?php echo $ddk->anggota[1]["ekonomi"]["kontrakan_rumah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_mess" class="col-sm-3 control-label">Mess</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_mess" name="data[anggota][1][ekonomi][mess]" placeholder="Mess" value="<?php echo $ddk->anggota[1]["ekonomi"]["mess"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_hotel" class="col-sm-3 control-label">Hotel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_hotel" name="data[anggota][1][ekonomi][hotel]" placeholder="Hotel" value="<?php echo $ddk->anggota[1]["ekonomi"]["hotel"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_home_stay" class="col-sm-3 control-label">Home Stay</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_home_stay" name="data[anggota][1][ekonomi][home_stay]" placeholder="Home Stay" value="<?php echo $ddk->anggota[1]["ekonomi"]["home_stay"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_villa" class="col-sm-3 control-label">Villa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_villa" name="data[anggota][1][ekonomi][villa]" placeholder="Villa" value="<?php echo $ddk->anggota[1]["ekonomi"]["villa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_town_house" class="col-sm-3 control-label">Town House</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_town_house" name="data[anggota][1][ekonomi][town_house]" placeholder="Town House" value="<?php echo $ddk->anggota[1]["ekonomi"]["town_house"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_asuransi" class="col-sm-3 control-label">Usaha Asuransi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_asuransi" name="data[anggota][1][ekonomi][usaha_asuransi]" placeholder="Usaha Asuransi" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_asuransi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_lembaga_keuangan_bukan_bank" class="col-sm-3 control-label">Lembaga Keuangan Bukan Bank</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_lembaga_keuangan_bukan_bank" name="data[anggota][1][ekonomi][lembaga_keuangan_bukan_bank]" placeholder="Lembaga Keuangan Bukan Bank" value="<?php echo $ddk->anggota[1]["ekonomi"]["lembaga_keuangan_bukan_bank"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_lembaga_perkreditan_rakyat" class="col-sm-3 control-label">Lembaga Perkreditan Rakyat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_lembaga_perkreditan_rakyat" name="data[anggota][1][ekonomi][lembaga_perkreditan_rakyat]" placeholder="Lembaga Perkreditan Rakyat" value="<?php echo $ddk->anggota[1]["ekonomi"]["lembaga_perkreditan_rakyat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_pegadaian" class="col-sm-3 control-label">Pegadaian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_pegadaian" name="data[anggota][1][ekonomi][pegadaian]" placeholder="Pegadaian" value="<?php echo $ddk->anggota[1]["ekonomi"]["pegadaian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_bank_perkreditan_rakyat" class="col-sm-3 control-label">Bank Perkreditan Rakyat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_bank_perkreditan_rakyat" name="data[anggota][1][ekonomi][bank_perkreditan_rakyat]" placeholder="Bank Perkreditan Rakyat" value="<?php echo $ddk->anggota[1]["ekonomi"]["bank_perkreditan_rakyat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_penyewaan_alat_pesta" class="col-sm-3 control-label">Usaha Penyewaan Alat Pesta</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_penyewaan_alat_pesta" name="data[anggota][1][ekonomi][usaha_penyewaan_alat_pesta]" placeholder="Usaha Penyewaan Alat Pesta" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_penyewaan_alat_pesta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_usaha_pengolahan_dan_penjualan_hasil_hutan" class="col-sm-3 control-label">Usaha Pengolahan dan Penjualan Hasil Hutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_usaha_pengolahan_dan_penjualan_hasil_hutan" name="data[anggota][1][ekonomi][usaha_pengolahan_dan_penjualan_hasil_hutan]" placeholder="Usaha Pengolahan dan Penjualan Hasil Hutan" value="<?php echo $ddk->anggota[1]["ekonomi"]["usaha_pengolahan_dan_penjualan_hasil_hutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_ekonomi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_ekonomi_lainnya" name="data[anggota][1][ekonomi][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[1]["ekonomi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_ekonomi_lainnya" name="data[anggota][1][ekonomi][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[1]["ekonomi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Produksi bahan galian yang dimiliki anggota keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_batu_kali" class="col-sm-3 control-label">Batu kali</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_batu_kali" name="data[anggota][1][galian][batu_kali][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["batu_kali"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_kali" name="data[anggota][1][galian][batu_kali][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["batu_kali"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_kali" name="data[anggota][1][galian][batu_kali][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["batu_kali"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_kali" name="data[anggota][1][galian][batu_kali][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["batu_kali"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_batu_kapur" class="col-sm-3 control-label">Batu kapur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_batu_kapur" name="data[anggota][1][galian][batu_kapur][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["batu_kapur"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_kapur" name="data[anggota][1][galian][batu_kapur][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["batu_kapur"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_kapur" name="data[anggota][1][galian][batu_kapur][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["batu_kapur"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_kapur" name="data[anggota][1][galian][batu_kapur][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["batu_kapur"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_pasir" class="col-sm-3 control-label">Pasir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_pasir" name="data[anggota][1][galian][pasir][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["pasir"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir" name="data[anggota][1][galian][pasir][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["pasir"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir" name="data[anggota][1][galian][pasir][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["pasir"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir" name="data[anggota][1][galian][pasir][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["pasir"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_emas" class="col-sm-3 control-label">Emas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_emas" name="data[anggota][1][galian][emas][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["emas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_emas" name="data[anggota][1][galian][emas][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["emas"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_emas" name="data[anggota][1][galian][emas][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["emas"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_emas" name="data[anggota][1][galian][emas][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["emas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_kuningan" class="col-sm-3 control-label">Kuningan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_kuningan" name="data[anggota][1][galian][kuningan][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["kuningan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_kuningan" name="data[anggota][1][galian][kuningan][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["kuningan"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_kuningan" name="data[anggota][1][galian][kuningan][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["kuningan"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_kuningan" name="data[anggota][1][galian][kuningan][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["kuningan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_aluminium" class="col-sm-3 control-label">Aluminium</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_aluminium" name="data[anggota][1][galian][aluminium][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["aluminium"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_aluminium" name="data[anggota][1][galian][aluminium][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["aluminium"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_aluminium" name="data[anggota][1][galian][aluminium][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["aluminium"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_aluminium" name="data[anggota][1][galian][aluminium][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["aluminium"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_perunggu" class="col-sm-3 control-label">Perunggu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_perunggu" name="data[anggota][1][galian][perunggu][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["perunggu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_perunggu" name="data[anggota][1][galian][perunggu][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["perunggu"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_perunggu" name="data[anggota][1][galian][perunggu][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["perunggu"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_perunggu" name="data[anggota][1][galian][perunggu][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["perunggu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_belerang" class="col-sm-3 control-label">Belerang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_belerang" name="data[anggota][1][galian][belerang][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["belerang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_belerang" name="data[anggota][1][galian][belerang][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["belerang"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_belerang" name="data[anggota][1][galian][belerang][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["belerang"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_belerang" name="data[anggota][1][galian][belerang][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["belerang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_batu_marmer" class="col-sm-3 control-label">Batu marmer</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_batu_marmer" name="data[anggota][1][galian][batu_marmer][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["batu_marmer"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_marmer" name="data[anggota][1][galian][batu_marmer][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["batu_marmer"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_marmer" name="data[anggota][1][galian][batu_marmer][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["batu_marmer"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_marmer" name="data[anggota][1][galian][batu_marmer][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["batu_marmer"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_batu_cadas" class="col-sm-3 control-label">Batu cadas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_batu_cadas" name="data[anggota][1][galian][batu_cadas][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["batu_cadas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_cadas" name="data[anggota][1][galian][batu_cadas][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["batu_cadas"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_cadas" name="data[anggota][1][galian][batu_cadas][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["batu_cadas"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_cadas" name="data[anggota][1][galian][batu_cadas][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["batu_cadas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_batu_apung" class="col-sm-3 control-label">Batu apung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_batu_apung" name="data[anggota][1][galian][batu_apung][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["batu_apung"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_apung" name="data[anggota][1][galian][batu_apung][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["batu_apung"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_apung" name="data[anggota][1][galian][batu_apung][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["batu_apung"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_apung" name="data[anggota][1][galian][batu_apung][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["batu_apung"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_pasir_kwarsa" class="col-sm-3 control-label">Pasir kwarsa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_pasir_kwarsa" name="data[anggota][1][galian][pasir_kwarsa][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["pasir_kwarsa"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir_kwarsa" name="data[anggota][1][galian][pasir_kwarsa][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["pasir_kwarsa"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir_kwarsa" name="data[anggota][1][galian][pasir_kwarsa][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["pasir_kwarsa"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir_kwarsa" name="data[anggota][1][galian][pasir_kwarsa][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["pasir_kwarsa"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_batubara" class="col-sm-3 control-label">Batubara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_batubara" name="data[anggota][1][galian][batubara][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["batubara"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batubara" name="data[anggota][1][galian][batubara][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["batubara"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batubara" name="data[anggota][1][galian][batubara][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["batubara"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batubara" name="data[anggota][1][galian][batubara][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["batubara"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_batu_granit" class="col-sm-3 control-label">Batu Granit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_batu_granit" name="data[anggota][1][galian][batu_granit][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["batu_granit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_granit" name="data[anggota][1][galian][batu_granit][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["batu_granit"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_granit" name="data[anggota][1][galian][batu_granit][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["batu_granit"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_granit" name="data[anggota][1][galian][batu_granit][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["batu_granit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_batu_gamping" class="col-sm-3 control-label">Batu Gamping</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_batu_gamping" name="data[anggota][1][galian][batu_gamping][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["batu_gamping"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_gamping" name="data[anggota][1][galian][batu_gamping][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["batu_gamping"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_gamping" name="data[anggota][1][galian][batu_gamping][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["batu_gamping"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_gamping" name="data[anggota][1][galian][batu_gamping][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["batu_gamping"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_mangan" class="col-sm-3 control-label">Mangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_mangan" name="data[anggota][1][galian][mangan][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["mangan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_mangan" name="data[anggota][1][galian][mangan][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["mangan"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_mangan" name="data[anggota][1][galian][mangan][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["mangan"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_mangan" name="data[anggota][1][galian][mangan][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["mangan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_batu_trass" class="col-sm-3 control-label">Batu Trass</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_batu_trass" name="data[anggota][1][galian][batu_trass][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["batu_trass"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_trass" name="data[anggota][1][galian][batu_trass][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["batu_trass"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_trass" name="data[anggota][1][galian][batu_trass][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["batu_trass"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_trass" name="data[anggota][1][galian][batu_trass][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["batu_trass"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_batu_putih" class="col-sm-3 control-label">Batu Putih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_batu_putih" name="data[anggota][1][galian][batu_putih][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["batu_putih"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_putih" name="data[anggota][1][galian][batu_putih][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["batu_putih"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_putih" name="data[anggota][1][galian][batu_putih][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["batu_putih"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_batu_putih" name="data[anggota][1][galian][batu_putih][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["batu_putih"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_pasir_batu" class="col-sm-3 control-label">Pasir Batu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_pasir_batu" name="data[anggota][1][galian][pasir_batu][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["pasir_batu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir_batu" name="data[anggota][1][galian][pasir_batu][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["pasir_batu"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir_batu" name="data[anggota][1][galian][pasir_batu][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["pasir_batu"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir_batu" name="data[anggota][1][galian][pasir_batu][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["pasir_batu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_pasir_besi" class="col-sm-3 control-label">Pasir Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_pasir_besi" name="data[anggota][1][galian][pasir_besi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["pasir_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir_besi" name="data[anggota][1][galian][pasir_besi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["pasir_besi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir_besi" name="data[anggota][1][galian][pasir_besi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["pasir_besi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_pasir_besi" name="data[anggota][1][galian][pasir_besi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["pasir_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_gips" class="col-sm-3 control-label">Gips</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_gips" name="data[anggota][1][galian][gips][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["gips"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_gips" name="data[anggota][1][galian][gips][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["gips"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_gips" name="data[anggota][1][galian][gips][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["gips"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_gips" name="data[anggota][1][galian][gips][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["gips"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_minyak_bumi" class="col-sm-3 control-label">Minyak Bumi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_minyak_bumi" name="data[anggota][1][galian][minyak_bumi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["minyak_bumi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_minyak_bumi" name="data[anggota][1][galian][minyak_bumi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["minyak_bumi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_minyak_bumi" name="data[anggota][1][galian][minyak_bumi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["minyak_bumi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_minyak_bumi" name="data[anggota][1][galian][minyak_bumi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["minyak_bumi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_gas_alam" class="col-sm-3 control-label">Gas Alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_gas_alam" name="data[anggota][1][galian][gas_alam][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["gas_alam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_gas_alam" name="data[anggota][1][galian][gas_alam][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["gas_alam"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_gas_alam" name="data[anggota][1][galian][gas_alam][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["gas_alam"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_gas_alam" name="data[anggota][1][galian][gas_alam][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["gas_alam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_perak" class="col-sm-3 control-label">Perak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_perak" name="data[anggota][1][galian][perak][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["perak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_perak" name="data[anggota][1][galian][perak][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["perak"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_perak" name="data[anggota][1][galian][perak][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["perak"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_perak" name="data[anggota][1][galian][perak][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["perak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_timah" class="col-sm-3 control-label">Timah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_timah" name="data[anggota][1][galian][timah][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["timah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_timah" name="data[anggota][1][galian][timah][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["timah"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_timah" name="data[anggota][1][galian][timah][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["timah"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_timah" name="data[anggota][1][galian][timah][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["timah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_tembaga" class="col-sm-3 control-label">Tembaga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_tembaga" name="data[anggota][1][galian][tembaga][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["tembaga"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_tembaga" name="data[anggota][1][galian][tembaga][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["tembaga"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_tembaga" name="data[anggota][1][galian][tembaga][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["tembaga"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_tembaga" name="data[anggota][1][galian][tembaga][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["tembaga"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_biji_besi" class="col-sm-3 control-label">Biji Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_biji_besi" name="data[anggota][1][galian][biji_besi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["biji_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_biji_besi" name="data[anggota][1][galian][biji_besi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["biji_besi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_biji_besi" name="data[anggota][1][galian][biji_besi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["biji_besi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_biji_besi" name="data[anggota][1][galian][biji_besi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["biji_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_uranium" class="col-sm-3 control-label">Uranium</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_uranium" name="data[anggota][1][galian][uranium][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["uranium"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_uranium" name="data[anggota][1][galian][uranium][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["uranium"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_uranium" name="data[anggota][1][galian][uranium][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["uranium"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_uranium" name="data[anggota][1][galian][uranium][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["uranium"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_bouxit" class="col-sm-3 control-label">Bouxit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_bouxit" name="data[anggota][1][galian][bouxit][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["bouxit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_bouxit" name="data[anggota][1][galian][bouxit][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["bouxit"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_bouxit" name="data[anggota][1][galian][bouxit][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["bouxit"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_bouxit" name="data[anggota][1][galian][bouxit][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["bouxit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_garam" class="col-sm-3 control-label">Garam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_garam" name="data[anggota][1][galian][garam][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["garam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_garam" name="data[anggota][1][galian][garam][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["garam"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_garam" name="data[anggota][1][galian][garam][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["garam"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_garam" name="data[anggota][1][galian][garam][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["garam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_nikel" class="col-sm-3 control-label">Nikel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_nikel" name="data[anggota][1][galian][nikel][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["nikel"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_nikel" name="data[anggota][1][galian][nikel][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["nikel"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_nikel" name="data[anggota][1][galian][nikel][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["nikel"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_nikel" name="data[anggota][1][galian][nikel][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["nikel"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota2_galian_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota2_galian_lainnya" name="data[anggota][1][galian][lainnya][keterangan]" placeholder="Keterangan" value="<?php echo $ddk->anggota[1]["galian"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_lainnya" name="data[anggota][1][galian][lainnya][opsi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[1]["galian"]["lainnya"]["opsi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_lainnya" name="data[anggota][1][galian][lainnya][opsi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[1]["galian"]["lainnya"]["opsi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_lainnya" name="data[anggota][1][galian][lainnya][opsi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[1]["galian"]["lainnya"]["opsi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota2_galian_lainnya" name="data[anggota][1][galian][lainnya][opsi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[1]["galian"]["lainnya"]["opsi"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Data Anggota Keluarga 3</strong></h4>
				<h4>Biodata</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_no_urut" class="col-sm-3 control-label">Nomor Urut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_no_urut" name="data[anggota][2][no_urut]" placeholder="Nomor Urut" value="<?php echo $ddk->anggota[2]["no_urut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_nik" class="col-sm-3 control-label">Nomor Induk Kependudukan (NIK)</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_nik" name="data[anggota][2][nik]" placeholder="Nomor Induk Kependudukan (NIK)" value="<?php echo $ddk->anggota[2]["nik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_nama" class="col-sm-3 control-label">Nama Lengkap</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_nama" name="data[anggota][2][nama]" placeholder="Nama Lengkap" value="<?php echo $ddk->anggota[2]["nama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_no_akte" class="col-sm-3 control-label">Nomor Akte Kelahiran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_no_akte" name="data[anggota][2][no_akte]" placeholder="Nomor Akte Kelahiran" value="<?php echo $ddk->anggota[2]["no_akte"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_jenis_kelamin" class="col-sm-3 control-label">Jenis Kelamin</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][2][jenis_kelamin]" id="anggota3_jenis_kelamin">
					<option value="laki" <?php echo $ddk->anggota[2]["jenis_kelamin"] == "laki" ? "selected" : ""; ?>>Laki-laki</option>
					<option value="perempuan" <?php echo $ddk->anggota[2]["jenis_kelamin"] == "perempuan" ? "selected" : ""; ?>>Perempuan</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_hubungan" class="col-sm-3 control-label">Hubungan dengan Kepala Keluarga</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][2][hubungan]" id="anggota3_hubungan">
					<option value="istri" <?php echo $ddk->anggota[2]["hubungan"] == "istri" ? "selected" : ""; ?>>Istri</option>
					<option value="suami" <?php echo $ddk->anggota[2]["hubungan"] == "suami" ? "selected" : ""; ?>>Suami</option>
					<option value="anak" <?php echo $ddk->anggota[2]["hubungan"] == "anak" ? "selected" : ""; ?>>Anak</option>
					<option value="cucu" <?php echo $ddk->anggota[2]["hubungan"] == "cucu" ? "selected" : ""; ?>>Cucu</option>
					<option value="mertua" <?php echo $ddk->anggota[2]["hubungan"] == "mertua" ? "selected" : ""; ?>>Mertua</option>
					<option value="menantu" <?php echo $ddk->anggota[2]["hubungan"] == "menantu" ? "selected" : ""; ?>>Menantu</option>
					<option value="keponakan" <?php echo $ddk->anggota[2]["hubungan"] == "keponakan" ? "selected" : ""; ?>>Keponakan</option>
					<option value="lainnya" <?php echo $ddk->anggota[2]["hubungan"] == "lainnya" ? "selected" : ""; ?>>Lainnya</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_tempat_lahir" class="col-sm-3 control-label">Tempat Lahir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_tempat_lahir" name="data[anggota][2][tempat_lahir]" placeholder="Tempat Lahir" value="<?php echo $ddk->anggota[2]["tempat_lahir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_tanggal_lahir" class="col-sm-3 control-label">Tanggal Lahir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="anggota3_tanggal_lahir" name="data[anggota][2][tanggal_lahir]" placeholder="Tanggal Lahir">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_tanggal_pencatatan" class="col-sm-3 control-label">Tanggal Pencatatan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="anggota3_tanggal_pencatatan" name="data[anggota][2][tanggal_pencatatan]" placeholder="Tanggal Pencatatan">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_status_kawin" class="col-sm-3 control-label">Status Perkawinan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][2][status_kawin]" id="anggota3_status_kawin">
					<option value="kawin" <?php echo $ddk->anggota[2]["status_kawin"] == "kawin" ? "selected" : ""; ?>>Kawin</option>
					<option value="belum" <?php echo $ddk->anggota[2]["status_kawin"] == "belum" ? "selected" : ""; ?>>Belum Kawin</option>
					<option value="pernah" <?php echo $ddk->anggota[2]["status_kawin"] == "pernah" ? "selected" : ""; ?>>Pernah Kawin</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_agama" class="col-sm-3 control-label">Agama dan Aliran Kepercayaan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][2][agama]" id="anggota3_agama">
					<option value="islam" <?php echo $ddk->anggota[2]["agama"] == "islam" ? "selected" : ""; ?>>Islam</option>
					<option value="protestan" <?php echo $ddk->anggota[2]["agama"] == "protestan" ? "selected" : ""; ?>>Protestan</option>
					<option value="katolik" <?php echo $ddk->anggota[2]["agama"] == "katolik" ? "selected" : ""; ?>>Katolik</option>
					<option value="hindu" <?php echo $ddk->anggota[2]["agama"] == "hindu" ? "selected" : ""; ?>>Hindu</option>
					<option value="budha" <?php echo $ddk->anggota[2]["agama"] == "budha" ? "selected" : ""; ?>>Budha</option>
					<option value="kong hu chu" <?php echo $ddk->anggota[2]["agama"] == "kong hu chu" ? "selected" : ""; ?>>Kong Hu Chu</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_darah" class="col-sm-3 control-label">Golongan Darah</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][2][darah]" id="anggota3_darah">
					<option value="O" <?php echo $ddk->anggota[2]["darah"] == "O" ? "selected" : ""; ?>>O</option>
					<option value="A" <?php echo $ddk->anggota[2]["darah"] == "A" ? "selected" : ""; ?>>A</option>
					<option value="B" <?php echo $ddk->anggota[2]["darah"] == "B" ? "selected" : ""; ?>>B</option>
					<option value="AB" <?php echo $ddk->anggota[2]["darah"] == "AB" ? "selected" : ""; ?>>AB</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kewarganegaraan" class="col-sm-3 control-label">Kewarganegaraan/Etnis/Suku</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kewarganegaraan" name="data[anggota][2][kewarganegaraan]" placeholder="Kewarganegaraan/Etnis/Suku" value="<?php echo $ddk->anggota[2]["kewarganegaraan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pendidikan" class="col-sm-3 control-label">Pendidikan Umum Terakhir</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][2][pendidikan]" id="anggota3_pendidikan">
					<option value="SD" <?php echo $ddk->anggota[2]["pendidikan"] == "SD" ? "selected" : ""; ?>>SD</option>
					<option value="SMP" <?php echo $ddk->anggota[2]["pendidikan"] == "SMP" ? "selected" : ""; ?>>SMP</option>
					<option value="SMA" <?php echo $ddk->anggota[2]["pendidikan"] == "SMA" ? "selected" : ""; ?>>SMA</option>
					<option value="Diploma" <?php echo $ddk->anggota[2]["pendidikan"] == "Diploma" ? "selected" : ""; ?>>Diploma</option>
					<option value="S1" <?php echo $ddk->anggota[2]["pendidikan"] == "S1" ? "selected" : ""; ?>>S1</option>
					<option value="S2" <?php echo $ddk->anggota[2]["pendidikan"] == "S2" ? "selected" : ""; ?>>S2</option>
					<option value="S3" <?php echo $ddk->anggota[2]["pendidikan"] == "S3" ? "selected" : ""; ?>>S3</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pekerjaan" class="col-sm-3 control-label">Mata Pencaharian Pokok/Pekerjaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pekerjaan" name="data[anggota][2][pekerjaan]" placeholder="Mata Pencaharian Pokok/Pekerjaan" value="<?php echo $ddk->anggota[2]["pekerjaan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_nama_ortu" class="col-sm-3 control-label">Nama Bapak / Ibu Kandung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_nama_ortu" name="data[anggota][2][nama_ortu]" placeholder="Nama Bapak / Ibu Kandung" value="<?php echo $ddk->anggota[2]["nama_ortu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kb" class="col-sm-3 control-label">Akseptor KB</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][2][kb]" id="anggota3_kb">
					<option value="Pil" <?php echo $ddk->anggota[2]["kb"] == "Pil" ? "selected" : ""; ?>>Pil</option>
					<option value="Spiral" <?php echo $ddk->anggota[2]["kb"] == "Spiral" ? "selected" : ""; ?>>Spiral</option>
					<option value="Suntik" <?php echo $ddk->anggota[2]["kb"] == "Suntik" ? "selected" : ""; ?>>Suntik</option>
					<option value="Susuk" <?php echo $ddk->anggota[2]["kb"] == "Susuk" ? "selected" : ""; ?>>Susuk</option>
					<option value="Kondom" <?php echo $ddk->anggota[2]["kb"] == "Kondom" ? "selected" : ""; ?>>Kondom</option>
					<option value="Vaksetomi" <?php echo $ddk->anggota[2]["kb"] == "Vaksetomi" ? "selected" : ""; ?>>Vaksetomi</option>
					<option value="Tubektomi" <?php echo $ddk->anggota[2]["kb"] == "Tubektomi" ? "selected" : ""; ?>>Tubektomi</option>
				</select>
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Cacat Menurut Jenis</strong></h4>
				<h4>Cacat Fisik</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_cacat_fisik_tuli" class="col-sm-3 control-label">Tuna rungu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_cacat_fisik_tuli" name="data[anggota][2][cacat_fisik][tuli]" placeholder="Tuna rungu" value="<?php echo $ddk->anggota[2]["cacat_fisik"]["tuli"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_cacat_fisik_bisu" class="col-sm-3 control-label">Tuna wicara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_cacat_fisik_bisu" name="data[anggota][2][cacat_fisik][bisu]" placeholder="Tuna wicara" value="<?php echo $ddk->anggota[2]["cacat_fisik"]["bisu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_cacat_fisik_buta" class="col-sm-3 control-label">Tuna netra</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_cacat_fisik_buta" name="data[anggota][2][cacat_fisik][buta]" placeholder="Tuna netra" value="<?php echo $ddk->anggota[2]["cacat_fisik"]["buta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_cacat_fisik_lumpuh" class="col-sm-3 control-label">Lumpuh</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_cacat_fisik_lumpuh" name="data[anggota][2][cacat_fisik][lumpuh]" placeholder="Lumpuh" value="<?php echo $ddk->anggota[2]["cacat_fisik"]["lumpuh"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_cacat_fisik_sumbing" class="col-sm-3 control-label">Sumbing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_cacat_fisik_sumbing" name="data[anggota][2][cacat_fisik][sumbing]" placeholder="Sumbing" value="<?php echo $ddk->anggota[2]["cacat_fisik"]["sumbing"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_cacat_fisik_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_cacat_fisik_lainnya" name="data[anggota][2][cacat_fisik][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[2]["cacat_fisik"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_cacat_fisik_lainnya" name="data[anggota][2][cacat_fisik][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[2]["cacat_fisik"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4>Cacat Mental</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_cacat_mental_idiot" class="col-sm-3 control-label">Idiot</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_cacat_mental_idiot" name="data[anggota][2][cacat_mental][idiot]" placeholder="Idiot" value="<?php echo $ddk->anggota[2]["cacat_mental"]["idiot"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_cacat_mental_gila" class="col-sm-3 control-label">Gila</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_cacat_mental_gila" name="data[anggota][2][cacat_mental][gila]" placeholder="Gila" value="<?php echo $ddk->anggota[2]["cacat_mental"]["gila"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_cacat_mental_stress" class="col-sm-3 control-label">Stress</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_cacat_mental_stress" name="data[anggota][2][cacat_mental][stress]" placeholder="Stress" value="<?php echo $ddk->anggota[2]["cacat_mental"]["stress"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_cacat_mental_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_cacat_mental_lainnya" name="data[anggota][2][cacat_mental][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[2]["cacat_mental"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_cacat_mental_lainnya" name="data[anggota][2][cacat_mental][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[2]["cacat_mental"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Kedudukan Anggota Keluarga sebagai Wajib Pajak dan Retribusi</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pajak_retribusi_pbb" class="col-sm-3 control-label">Wajib Pajak Bumi dan Bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pajak_retribusi_pbb" name="data[anggota][2][pajak_retribusi][pbb]" placeholder="Wajib Pajak Bumi dan Bangunan" value="<?php echo $ddk->anggota[2]["pajak_retribusi"]["pbb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pajak_retribusi_ppp" class="col-sm-3 control-label">Wajib Pajak Penghasilan Perorangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pajak_retribusi_ppp" name="data[anggota][2][pajak_retribusi][ppp]" placeholder="Wajib Pajak Penghasilan Perorangan" value="<?php echo $ddk->anggota[2]["pajak_retribusi"]["ppp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pajak_retribusi_pb" class="col-sm-3 control-label">Wajib Pajak Badan/Perusahaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pajak_retribusi_pb" name="data[anggota][2][pajak_retribusi][pb]" placeholder="Wajib Pajak Badan/Perusahaan" value="<?php echo $ddk->anggota[2]["pajak_retribusi"]["pb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pajak_retribusi_pkb" class="col-sm-3 control-label">Wajib Pajak Kendaraan Bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pajak_retribusi_pkb" name="data[anggota][2][pajak_retribusi][pkb]" placeholder="Wajib Pajak Kendaraan Bermotor" value="<?php echo $ddk->anggota[2]["pajak_retribusi"]["pkb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pajak_retribusi_kebersihan" class="col-sm-3 control-label">Wajib Retribusi Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pajak_retribusi_kebersihan" name="data[anggota][2][pajak_retribusi][kebersihan]" placeholder="Wajib Retribusi Kebersihan" value="<?php echo $ddk->anggota[2]["pajak_retribusi"]["kebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pajak_retribusi_keamanan" class="col-sm-3 control-label">Wajib Retribusi Keamanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pajak_retribusi_keamanan" name="data[anggota][2][pajak_retribusi][keamanan]" placeholder="Wajib Retribusi Keamanan" value="<?php echo $ddk->anggota[2]["pajak_retribusi"]["keamanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pajak_retribusi_iuran" class="col-sm-3 control-label">Wajib iuran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pajak_retribusi_iuran" name="data[anggota][2][pajak_retribusi][iuran]" placeholder="Wajib iuran" value="<?php echo $ddk->anggota[2]["pajak_retribusi"]["iuran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pajak_retribusi_pungutan" class="col-sm-3 control-label">Wajib pungutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pajak_retribusi_pungutan" name="data[anggota][2][pajak_retribusi][pungutan]" placeholder="Wajib pungutan" value="<?php echo $ddk->anggota[2]["pajak_retribusi"]["pungutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pajak_retribusi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pajak_retribusi_lainnya" name="data[anggota][2][pajak_retribusi][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[2]["pajak_retribusi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_pajak_retribusi_lainnya" name="data[anggota][2][pajak_retribusi][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[2]["pajak_retribusi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Pemerintahan Yang Diikuti Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pemerintahan_kepala_desa" class="col-sm-3 control-label">Kepala Desa/Lurah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pemerintahan_kepala_desa" name="data[anggota][2][pemerintahan][kepala_desa]" placeholder="Kepala Desa/Lurah" value="<?php echo $ddk->anggota[2]["pemerintahan"]["kepala_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pemerintahan_sekretaris_desa" class="col-sm-3 control-label">Sekretaris Desa/Kelurahan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pemerintahan_sekretaris_desa" name="data[anggota][2][pemerintahan][sekretaris_desa]" placeholder="Sekretaris Desa/Kelurahan" value="<?php echo $ddk->anggota[2]["pemerintahan"]["sekretaris_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pemerintahan_kepala_urusan" class="col-sm-3 control-label">Kepala Urusan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pemerintahan_kepala_urusan" name="data[anggota][2][pemerintahan][kepala_urusan]" placeholder="Kepala Urusan" value="<?php echo $ddk->anggota[2]["pemerintahan"]["kepala_urusan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pemerintahan_kepala_dusun" class="col-sm-3 control-label">Kepala Dusun/Lingkungan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pemerintahan_kepala_dusun" name="data[anggota][2][pemerintahan][kepala_dusun]" placeholder="Kepala Dusun/Lingkungan" value="<?php echo $ddk->anggota[2]["pemerintahan"]["kepala_dusun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pemerintahan_staf_desa" class="col-sm-3 control-label">Staf Desa/Kelurahan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pemerintahan_staf_desa" name="data[anggota][2][pemerintahan][staf_desa]" placeholder="Staf Desa/Kelurahan" value="<?php echo $ddk->anggota[2]["pemerintahan"]["staf_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pemerintahan_ketua_bpd" class="col-sm-3 control-label">Ketua BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pemerintahan_ketua_bpd" name="data[anggota][2][pemerintahan][ketua_bpd]" placeholder="Ketua BPD" value="<?php echo $ddk->anggota[2]["pemerintahan"]["ketua_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pemerintahan_wakil_ketua_bpd" class="col-sm-3 control-label">Wakil Ketua BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pemerintahan_wakil_ketua_bpd" name="data[anggota][2][pemerintahan][wakil_ketua_bpd]" placeholder="Wakil Ketua BPD" value="<?php echo $ddk->anggota[2]["pemerintahan"]["wakil_ketua_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pemerintahan_sekretaris_bpd" class="col-sm-3 control-label">Sekretaris BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pemerintahan_sekretaris_bpd" name="data[anggota][2][pemerintahan][sekretaris_bpd]" placeholder="Sekretaris BPD" value="<?php echo $ddk->anggota[2]["pemerintahan"]["sekretaris_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pemerintahan_anggota_bpd" class="col-sm-3 control-label">Anggota BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pemerintahan_anggota_bpd" name="data[anggota][2][pemerintahan][anggota_bpd]" placeholder="Anggota BPD" value="<?php echo $ddk->anggota[2]["pemerintahan"]["anggota_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_pemerintahan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_pemerintahan_lainnya" name="data[anggota][2][pemerintahan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[2]["pemerintahan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_pemerintahan_lainnya" name="data[anggota][2][pemerintahan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[2]["pemerintahan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Kemasyarakatan Yang Diikuti Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_prt" class="col-sm-3 control-label">Pengurus RT</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_prt" name="data[anggota][2][kemasyarakatan][prt]" placeholder="Pengurus RT" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["prt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aprt" class="col-sm-3 control-label">Anggota Pengurus RT</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aprt" name="data[anggota][2][kemasyarakatan][aprt]" placeholder="Anggota Pengurus RT" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aprt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_prw" class="col-sm-3 control-label">Pengurus RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_prw" name="data[anggota][2][kemasyarakatan][prw]" placeholder="Pengurus RW" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["prw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aprw" class="col-sm-3 control-label">Anggota Pengurus RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aprw" name="data[anggota][2][kemasyarakatan][aprw]" placeholder="Anggota Pengurus RW" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aprw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_plkmdklpm" class="col-sm-3 control-label">Pengurus LKMD/K/LPM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_plkmdklpm" name="data[anggota][2][kemasyarakatan][plkmdklpm]" placeholder="Pengurus LKMD/K/LPM" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["plkmdklpm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_alkmdklpm" class="col-sm-3 control-label">Anggota LKMD/K/LPM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_alkmdklpm" name="data[anggota][2][kemasyarakatan][alkmdklpm]" placeholder="Anggota LKMD/K/LPM" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["alkmdklpm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_ppkk" class="col-sm-3 control-label">Pengurus PKK</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_ppkk" name="data[anggota][2][kemasyarakatan][ppkk]" placeholder="Pengurus PKK" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["ppkk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_apkk" class="col-sm-3 control-label">Anggota PKK</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_apkk" name="data[anggota][2][kemasyarakatan][apkk]" placeholder="Anggota PKK" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["apkk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pla" class="col-sm-3 control-label">Pengurus Lembaga Adat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pla" name="data[anggota][2][kemasyarakatan][pla]" placeholder="Pengurus Lembaga Adat" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pla"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pkt" class="col-sm-3 control-label">Pengurus Karang Taruna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pkt" name="data[anggota][2][kemasyarakatan][pkt]" placeholder="Pengurus Karang Taruna" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pkt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_akt" class="col-sm-3 control-label">Anggota Karang Taruna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_akt" name="data[anggota][2][kemasyarakatan][akt]" placeholder="Anggota Karang Taruna" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["akt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_phl" class="col-sm-3 control-label">Pengurus Hansip/Linmas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_phl" name="data[anggota][2][kemasyarakatan][phl]" placeholder="Pengurus Hansip/Linmas" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["phl"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pp" class="col-sm-3 control-label">Pengurus Poskamling</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pp" name="data[anggota][2][kemasyarakatan][pp]" placeholder="Pengurus Poskamling" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pop" class="col-sm-3 control-label">Pengurus Organisasi Perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pop" name="data[anggota][2][kemasyarakatan][pop]" placeholder="Pengurus Organisasi Perempuan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aop" class="col-sm-3 control-label">Anggota Organisasi Perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aop" name="data[anggota][2][kemasyarakatan][aop]" placeholder="Anggota Organisasi Perempuan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pob" class="col-sm-3 control-label">Pengurus Organisasi Bapak-bapak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pob" name="data[anggota][2][kemasyarakatan][pob]" placeholder="Pengurus Organisasi Bapak-bapak" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pob"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aob" class="col-sm-3 control-label">Anggota Organisasi Bapak-bapak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aob" name="data[anggota][2][kemasyarakatan][aob]" placeholder="Anggota Organisasi Bapak-bapak" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aob"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pok" class="col-sm-3 control-label">Pengurus Organisasi keagamaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pok" name="data[anggota][2][kemasyarakatan][pok]" placeholder="Pengurus Organisasi keagamaan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aok" class="col-sm-3 control-label">Anggota Organisasi keagamaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aok" name="data[anggota][2][kemasyarakatan][aok]" placeholder="Anggota Organisasi keagamaan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_popw" class="col-sm-3 control-label">Pengurus Organisasi profesi wartawan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_popw" name="data[anggota][2][kemasyarakatan][popw]" placeholder="Pengurus Organisasi profesi wartawan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["popw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aopw" class="col-sm-3 control-label">Anggota Organisasi profesi wartawan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aopw" name="data[anggota][2][kemasyarakatan][aopw]" placeholder="Anggota Organisasi profesi wartawan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aopw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pposyandu" class="col-sm-3 control-label">Pengurus Posyandu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pposyandu" name="data[anggota][2][kemasyarakatan][pposyandu]" placeholder="Pengurus Posyandu" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pposyandu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pposyantekdes" class="col-sm-3 control-label">Pengurus Posyantekdes</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pposyantekdes" name="data[anggota][2][kemasyarakatan][pposyantekdes]" placeholder="Pengurus Posyantekdes" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pposyantekdes"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_poktan" class="col-sm-3 control-label">Pengurus Organisasi Kelompok Tani/Nelayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_poktan" name="data[anggota][2][kemasyarakatan][poktan]" placeholder="Pengurus Organisasi Kelompok Tani/Nelayan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["poktan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aoktan" class="col-sm-3 control-label">Anggota Organisasi Kelompok Tani/Nelayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aoktan" name="data[anggota][2][kemasyarakatan][aoktan]" placeholder="Anggota Organisasi Kelompok Tani/Nelayan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aoktan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_plgr" class="col-sm-3 control-label">Pengurus Lembaga Gotong royong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_plgr" name="data[anggota][2][kemasyarakatan][plgr]" placeholder="Pengurus Lembaga Gotong royong" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["plgr"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_algr" class="col-sm-3 control-label">Anggota Lembaga Gotong royong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_algr" name="data[anggota][2][kemasyarakatan][algr]" placeholder="Anggota Lembaga Gotong royong" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["algr"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_popg" class="col-sm-3 control-label">Pengurus Organisasi Profesi guru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_popg" name="data[anggota][2][kemasyarakatan][popg]" placeholder="Pengurus Organisasi Profesi guru" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["popg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aopg" class="col-sm-3 control-label">Anggota Organisasi Profesi guru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aopg" name="data[anggota][2][kemasyarakatan][aopg]" placeholder="Anggota Organisasi Profesi guru" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aopg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_popdtm" class="col-sm-3 control-label">Pengurus Organisasi profesi dokter/tenaga medis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_popdtm" name="data[anggota][2][kemasyarakatan][popdtm]" placeholder="Pengurus Organisasi profesi dokter/tenaga medis" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["popdtm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aoptm" class="col-sm-3 control-label">Anggota Organisasi profesi/tenaga medis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aoptm" name="data[anggota][2][kemasyarakatan][aoptm]" placeholder="Anggota Organisasi profesi/tenaga medis" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aoptm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_popensiun" class="col-sm-3 control-label">Pengurus organisasi pensiunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_popensiun" name="data[anggota][2][kemasyarakatan][popensiun]" placeholder="Pengurus organisasi pensiunan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["popensiun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aopensiun" class="col-sm-3 control-label">Anggota organisasi pensiunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aopensiun" name="data[anggota][2][kemasyarakatan][aopensiun]" placeholder="Anggota organisasi pensiunan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aopensiun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_popp" class="col-sm-3 control-label">Pengurus organisasi pemirsa/pendengar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_popp" name="data[anggota][2][kemasyarakatan][popp]" placeholder="Pengurus organisasi pemirsa/pendengar" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["popp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aopp" class="col-sm-3 control-label">Anggota organisasi pemirsa/pendengar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aopp" name="data[anggota][2][kemasyarakatan][aopp]" placeholder="Anggota organisasi pemirsa/pendengar" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aopp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_plpa" class="col-sm-3 control-label">Pengurus lembaga pencinta alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_plpa" name="data[anggota][2][kemasyarakatan][plpa]" placeholder="Pengurus lembaga pencinta alam" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["plpa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_alpa" class="col-sm-3 control-label">Anggota organisasi pencinta alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_alpa" name="data[anggota][2][kemasyarakatan][alpa]" placeholder="Anggota organisasi pencinta alam" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["alpa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_popip" class="col-sm-3 control-label">Pengurus organisasi pengembangan ilmu pengetahuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_popip" name="data[anggota][2][kemasyarakatan][popip]" placeholder="Pengurus organisasi pengembangan ilmu pengetahuan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["popip"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_aopip" class="col-sm-3 control-label">Anggota organisasi pengembangan ilmu pengetaahuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_aopip" name="data[anggota][2][kemasyarakatan][aopip]" placeholder="Anggota organisasi pengembangan ilmu pengetaahuan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["aopip"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pemyaya" class="col-sm-3 control-label">Pemilik yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pemyaya" name="data[anggota][2][kemasyarakatan][pemyaya]" placeholder="Pemilik yayasan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pemyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_penyaya" class="col-sm-3 control-label">Pengurus yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_penyaya" name="data[anggota][2][kemasyarakatan][penyaya]" placeholder="Pengurus yayasan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["penyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_angyaya" class="col-sm-3 control-label">Anggota yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_angyaya" name="data[anggota][2][kemasyarakatan][angyaya]" placeholder="Anggota yayasan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["angyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pkebersihan" class="col-sm-3 control-label">Pengurus Satgas Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pkebersihan" name="data[anggota][2][kemasyarakatan][pkebersihan]" placeholder="Pengurus Satgas Kebersihan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pkebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_akebersihan" class="col-sm-3 control-label">Anggota Satgas Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_akebersihan" name="data[anggota][2][kemasyarakatan][akebersihan]" placeholder="Anggota Satgas Kebersihan" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["akebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_pkebakaran" class="col-sm-3 control-label">Pengurus Satgas Kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_pkebakaran" name="data[anggota][2][kemasyarakatan][pkebakaran]" placeholder="Pengurus Satgas Kebakaran" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["pkebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_akebakaran" class="col-sm-3 control-label">Anggota Satgas Kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_akebakaran" name="data[anggota][2][kemasyarakatan][akebakaran]" placeholder="Anggota Satgas Kebakaran" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["akebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_ppb" class="col-sm-3 control-label">Pengurus Posko Penanggulangan Bencana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_ppb" name="data[anggota][2][kemasyarakatan][ppb]" placeholder="Pengurus Posko Penanggulangan Bencana" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["ppb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_atpb" class="col-sm-3 control-label">Anggota Tim Penanggulangan Bencana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_atpb" name="data[anggota][2][kemasyarakatan][atpb]" placeholder="Anggota Tim Penanggulangan Bencana" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["atpb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_kemasyarakatan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_lainnya" name="data[anggota][2][kemasyarakatan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_kemasyarakatan_lainnya" name="data[anggota][2][kemasyarakatan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[2]["kemasyarakatan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Ekonomi Yang Dimiliki Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_koperasi" class="col-sm-3 control-label">Koperasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_koperasi" name="data[anggota][2][ekonomi][koperasi]" placeholder="Koperasi" value="<?php echo $ddk->anggota[2]["ekonomi"]["koperasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_unit_usaha_simpan_pinjam" class="col-sm-3 control-label">Unit Usaha Simpan Pinjam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_unit_usaha_simpan_pinjam" name="data[anggota][2][ekonomi][unit_usaha_simpan_pinjam]" placeholder="Unit Usaha Simpan Pinjam" value="<?php echo $ddk->anggota[2]["ekonomi"]["unit_usaha_simpan_pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_industri_kerajinan_tangan" class="col-sm-3 control-label">Industri Kerajinan Tangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_industri_kerajinan_tangan" name="data[anggota][2][ekonomi][industri_kerajinan_tangan]" placeholder="Industri Kerajinan Tangan" value="<?php echo $ddk->anggota[2]["ekonomi"]["industri_kerajinan_tangan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_industri_pakaian" class="col-sm-3 control-label">Industri Pakaian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_industri_pakaian" name="data[anggota][2][ekonomi][industri_pakaian]" placeholder="Industri Pakaian" value="<?php echo $ddk->anggota[2]["ekonomi"]["industri_pakaian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_industri_usaha_makanan" class="col-sm-3 control-label">Industri Usaha Makanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_industri_usaha_makanan" name="data[anggota][2][ekonomi][industri_usaha_makanan]" placeholder="Industri Usaha Makanan" value="<?php echo $ddk->anggota[2]["ekonomi"]["industri_usaha_makanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_industri_alat_rumah_tangga" class="col-sm-3 control-label">Industri Alat Rumah Tangga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_industri_alat_rumah_tangga" name="data[anggota][2][ekonomi][industri_alat_rumah_tangga]" placeholder="Industri Alat Rumah Tangga" value="<?php echo $ddk->anggota[2]["ekonomi"]["industri_alat_rumah_tangga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_industri_usaha_bahan_bangunan" class="col-sm-3 control-label">Industri Usaha Bahan Bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_industri_usaha_bahan_bangunan" name="data[anggota][2][ekonomi][industri_usaha_bahan_bangunan]" placeholder="Industri Usaha Bahan Bangunan" value="<?php echo $ddk->anggota[2]["ekonomi"]["industri_usaha_bahan_bangunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_industri_alat_pertanian" class="col-sm-3 control-label">Industri Alat Pertanian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_industri_alat_pertanian" name="data[anggota][2][ekonomi][industri_alat_pertanian]" placeholder="Industri Alat Pertanian" value="<?php echo $ddk->anggota[2]["ekonomi"]["industri_alat_pertanian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_restoran" class="col-sm-3 control-label">Restoran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_restoran" name="data[anggota][2][ekonomi][restoran]" placeholder="Restoran" value="<?php echo $ddk->anggota[2]["ekonomi"]["restoran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_toko__swalayan" class="col-sm-3 control-label">Toko/ Swalayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_toko__swalayan" name="data[anggota][2][ekonomi][toko__swalayan]" placeholder="Toko/ Swalayan" value="<?php echo $ddk->anggota[2]["ekonomi"]["toko__swalayan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_warung_kelontongan_kios" class="col-sm-3 control-label">Warung Kelontongan/Kios</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_warung_kelontongan_kios" name="data[anggota][2][ekonomi][warung_kelontongan_kios]" placeholder="Warung Kelontongan/Kios" value="<?php echo $ddk->anggota[2]["ekonomi"]["warung_kelontongan_kios"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_angkutan_darat" class="col-sm-3 control-label">Angkutan Darat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_angkutan_darat" name="data[anggota][2][ekonomi][angkutan_darat]" placeholder="Angkutan Darat" value="<?php echo $ddk->anggota[2]["ekonomi"]["angkutan_darat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_angkutan_sungai" class="col-sm-3 control-label">Angkutan Sungai</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_angkutan_sungai" name="data[anggota][2][ekonomi][angkutan_sungai]" placeholder="Angkutan Sungai" value="<?php echo $ddk->anggota[2]["ekonomi"]["angkutan_sungai"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_angkutan_laut" class="col-sm-3 control-label">Angkutan Laut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_angkutan_laut" name="data[anggota][2][ekonomi][angkutan_laut]" placeholder="Angkutan Laut" value="<?php echo $ddk->anggota[2]["ekonomi"]["angkutan_laut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_angkutan_udara" class="col-sm-3 control-label">Angkutan Udara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_angkutan_udara" name="data[anggota][2][ekonomi][angkutan_udara]" placeholder="Angkutan Udara" value="<?php echo $ddk->anggota[2]["ekonomi"]["angkutan_udara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_jasa_ekspedisi_pengiriman_barang" class="col-sm-3 control-label">Jasa Ekspedisi/Pengiriman Barang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_jasa_ekspedisi_pengiriman_barang" name="data[anggota][2][ekonomi][jasa_ekspedisi_pengiriman_barang]" placeholder="Jasa Ekspedisi/Pengiriman Barang" value="<?php echo $ddk->anggota[2]["ekonomi"]["jasa_ekspedisi_pengiriman_barang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_pasar_harian" class="col-sm-3 control-label">Usaha Pasar Harian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_pasar_harian" name="data[anggota][2][ekonomi][usaha_pasar_harian]" placeholder="Usaha Pasar Harian" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_pasar_harian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_pasar_mingguan" class="col-sm-3 control-label">Usaha Pasar Mingguan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_pasar_mingguan" name="data[anggota][2][ekonomi][usaha_pasar_mingguan]" placeholder="Usaha Pasar Mingguan" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_pasar_mingguan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_pasar_ternak" class="col-sm-3 control-label">Usaha Pasar Ternak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_pasar_ternak" name="data[anggota][2][ekonomi][usaha_pasar_ternak]" placeholder="Usaha Pasar Ternak" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_pasar_ternak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_pasar_hasil_bumi_dan_tambang" class="col-sm-3 control-label">Usaha Pasar Hasil Bumi Dan Tambang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_pasar_hasil_bumi_dan_tambang" name="data[anggota][2][ekonomi][usaha_pasar_hasil_bumi_dan_tambang]" placeholder="Usaha Pasar Hasil Bumi Dan Tambang" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_pasar_hasil_bumi_dan_tambang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_perdagangan_antar_pulau" class="col-sm-3 control-label">Usaha Perdagangan Antar Pulau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_perdagangan_antar_pulau" name="data[anggota][2][ekonomi][usaha_perdagangan_antar_pulau]" placeholder="Usaha Perdagangan Antar Pulau" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_perdagangan_antar_pulau"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_pengijon" class="col-sm-3 control-label">Pengijon</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_pengijon" name="data[anggota][2][ekonomi][pengijon]" placeholder="Pengijon" value="<?php echo $ddk->anggota[2]["ekonomi"]["pengijon"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_pedagang_pengumpul_tengkulak" class="col-sm-3 control-label">Pedagang Pengumpul/Tengkulak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_pedagang_pengumpul_tengkulak" name="data[anggota][2][ekonomi][pedagang_pengumpul_tengkulak]" placeholder="Pedagang Pengumpul/Tengkulak" value="<?php echo $ddk->anggota[2]["ekonomi"]["pedagang_pengumpul_tengkulak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_peternakan" class="col-sm-3 control-label">Usaha Peternakan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_peternakan" name="data[anggota][2][ekonomi][usaha_peternakan]" placeholder="Usaha Peternakan" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_peternakan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_perikanan" class="col-sm-3 control-label">Usaha Perikanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_perikanan" name="data[anggota][2][ekonomi][usaha_perikanan]" placeholder="Usaha Perikanan" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_perikanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_perkebunan" class="col-sm-3 control-label">Usaha Perkebunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_perkebunan" name="data[anggota][2][ekonomi][usaha_perkebunan]" placeholder="Usaha Perkebunan" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_perkebunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_kelompok_simpan_pinjam" class="col-sm-3 control-label">Kelompok Simpan Pinjam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_kelompok_simpan_pinjam" name="data[anggota][2][ekonomi][kelompok_simpan_pinjam]" placeholder="Kelompok Simpan Pinjam" value="<?php echo $ddk->anggota[2]["ekonomi"]["kelompok_simpan_pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_minuman" class="col-sm-3 control-label">Usaha Minuman</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_minuman" name="data[anggota][2][ekonomi][usaha_minuman]" placeholder="Usaha Minuman" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_minuman"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_industri_farmasi" class="col-sm-3 control-label">Industri Farmasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_industri_farmasi" name="data[anggota][2][ekonomi][industri_farmasi]" placeholder="Industri Farmasi" value="<?php echo $ddk->anggota[2]["ekonomi"]["industri_farmasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_industri_karoseri" class="col-sm-3 control-label">Industri Karoseri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_industri_karoseri" name="data[anggota][2][ekonomi][industri_karoseri]" placeholder="Industri Karoseri" value="<?php echo $ddk->anggota[2]["ekonomi"]["industri_karoseri"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_penitipan_kendaraan_bermotor" class="col-sm-3 control-label">Penitipan Kendaraan Bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_penitipan_kendaraan_bermotor" name="data[anggota][2][ekonomi][penitipan_kendaraan_bermotor]" placeholder="Penitipan Kendaraan Bermotor" value="<?php echo $ddk->anggota[2]["ekonomi"]["penitipan_kendaraan_bermotor"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_industri_perakitan_elektronik" class="col-sm-3 control-label">Industri Perakitan Elektronik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_industri_perakitan_elektronik" name="data[anggota][2][ekonomi][industri_perakitan_elektronik]" placeholder="Industri Perakitan Elektronik" value="<?php echo $ddk->anggota[2]["ekonomi"]["industri_perakitan_elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_pengolahan_kayu" class="col-sm-3 control-label">Pengolahan Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_pengolahan_kayu" name="data[anggota][2][ekonomi][pengolahan_kayu]" placeholder="Pengolahan Kayu" value="<?php echo $ddk->anggota[2]["ekonomi"]["pengolahan_kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_bioskop" class="col-sm-3 control-label">Bioskop</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_bioskop" name="data[anggota][2][ekonomi][bioskop]" placeholder="Bioskop" value="<?php echo $ddk->anggota[2]["ekonomi"]["bioskop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_film_keliling" class="col-sm-3 control-label">Film Keliling</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_film_keliling" name="data[anggota][2][ekonomi][film_keliling]" placeholder="Film Keliling" value="<?php echo $ddk->anggota[2]["ekonomi"]["film_keliling"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_sandiwara_drama" class="col-sm-3 control-label">Sandiwara/Drama</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_sandiwara_drama" name="data[anggota][2][ekonomi][sandiwara_drama]" placeholder="Sandiwara/Drama" value="<?php echo $ddk->anggota[2]["ekonomi"]["sandiwara_drama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_group_lawak" class="col-sm-3 control-label">Group Lawak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_group_lawak" name="data[anggota][2][ekonomi][group_lawak]" placeholder="Group Lawak" value="<?php echo $ddk->anggota[2]["ekonomi"]["group_lawak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_jaipongan" class="col-sm-3 control-label">Jaipongan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_jaipongan" name="data[anggota][2][ekonomi][jaipongan]" placeholder="Jaipongan" value="<?php echo $ddk->anggota[2]["ekonomi"]["jaipongan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_wayang_orang_golek" class="col-sm-3 control-label">Wayang Orang/Golek</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_wayang_orang_golek" name="data[anggota][2][ekonomi][wayang_orang_golek]" placeholder="Wayang Orang/Golek" value="<?php echo $ddk->anggota[2]["ekonomi"]["wayang_orang_golek"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_group_musik_band" class="col-sm-3 control-label">Group Musik/Band</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_group_musik_band" name="data[anggota][2][ekonomi][group_musik_band]" placeholder="Group Musik/Band" value="<?php echo $ddk->anggota[2]["ekonomi"]["group_musik_band"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_group_vokal_paduan_suara" class="col-sm-3 control-label">Group Vokal/Paduan Suara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_group_vokal_paduan_suara" name="data[anggota][2][ekonomi][group_vokal_paduan_suara]" placeholder="Group Vokal/Paduan Suara" value="<?php echo $ddk->anggota[2]["ekonomi"]["group_vokal_paduan_suara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_persewaan_tenaga_listrik" class="col-sm-3 control-label">Usaha Persewaan Tenaga Listrik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_persewaan_tenaga_listrik" name="data[anggota][2][ekonomi][usaha_persewaan_tenaga_listrik]" placeholder="Usaha Persewaan Tenaga Listrik" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_persewaan_tenaga_listrik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_pengecer_gas_dan_bahan_bakar_minyak" class="col-sm-3 control-label">Usaha Pengecer Gas Dan Bahan Bakar Minyak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_pengecer_gas_dan_bahan_bakar_minyak" name="data[anggota][2][ekonomi][usaha_pengecer_gas_dan_bahan_bakar_minyak]" placeholder="Usaha Pengecer Gas Dan Bahan Bakar Minyak" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_pengecer_gas_dan_bahan_bakar_minyak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_air_minum_dalam_kemasan" class="col-sm-3 control-label">Usaha Air Minum Dalam Kemasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_air_minum_dalam_kemasan" name="data[anggota][2][ekonomi][usaha_air_minum_dalam_kemasan]" placeholder="Usaha Air Minum Dalam Kemasan" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_air_minum_dalam_kemasan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_tukang_kayu" class="col-sm-3 control-label">Tukang Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_tukang_kayu" name="data[anggota][2][ekonomi][tukang_kayu]" placeholder="Tukang Kayu" value="<?php echo $ddk->anggota[2]["ekonomi"]["tukang_kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_tukang_batu" class="col-sm-3 control-label">Tukang Batu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_tukang_batu" name="data[anggota][2][ekonomi][tukang_batu]" placeholder="Tukang Batu" value="<?php echo $ddk->anggota[2]["ekonomi"]["tukang_batu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_tukang_jahit_bordir" class="col-sm-3 control-label">Tukang Jahit/Bordir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_tukang_jahit_bordir" name="data[anggota][2][ekonomi][tukang_jahit_bordir]" placeholder="Tukang Jahit/Bordir" value="<?php echo $ddk->anggota[2]["ekonomi"]["tukang_jahit_bordir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_tukang_cukur" class="col-sm-3 control-label">Tukang Cukur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_tukang_cukur" name="data[anggota][2][ekonomi][tukang_cukur]" placeholder="Tukang Cukur" value="<?php echo $ddk->anggota[2]["ekonomi"]["tukang_cukur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_tukang_service_elektronik" class="col-sm-3 control-label">Tukang Service Elektronik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_tukang_service_elektronik" name="data[anggota][2][ekonomi][tukang_service_elektronik]" placeholder="Tukang Service Elektronik" value="<?php echo $ddk->anggota[2]["ekonomi"]["tukang_service_elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_tukang_besi" class="col-sm-3 control-label">Tukang Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_tukang_besi" name="data[anggota][2][ekonomi][tukang_besi]" placeholder="Tukang Besi" value="<?php echo $ddk->anggota[2]["ekonomi"]["tukang_besi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_tukang_pijat_urut" class="col-sm-3 control-label">Tukang Pijat/Urut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_tukang_pijat_urut" name="data[anggota][2][ekonomi][tukang_pijat_urut]" placeholder="Tukang Pijat/Urut" value="<?php echo $ddk->anggota[2]["ekonomi"]["tukang_pijat_urut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_tukang_sumur" class="col-sm-3 control-label">Tukang Sumur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_tukang_sumur" name="data[anggota][2][ekonomi][tukang_sumur]" placeholder="Tukang Sumur" value="<?php echo $ddk->anggota[2]["ekonomi"]["tukang_sumur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_notaris" class="col-sm-3 control-label">Notaris</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_notaris" name="data[anggota][2][ekonomi][notaris]" placeholder="Notaris" value="<?php echo $ddk->anggota[2]["ekonomi"]["notaris"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_pengacara_advokat" class="col-sm-3 control-label">Pengacara/Advokat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_pengacara_advokat" name="data[anggota][2][ekonomi][pengacara_advokat]" placeholder="Pengacara/Advokat" value="<?php echo $ddk->anggota[2]["ekonomi"]["pengacara_advokat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_konsultan_manajemen" class="col-sm-3 control-label">Konsultan Manajemen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_konsultan_manajemen" name="data[anggota][2][ekonomi][konsultan_manajemen]" placeholder="Konsultan Manajemen" value="<?php echo $ddk->anggota[2]["ekonomi"]["konsultan_manajemen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_konsultan_teknis" class="col-sm-3 control-label">Konsultan Teknis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_konsultan_teknis" name="data[anggota][2][ekonomi][konsultan_teknis]" placeholder="Konsultan Teknis" value="<?php echo $ddk->anggota[2]["ekonomi"]["konsultan_teknis"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_pejabat_pembuat_akta_tanah" class="col-sm-3 control-label">Pejabat Pembuat Akta Tanah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_pejabat_pembuat_akta_tanah" name="data[anggota][2][ekonomi][pejabat_pembuat_akta_tanah]" placeholder="Pejabat Pembuat Akta Tanah" value="<?php echo $ddk->anggota[2]["ekonomi"]["pejabat_pembuat_akta_tanah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_losmen" class="col-sm-3 control-label">Losmen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_losmen" name="data[anggota][2][ekonomi][losmen]" placeholder="Losmen" value="<?php echo $ddk->anggota[2]["ekonomi"]["losmen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_wisma" class="col-sm-3 control-label">Wisma</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_wisma" name="data[anggota][2][ekonomi][wisma]" placeholder="Wisma" value="<?php echo $ddk->anggota[2]["ekonomi"]["wisma"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_asrama" class="col-sm-3 control-label">Asrama</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_asrama" name="data[anggota][2][ekonomi][asrama]" placeholder="Asrama" value="<?php echo $ddk->anggota[2]["ekonomi"]["asrama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_persewaan_kamar" class="col-sm-3 control-label">Persewaan Kamar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_persewaan_kamar" name="data[anggota][2][ekonomi][persewaan_kamar]" placeholder="Persewaan Kamar" value="<?php echo $ddk->anggota[2]["ekonomi"]["persewaan_kamar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_kontrakan_rumah" class="col-sm-3 control-label">Kontrakan Rumah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_kontrakan_rumah" name="data[anggota][2][ekonomi][kontrakan_rumah]" placeholder="Kontrakan Rumah" value="<?php echo $ddk->anggota[2]["ekonomi"]["kontrakan_rumah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_mess" class="col-sm-3 control-label">Mess</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_mess" name="data[anggota][2][ekonomi][mess]" placeholder="Mess" value="<?php echo $ddk->anggota[2]["ekonomi"]["mess"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_hotel" class="col-sm-3 control-label">Hotel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_hotel" name="data[anggota][2][ekonomi][hotel]" placeholder="Hotel" value="<?php echo $ddk->anggota[2]["ekonomi"]["hotel"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_home_stay" class="col-sm-3 control-label">Home Stay</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_home_stay" name="data[anggota][2][ekonomi][home_stay]" placeholder="Home Stay" value="<?php echo $ddk->anggota[2]["ekonomi"]["home_stay"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_villa" class="col-sm-3 control-label">Villa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_villa" name="data[anggota][2][ekonomi][villa]" placeholder="Villa" value="<?php echo $ddk->anggota[2]["ekonomi"]["villa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_town_house" class="col-sm-3 control-label">Town House</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_town_house" name="data[anggota][2][ekonomi][town_house]" placeholder="Town House" value="<?php echo $ddk->anggota[2]["ekonomi"]["town_house"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_asuransi" class="col-sm-3 control-label">Usaha Asuransi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_asuransi" name="data[anggota][2][ekonomi][usaha_asuransi]" placeholder="Usaha Asuransi" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_asuransi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_lembaga_keuangan_bukan_bank" class="col-sm-3 control-label">Lembaga Keuangan Bukan Bank</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_lembaga_keuangan_bukan_bank" name="data[anggota][2][ekonomi][lembaga_keuangan_bukan_bank]" placeholder="Lembaga Keuangan Bukan Bank" value="<?php echo $ddk->anggota[2]["ekonomi"]["lembaga_keuangan_bukan_bank"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_lembaga_perkreditan_rakyat" class="col-sm-3 control-label">Lembaga Perkreditan Rakyat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_lembaga_perkreditan_rakyat" name="data[anggota][2][ekonomi][lembaga_perkreditan_rakyat]" placeholder="Lembaga Perkreditan Rakyat" value="<?php echo $ddk->anggota[2]["ekonomi"]["lembaga_perkreditan_rakyat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_pegadaian" class="col-sm-3 control-label">Pegadaian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_pegadaian" name="data[anggota][2][ekonomi][pegadaian]" placeholder="Pegadaian" value="<?php echo $ddk->anggota[2]["ekonomi"]["pegadaian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_bank_perkreditan_rakyat" class="col-sm-3 control-label">Bank Perkreditan Rakyat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_bank_perkreditan_rakyat" name="data[anggota][2][ekonomi][bank_perkreditan_rakyat]" placeholder="Bank Perkreditan Rakyat" value="<?php echo $ddk->anggota[2]["ekonomi"]["bank_perkreditan_rakyat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_penyewaan_alat_pesta" class="col-sm-3 control-label">Usaha Penyewaan Alat Pesta</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_penyewaan_alat_pesta" name="data[anggota][2][ekonomi][usaha_penyewaan_alat_pesta]" placeholder="Usaha Penyewaan Alat Pesta" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_penyewaan_alat_pesta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_usaha_pengolahan_dan_penjualan_hasil_hutan" class="col-sm-3 control-label">Usaha Pengolahan dan Penjualan Hasil Hutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_usaha_pengolahan_dan_penjualan_hasil_hutan" name="data[anggota][2][ekonomi][usaha_pengolahan_dan_penjualan_hasil_hutan]" placeholder="Usaha Pengolahan dan Penjualan Hasil Hutan" value="<?php echo $ddk->anggota[2]["ekonomi"]["usaha_pengolahan_dan_penjualan_hasil_hutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_ekonomi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_ekonomi_lainnya" name="data[anggota][2][ekonomi][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[2]["ekonomi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_ekonomi_lainnya" name="data[anggota][2][ekonomi][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[2]["ekonomi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Produksi bahan galian yang dimiliki anggota keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_batu_kali" class="col-sm-3 control-label">Batu kali</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_batu_kali" name="data[anggota][2][galian][batu_kali][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["batu_kali"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_kali" name="data[anggota][2][galian][batu_kali][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["batu_kali"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_kali" name="data[anggota][2][galian][batu_kali][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["batu_kali"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_kali" name="data[anggota][2][galian][batu_kali][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["batu_kali"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_batu_kapur" class="col-sm-3 control-label">Batu kapur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_batu_kapur" name="data[anggota][2][galian][batu_kapur][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["batu_kapur"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_kapur" name="data[anggota][2][galian][batu_kapur][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["batu_kapur"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_kapur" name="data[anggota][2][galian][batu_kapur][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["batu_kapur"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_kapur" name="data[anggota][2][galian][batu_kapur][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["batu_kapur"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_pasir" class="col-sm-3 control-label">Pasir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_pasir" name="data[anggota][2][galian][pasir][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["pasir"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir" name="data[anggota][2][galian][pasir][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["pasir"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir" name="data[anggota][2][galian][pasir][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["pasir"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir" name="data[anggota][2][galian][pasir][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["pasir"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_emas" class="col-sm-3 control-label">Emas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_emas" name="data[anggota][2][galian][emas][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["emas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_emas" name="data[anggota][2][galian][emas][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["emas"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_emas" name="data[anggota][2][galian][emas][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["emas"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_emas" name="data[anggota][2][galian][emas][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["emas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_kuningan" class="col-sm-3 control-label">Kuningan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_kuningan" name="data[anggota][2][galian][kuningan][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["kuningan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_kuningan" name="data[anggota][2][galian][kuningan][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["kuningan"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_kuningan" name="data[anggota][2][galian][kuningan][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["kuningan"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_kuningan" name="data[anggota][2][galian][kuningan][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["kuningan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_aluminium" class="col-sm-3 control-label">Aluminium</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_aluminium" name="data[anggota][2][galian][aluminium][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["aluminium"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_aluminium" name="data[anggota][2][galian][aluminium][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["aluminium"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_aluminium" name="data[anggota][2][galian][aluminium][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["aluminium"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_aluminium" name="data[anggota][2][galian][aluminium][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["aluminium"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_perunggu" class="col-sm-3 control-label">Perunggu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_perunggu" name="data[anggota][2][galian][perunggu][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["perunggu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_perunggu" name="data[anggota][2][galian][perunggu][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["perunggu"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_perunggu" name="data[anggota][2][galian][perunggu][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["perunggu"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_perunggu" name="data[anggota][2][galian][perunggu][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["perunggu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_belerang" class="col-sm-3 control-label">Belerang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_belerang" name="data[anggota][2][galian][belerang][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["belerang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_belerang" name="data[anggota][2][galian][belerang][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["belerang"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_belerang" name="data[anggota][2][galian][belerang][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["belerang"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_belerang" name="data[anggota][2][galian][belerang][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["belerang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_batu_marmer" class="col-sm-3 control-label">Batu marmer</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_batu_marmer" name="data[anggota][2][galian][batu_marmer][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["batu_marmer"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_marmer" name="data[anggota][2][galian][batu_marmer][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["batu_marmer"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_marmer" name="data[anggota][2][galian][batu_marmer][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["batu_marmer"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_marmer" name="data[anggota][2][galian][batu_marmer][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["batu_marmer"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_batu_cadas" class="col-sm-3 control-label">Batu cadas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_batu_cadas" name="data[anggota][2][galian][batu_cadas][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["batu_cadas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_cadas" name="data[anggota][2][galian][batu_cadas][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["batu_cadas"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_cadas" name="data[anggota][2][galian][batu_cadas][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["batu_cadas"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_cadas" name="data[anggota][2][galian][batu_cadas][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["batu_cadas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_batu_apung" class="col-sm-3 control-label">Batu apung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_batu_apung" name="data[anggota][2][galian][batu_apung][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["batu_apung"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_apung" name="data[anggota][2][galian][batu_apung][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["batu_apung"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_apung" name="data[anggota][2][galian][batu_apung][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["batu_apung"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_apung" name="data[anggota][2][galian][batu_apung][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["batu_apung"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_pasir_kwarsa" class="col-sm-3 control-label">Pasir kwarsa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_pasir_kwarsa" name="data[anggota][2][galian][pasir_kwarsa][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["pasir_kwarsa"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir_kwarsa" name="data[anggota][2][galian][pasir_kwarsa][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["pasir_kwarsa"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir_kwarsa" name="data[anggota][2][galian][pasir_kwarsa][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["pasir_kwarsa"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir_kwarsa" name="data[anggota][2][galian][pasir_kwarsa][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["pasir_kwarsa"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_batubara" class="col-sm-3 control-label">Batubara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_batubara" name="data[anggota][2][galian][batubara][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["batubara"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batubara" name="data[anggota][2][galian][batubara][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["batubara"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batubara" name="data[anggota][2][galian][batubara][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["batubara"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batubara" name="data[anggota][2][galian][batubara][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["batubara"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_batu_granit" class="col-sm-3 control-label">Batu Granit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_batu_granit" name="data[anggota][2][galian][batu_granit][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["batu_granit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_granit" name="data[anggota][2][galian][batu_granit][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["batu_granit"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_granit" name="data[anggota][2][galian][batu_granit][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["batu_granit"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_granit" name="data[anggota][2][galian][batu_granit][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["batu_granit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_batu_gamping" class="col-sm-3 control-label">Batu Gamping</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_batu_gamping" name="data[anggota][2][galian][batu_gamping][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["batu_gamping"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_gamping" name="data[anggota][2][galian][batu_gamping][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["batu_gamping"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_gamping" name="data[anggota][2][galian][batu_gamping][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["batu_gamping"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_gamping" name="data[anggota][2][galian][batu_gamping][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["batu_gamping"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_mangan" class="col-sm-3 control-label">Mangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_mangan" name="data[anggota][2][galian][mangan][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["mangan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_mangan" name="data[anggota][2][galian][mangan][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["mangan"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_mangan" name="data[anggota][2][galian][mangan][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["mangan"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_mangan" name="data[anggota][2][galian][mangan][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["mangan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_batu_trass" class="col-sm-3 control-label">Batu Trass</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_batu_trass" name="data[anggota][2][galian][batu_trass][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["batu_trass"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_trass" name="data[anggota][2][galian][batu_trass][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["batu_trass"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_trass" name="data[anggota][2][galian][batu_trass][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["batu_trass"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_trass" name="data[anggota][2][galian][batu_trass][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["batu_trass"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_batu_putih" class="col-sm-3 control-label">Batu Putih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_batu_putih" name="data[anggota][2][galian][batu_putih][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["batu_putih"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_putih" name="data[anggota][2][galian][batu_putih][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["batu_putih"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_putih" name="data[anggota][2][galian][batu_putih][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["batu_putih"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_batu_putih" name="data[anggota][2][galian][batu_putih][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["batu_putih"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_pasir_batu" class="col-sm-3 control-label">Pasir Batu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_pasir_batu" name="data[anggota][2][galian][pasir_batu][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["pasir_batu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir_batu" name="data[anggota][2][galian][pasir_batu][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["pasir_batu"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir_batu" name="data[anggota][2][galian][pasir_batu][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["pasir_batu"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir_batu" name="data[anggota][2][galian][pasir_batu][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["pasir_batu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_pasir_besi" class="col-sm-3 control-label">Pasir Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_pasir_besi" name="data[anggota][2][galian][pasir_besi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["pasir_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir_besi" name="data[anggota][2][galian][pasir_besi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["pasir_besi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir_besi" name="data[anggota][2][galian][pasir_besi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["pasir_besi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_pasir_besi" name="data[anggota][2][galian][pasir_besi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["pasir_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_gips" class="col-sm-3 control-label">Gips</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_gips" name="data[anggota][2][galian][gips][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["gips"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_gips" name="data[anggota][2][galian][gips][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["gips"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_gips" name="data[anggota][2][galian][gips][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["gips"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_gips" name="data[anggota][2][galian][gips][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["gips"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_minyak_bumi" class="col-sm-3 control-label">Minyak Bumi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_minyak_bumi" name="data[anggota][2][galian][minyak_bumi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["minyak_bumi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_minyak_bumi" name="data[anggota][2][galian][minyak_bumi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["minyak_bumi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_minyak_bumi" name="data[anggota][2][galian][minyak_bumi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["minyak_bumi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_minyak_bumi" name="data[anggota][2][galian][minyak_bumi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["minyak_bumi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_gas_alam" class="col-sm-3 control-label">Gas Alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_gas_alam" name="data[anggota][2][galian][gas_alam][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["gas_alam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_gas_alam" name="data[anggota][2][galian][gas_alam][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["gas_alam"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_gas_alam" name="data[anggota][2][galian][gas_alam][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["gas_alam"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_gas_alam" name="data[anggota][2][galian][gas_alam][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["gas_alam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_perak" class="col-sm-3 control-label">Perak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_perak" name="data[anggota][2][galian][perak][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["perak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_perak" name="data[anggota][2][galian][perak][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["perak"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_perak" name="data[anggota][2][galian][perak][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["perak"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_perak" name="data[anggota][2][galian][perak][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["perak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_timah" class="col-sm-3 control-label">Timah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_timah" name="data[anggota][2][galian][timah][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["timah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_timah" name="data[anggota][2][galian][timah][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["timah"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_timah" name="data[anggota][2][galian][timah][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["timah"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_timah" name="data[anggota][2][galian][timah][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["timah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_tembaga" class="col-sm-3 control-label">Tembaga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_tembaga" name="data[anggota][2][galian][tembaga][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["tembaga"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_tembaga" name="data[anggota][2][galian][tembaga][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["tembaga"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_tembaga" name="data[anggota][2][galian][tembaga][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["tembaga"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_tembaga" name="data[anggota][2][galian][tembaga][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["tembaga"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_biji_besi" class="col-sm-3 control-label">Biji Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_biji_besi" name="data[anggota][2][galian][biji_besi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["biji_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_biji_besi" name="data[anggota][2][galian][biji_besi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["biji_besi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_biji_besi" name="data[anggota][2][galian][biji_besi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["biji_besi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_biji_besi" name="data[anggota][2][galian][biji_besi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["biji_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_uranium" class="col-sm-3 control-label">Uranium</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_uranium" name="data[anggota][2][galian][uranium][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["uranium"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_uranium" name="data[anggota][2][galian][uranium][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["uranium"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_uranium" name="data[anggota][2][galian][uranium][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["uranium"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_uranium" name="data[anggota][2][galian][uranium][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["uranium"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_bouxit" class="col-sm-3 control-label">Bouxit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_bouxit" name="data[anggota][2][galian][bouxit][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["bouxit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_bouxit" name="data[anggota][2][galian][bouxit][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["bouxit"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_bouxit" name="data[anggota][2][galian][bouxit][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["bouxit"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_bouxit" name="data[anggota][2][galian][bouxit][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["bouxit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_garam" class="col-sm-3 control-label">Garam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_garam" name="data[anggota][2][galian][garam][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["garam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_garam" name="data[anggota][2][galian][garam][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["garam"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_garam" name="data[anggota][2][galian][garam][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["garam"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_garam" name="data[anggota][2][galian][garam][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["garam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_nikel" class="col-sm-3 control-label">Nikel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_nikel" name="data[anggota][2][galian][nikel][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["nikel"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_nikel" name="data[anggota][2][galian][nikel][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["nikel"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_nikel" name="data[anggota][2][galian][nikel][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["nikel"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_nikel" name="data[anggota][2][galian][nikel][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["nikel"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota3_galian_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota3_galian_lainnya" name="data[anggota][2][galian][lainnya][keterangan]" placeholder="Keterangan" value="<?php echo $ddk->anggota[2]["galian"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_lainnya" name="data[anggota][2][galian][lainnya][opsi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[2]["galian"]["lainnya"]["opsi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_lainnya" name="data[anggota][2][galian][lainnya][opsi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[2]["galian"]["lainnya"]["opsi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_lainnya" name="data[anggota][2][galian][lainnya][opsi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[2]["galian"]["lainnya"]["opsi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota3_galian_lainnya" name="data[anggota][2][galian][lainnya][opsi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[2]["galian"]["lainnya"]["opsi"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Data Anggota Keluarga 4</strong></h4>
				<h4>Biodata</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_no_urut" class="col-sm-3 control-label">Nomor Urut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_no_urut" name="data[anggota][3][no_urut]" placeholder="Nomor Urut" value="<?php echo $ddk->anggota[3]["no_urut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_nik" class="col-sm-3 control-label">Nomor Induk Kependudukan (NIK)</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_nik" name="data[anggota][3][nik]" placeholder="Nomor Induk Kependudukan (NIK)" value="<?php echo $ddk->anggota[3]["nik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_nama" class="col-sm-3 control-label">Nama Lengkap</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_nama" name="data[anggota][3][nama]" placeholder="Nama Lengkap" value="<?php echo $ddk->anggota[3]["nama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_no_akte" class="col-sm-3 control-label">Nomor Akte Kelahiran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_no_akte" name="data[anggota][3][no_akte]" placeholder="Nomor Akte Kelahiran" value="<?php echo $ddk->anggota[3]["no_akte"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_jenis_kelamin" class="col-sm-3 control-label">Jenis Kelamin</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][3][jenis_kelamin]" id="anggota4_jenis_kelamin">
					<option value="laki" <?php echo $ddk->anggota[3]["jenis_kelamin"] == "laki" ? "selected" : ""; ?>>Laki-laki</option>
					<option value="perempuan" <?php echo $ddk->anggota[3]["jenis_kelamin"] == "perempuan" ? "selected" : ""; ?>>Perempuan</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_hubungan" class="col-sm-3 control-label">Hubungan dengan Kepala Keluarga</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][3][hubungan]" id="anggota4_hubungan">
					<option value="istri" <?php echo $ddk->anggota[3]["hubungan"] == "istri" ? "selected" : ""; ?>>Istri</option>
					<option value="suami" <?php echo $ddk->anggota[3]["hubungan"] == "suami" ? "selected" : ""; ?>>Suami</option>
					<option value="anak" <?php echo $ddk->anggota[3]["hubungan"] == "anak" ? "selected" : ""; ?>>Anak</option>
					<option value="cucu" <?php echo $ddk->anggota[3]["hubungan"] == "cucu" ? "selected" : ""; ?>>Cucu</option>
					<option value="mertua" <?php echo $ddk->anggota[3]["hubungan"] == "mertua" ? "selected" : ""; ?>>Mertua</option>
					<option value="menantu" <?php echo $ddk->anggota[3]["hubungan"] == "menantu" ? "selected" : ""; ?>>Menantu</option>
					<option value="keponakan" <?php echo $ddk->anggota[3]["hubungan"] == "keponakan" ? "selected" : ""; ?>>Keponakan</option>
					<option value="lainnya" <?php echo $ddk->anggota[3]["hubungan"] == "lainnya" ? "selected" : ""; ?>>Lainnya</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_tempat_lahir" class="col-sm-3 control-label">Tempat Lahir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_tempat_lahir" name="data[anggota][3][tempat_lahir]" placeholder="Tempat Lahir" value="<?php echo $ddk->anggota[3]["tempat_lahir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_tanggal_lahir" class="col-sm-3 control-label">Tanggal Lahir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="anggota4_tanggal_lahir" name="data[anggota][3][tanggal_lahir]" placeholder="Tanggal Lahir">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_tanggal_pencatatan" class="col-sm-3 control-label">Tanggal Pencatatan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="anggota4_tanggal_pencatatan" name="data[anggota][3][tanggal_pencatatan]" placeholder="Tanggal Pencatatan">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_status_kawin" class="col-sm-3 control-label">Status Perkawinan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][3][status_kawin]" id="anggota4_status_kawin">
					<option value="kawin" <?php echo $ddk->anggota[3]["status_kawin"] == "kawin" ? "selected" : ""; ?>>Kawin</option>
					<option value="belum" <?php echo $ddk->anggota[3]["status_kawin"] == "belum" ? "selected" : ""; ?>>Belum Kawin</option>
					<option value="pernah" <?php echo $ddk->anggota[3]["status_kawin"] == "pernah" ? "selected" : ""; ?>>Pernah Kawin</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_agama" class="col-sm-3 control-label">Agama dan Aliran Kepercayaan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][3][agama]" id="anggota4_agama">
					<option value="islam" <?php echo $ddk->anggota[3]["agama"] == "islam" ? "selected" : ""; ?>>Islam</option>
					<option value="protestan" <?php echo $ddk->anggota[3]["agama"] == "protestan" ? "selected" : ""; ?>>Protestan</option>
					<option value="katolik" <?php echo $ddk->anggota[3]["agama"] == "katolik" ? "selected" : ""; ?>>Katolik</option>
					<option value="hindu" <?php echo $ddk->anggota[3]["agama"] == "hindu" ? "selected" : ""; ?>>Hindu</option>
					<option value="budha" <?php echo $ddk->anggota[3]["agama"] == "budha" ? "selected" : ""; ?>>Budha</option>
					<option value="kong hu chu" <?php echo $ddk->anggota[3]["agama"] == "kong hu chu" ? "selected" : ""; ?>>Kong Hu Chu</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_darah" class="col-sm-3 control-label">Golongan Darah</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][3][darah]" id="anggota4_darah">
					<option value="O" <?php echo $ddk->anggota[3]["darah"] == "O" ? "selected" : ""; ?>>O</option>
					<option value="A" <?php echo $ddk->anggota[3]["darah"] == "A" ? "selected" : ""; ?>>A</option>
					<option value="B" <?php echo $ddk->anggota[3]["darah"] == "B" ? "selected" : ""; ?>>B</option>
					<option value="AB" <?php echo $ddk->anggota[3]["darah"] == "AB" ? "selected" : ""; ?>>AB</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kewarganegaraan" class="col-sm-3 control-label">Kewarganegaraan/Etnis/Suku</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kewarganegaraan" name="data[anggota][3][kewarganegaraan]" placeholder="Kewarganegaraan/Etnis/Suku" value="<?php echo $ddk->anggota[3]["kewarganegaraan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pendidikan" class="col-sm-3 control-label">Pendidikan Umum Terakhir</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][3][pendidikan]" id="anggota4_pendidikan">
					<option value="SD" <?php echo $ddk->anggota[3]["pendidikan"] == "SD" ? "selected" : ""; ?>>SD</option>
					<option value="SMP" <?php echo $ddk->anggota[3]["pendidikan"] == "SMP" ? "selected" : ""; ?>>SMP</option>
					<option value="SMA" <?php echo $ddk->anggota[3]["pendidikan"] == "SMA" ? "selected" : ""; ?>>SMA</option>
					<option value="Diploma" <?php echo $ddk->anggota[3]["pendidikan"] == "Diploma" ? "selected" : ""; ?>>Diploma</option>
					<option value="S1" <?php echo $ddk->anggota[3]["pendidikan"] == "S1" ? "selected" : ""; ?>>S1</option>
					<option value="S2" <?php echo $ddk->anggota[3]["pendidikan"] == "S2" ? "selected" : ""; ?>>S2</option>
					<option value="S3" <?php echo $ddk->anggota[3]["pendidikan"] == "S3" ? "selected" : ""; ?>>S3</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pekerjaan" class="col-sm-3 control-label">Mata Pencaharian Pokok/Pekerjaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pekerjaan" name="data[anggota][3][pekerjaan]" placeholder="Mata Pencaharian Pokok/Pekerjaan" value="<?php echo $ddk->anggota[3]["pekerjaan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_nama_ortu" class="col-sm-3 control-label">Nama Bapak / Ibu Kandung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_nama_ortu" name="data[anggota][3][nama_ortu]" placeholder="Nama Bapak / Ibu Kandung" value="<?php echo $ddk->anggota[3]["nama_ortu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kb" class="col-sm-3 control-label">Akseptor KB</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][3][kb]" id="anggota4_kb">
					<option value="Pil" <?php echo $ddk->anggota[3]["kb"] == "Pil" ? "selected" : ""; ?>>Pil</option>
					<option value="Spiral" <?php echo $ddk->anggota[3]["kb"] == "Spiral" ? "selected" : ""; ?>>Spiral</option>
					<option value="Suntik" <?php echo $ddk->anggota[3]["kb"] == "Suntik" ? "selected" : ""; ?>>Suntik</option>
					<option value="Susuk" <?php echo $ddk->anggota[3]["kb"] == "Susuk" ? "selected" : ""; ?>>Susuk</option>
					<option value="Kondom" <?php echo $ddk->anggota[3]["kb"] == "Kondom" ? "selected" : ""; ?>>Kondom</option>
					<option value="Vaksetomi" <?php echo $ddk->anggota[3]["kb"] == "Vaksetomi" ? "selected" : ""; ?>>Vaksetomi</option>
					<option value="Tubektomi" <?php echo $ddk->anggota[3]["kb"] == "Tubektomi" ? "selected" : ""; ?>>Tubektomi</option>
				</select>
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Cacat Menurut Jenis</strong></h4>
				<h4>Cacat Fisik</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_cacat_fisik_tuli" class="col-sm-3 control-label">Tuna rungu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_cacat_fisik_tuli" name="data[anggota][3][cacat_fisik][tuli]" placeholder="Tuna rungu" value="<?php echo $ddk->anggota[3]["cacat_fisik"]["tuli"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_cacat_fisik_bisu" class="col-sm-3 control-label">Tuna wicara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_cacat_fisik_bisu" name="data[anggota][3][cacat_fisik][bisu]" placeholder="Tuna wicara" value="<?php echo $ddk->anggota[3]["cacat_fisik"]["bisu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_cacat_fisik_buta" class="col-sm-3 control-label">Tuna netra</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_cacat_fisik_buta" name="data[anggota][3][cacat_fisik][buta]" placeholder="Tuna netra" value="<?php echo $ddk->anggota[3]["cacat_fisik"]["buta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_cacat_fisik_lumpuh" class="col-sm-3 control-label">Lumpuh</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_cacat_fisik_lumpuh" name="data[anggota][3][cacat_fisik][lumpuh]" placeholder="Lumpuh" value="<?php echo $ddk->anggota[3]["cacat_fisik"]["lumpuh"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_cacat_fisik_sumbing" class="col-sm-3 control-label">Sumbing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_cacat_fisik_sumbing" name="data[anggota][3][cacat_fisik][sumbing]" placeholder="Sumbing" value="<?php echo $ddk->anggota[3]["cacat_fisik"]["sumbing"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_cacat_fisik_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_cacat_fisik_lainnya" name="data[anggota][3][cacat_fisik][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[3]["cacat_fisik"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_cacat_fisik_lainnya" name="data[anggota][3][cacat_fisik][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[3]["cacat_fisik"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4>Cacat Mental</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_cacat_mental_idiot" class="col-sm-3 control-label">Idiot</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_cacat_mental_idiot" name="data[anggota][3][cacat_mental][idiot]" placeholder="Idiot" value="<?php echo $ddk->anggota[3]["cacat_mental"]["idiot"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_cacat_mental_gila" class="col-sm-3 control-label">Gila</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_cacat_mental_gila" name="data[anggota][3][cacat_mental][gila]" placeholder="Gila" value="<?php echo $ddk->anggota[3]["cacat_mental"]["gila"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_cacat_mental_stress" class="col-sm-3 control-label">Stress</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_cacat_mental_stress" name="data[anggota][3][cacat_mental][stress]" placeholder="Stress" value="<?php echo $ddk->anggota[3]["cacat_mental"]["stress"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_cacat_mental_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_cacat_mental_lainnya" name="data[anggota][3][cacat_mental][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[3]["cacat_mental"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_cacat_mental_lainnya" name="data[anggota][3][cacat_mental][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[3]["cacat_mental"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Kedudukan Anggota Keluarga sebagai Wajib Pajak dan Retribusi</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pajak_retribusi_pbb" class="col-sm-3 control-label">Wajib Pajak Bumi dan Bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pajak_retribusi_pbb" name="data[anggota][3][pajak_retribusi][pbb]" placeholder="Wajib Pajak Bumi dan Bangunan" value="<?php echo $ddk->anggota[3]["pajak_retribusi"]["pbb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pajak_retribusi_ppp" class="col-sm-3 control-label">Wajib Pajak Penghasilan Perorangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pajak_retribusi_ppp" name="data[anggota][3][pajak_retribusi][ppp]" placeholder="Wajib Pajak Penghasilan Perorangan" value="<?php echo $ddk->anggota[3]["pajak_retribusi"]["ppp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pajak_retribusi_pb" class="col-sm-3 control-label">Wajib Pajak Badan/Perusahaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pajak_retribusi_pb" name="data[anggota][3][pajak_retribusi][pb]" placeholder="Wajib Pajak Badan/Perusahaan" value="<?php echo $ddk->anggota[3]["pajak_retribusi"]["pb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pajak_retribusi_pkb" class="col-sm-3 control-label">Wajib Pajak Kendaraan Bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pajak_retribusi_pkb" name="data[anggota][3][pajak_retribusi][pkb]" placeholder="Wajib Pajak Kendaraan Bermotor" value="<?php echo $ddk->anggota[3]["pajak_retribusi"]["pkb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pajak_retribusi_kebersihan" class="col-sm-3 control-label">Wajib Retribusi Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pajak_retribusi_kebersihan" name="data[anggota][3][pajak_retribusi][kebersihan]" placeholder="Wajib Retribusi Kebersihan" value="<?php echo $ddk->anggota[3]["pajak_retribusi"]["kebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pajak_retribusi_keamanan" class="col-sm-3 control-label">Wajib Retribusi Keamanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pajak_retribusi_keamanan" name="data[anggota][3][pajak_retribusi][keamanan]" placeholder="Wajib Retribusi Keamanan" value="<?php echo $ddk->anggota[3]["pajak_retribusi"]["keamanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pajak_retribusi_iuran" class="col-sm-3 control-label">Wajib iuran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pajak_retribusi_iuran" name="data[anggota][3][pajak_retribusi][iuran]" placeholder="Wajib iuran" value="<?php echo $ddk->anggota[3]["pajak_retribusi"]["iuran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pajak_retribusi_pungutan" class="col-sm-3 control-label">Wajib pungutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pajak_retribusi_pungutan" name="data[anggota][3][pajak_retribusi][pungutan]" placeholder="Wajib pungutan" value="<?php echo $ddk->anggota[3]["pajak_retribusi"]["pungutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pajak_retribusi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pajak_retribusi_lainnya" name="data[anggota][3][pajak_retribusi][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[3]["pajak_retribusi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_pajak_retribusi_lainnya" name="data[anggota][3][pajak_retribusi][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[3]["pajak_retribusi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Pemerintahan Yang Diikuti Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pemerintahan_kepala_desa" class="col-sm-3 control-label">Kepala Desa/Lurah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pemerintahan_kepala_desa" name="data[anggota][3][pemerintahan][kepala_desa]" placeholder="Kepala Desa/Lurah" value="<?php echo $ddk->anggota[3]["pemerintahan"]["kepala_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pemerintahan_sekretaris_desa" class="col-sm-3 control-label">Sekretaris Desa/Kelurahan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pemerintahan_sekretaris_desa" name="data[anggota][3][pemerintahan][sekretaris_desa]" placeholder="Sekretaris Desa/Kelurahan" value="<?php echo $ddk->anggota[3]["pemerintahan"]["sekretaris_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pemerintahan_kepala_urusan" class="col-sm-3 control-label">Kepala Urusan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pemerintahan_kepala_urusan" name="data[anggota][3][pemerintahan][kepala_urusan]" placeholder="Kepala Urusan" value="<?php echo $ddk->anggota[3]["pemerintahan"]["kepala_urusan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pemerintahan_kepala_dusun" class="col-sm-3 control-label">Kepala Dusun/Lingkungan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pemerintahan_kepala_dusun" name="data[anggota][3][pemerintahan][kepala_dusun]" placeholder="Kepala Dusun/Lingkungan" value="<?php echo $ddk->anggota[3]["pemerintahan"]["kepala_dusun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pemerintahan_staf_desa" class="col-sm-3 control-label">Staf Desa/Kelurahan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pemerintahan_staf_desa" name="data[anggota][3][pemerintahan][staf_desa]" placeholder="Staf Desa/Kelurahan" value="<?php echo $ddk->anggota[3]["pemerintahan"]["staf_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pemerintahan_ketua_bpd" class="col-sm-3 control-label">Ketua BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pemerintahan_ketua_bpd" name="data[anggota][3][pemerintahan][ketua_bpd]" placeholder="Ketua BPD" value="<?php echo $ddk->anggota[3]["pemerintahan"]["ketua_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pemerintahan_wakil_ketua_bpd" class="col-sm-3 control-label">Wakil Ketua BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pemerintahan_wakil_ketua_bpd" name="data[anggota][3][pemerintahan][wakil_ketua_bpd]" placeholder="Wakil Ketua BPD" value="<?php echo $ddk->anggota[3]["pemerintahan"]["wakil_ketua_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pemerintahan_sekretaris_bpd" class="col-sm-3 control-label">Sekretaris BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pemerintahan_sekretaris_bpd" name="data[anggota][3][pemerintahan][sekretaris_bpd]" placeholder="Sekretaris BPD" value="<?php echo $ddk->anggota[3]["pemerintahan"]["sekretaris_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pemerintahan_anggota_bpd" class="col-sm-3 control-label">Anggota BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pemerintahan_anggota_bpd" name="data[anggota][3][pemerintahan][anggota_bpd]" placeholder="Anggota BPD" value="<?php echo $ddk->anggota[3]["pemerintahan"]["anggota_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_pemerintahan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_pemerintahan_lainnya" name="data[anggota][3][pemerintahan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[3]["pemerintahan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_pemerintahan_lainnya" name="data[anggota][3][pemerintahan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[3]["pemerintahan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Kemasyarakatan Yang Diikuti Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_prt" class="col-sm-3 control-label">Pengurus RT</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_prt" name="data[anggota][3][kemasyarakatan][prt]" placeholder="Pengurus RT" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["prt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aprt" class="col-sm-3 control-label">Anggota Pengurus RT</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aprt" name="data[anggota][3][kemasyarakatan][aprt]" placeholder="Anggota Pengurus RT" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aprt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_prw" class="col-sm-3 control-label">Pengurus RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_prw" name="data[anggota][3][kemasyarakatan][prw]" placeholder="Pengurus RW" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["prw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aprw" class="col-sm-3 control-label">Anggota Pengurus RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aprw" name="data[anggota][3][kemasyarakatan][aprw]" placeholder="Anggota Pengurus RW" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aprw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_plkmdklpm" class="col-sm-3 control-label">Pengurus LKMD/K/LPM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_plkmdklpm" name="data[anggota][3][kemasyarakatan][plkmdklpm]" placeholder="Pengurus LKMD/K/LPM" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["plkmdklpm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_alkmdklpm" class="col-sm-3 control-label">Anggota LKMD/K/LPM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_alkmdklpm" name="data[anggota][3][kemasyarakatan][alkmdklpm]" placeholder="Anggota LKMD/K/LPM" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["alkmdklpm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_ppkk" class="col-sm-3 control-label">Pengurus PKK</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_ppkk" name="data[anggota][3][kemasyarakatan][ppkk]" placeholder="Pengurus PKK" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["ppkk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_apkk" class="col-sm-3 control-label">Anggota PKK</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_apkk" name="data[anggota][3][kemasyarakatan][apkk]" placeholder="Anggota PKK" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["apkk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pla" class="col-sm-3 control-label">Pengurus Lembaga Adat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pla" name="data[anggota][3][kemasyarakatan][pla]" placeholder="Pengurus Lembaga Adat" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pla"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pkt" class="col-sm-3 control-label">Pengurus Karang Taruna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pkt" name="data[anggota][3][kemasyarakatan][pkt]" placeholder="Pengurus Karang Taruna" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pkt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_akt" class="col-sm-3 control-label">Anggota Karang Taruna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_akt" name="data[anggota][3][kemasyarakatan][akt]" placeholder="Anggota Karang Taruna" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["akt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_phl" class="col-sm-3 control-label">Pengurus Hansip/Linmas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_phl" name="data[anggota][3][kemasyarakatan][phl]" placeholder="Pengurus Hansip/Linmas" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["phl"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pp" class="col-sm-3 control-label">Pengurus Poskamling</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pp" name="data[anggota][3][kemasyarakatan][pp]" placeholder="Pengurus Poskamling" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pop" class="col-sm-3 control-label">Pengurus Organisasi Perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pop" name="data[anggota][3][kemasyarakatan][pop]" placeholder="Pengurus Organisasi Perempuan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aop" class="col-sm-3 control-label">Anggota Organisasi Perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aop" name="data[anggota][3][kemasyarakatan][aop]" placeholder="Anggota Organisasi Perempuan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pob" class="col-sm-3 control-label">Pengurus Organisasi Bapak-bapak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pob" name="data[anggota][3][kemasyarakatan][pob]" placeholder="Pengurus Organisasi Bapak-bapak" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pob"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aob" class="col-sm-3 control-label">Anggota Organisasi Bapak-bapak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aob" name="data[anggota][3][kemasyarakatan][aob]" placeholder="Anggota Organisasi Bapak-bapak" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aob"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pok" class="col-sm-3 control-label">Pengurus Organisasi keagamaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pok" name="data[anggota][3][kemasyarakatan][pok]" placeholder="Pengurus Organisasi keagamaan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aok" class="col-sm-3 control-label">Anggota Organisasi keagamaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aok" name="data[anggota][3][kemasyarakatan][aok]" placeholder="Anggota Organisasi keagamaan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_popw" class="col-sm-3 control-label">Pengurus Organisasi profesi wartawan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_popw" name="data[anggota][3][kemasyarakatan][popw]" placeholder="Pengurus Organisasi profesi wartawan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["popw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aopw" class="col-sm-3 control-label">Anggota Organisasi profesi wartawan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aopw" name="data[anggota][3][kemasyarakatan][aopw]" placeholder="Anggota Organisasi profesi wartawan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aopw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pposyandu" class="col-sm-3 control-label">Pengurus Posyandu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pposyandu" name="data[anggota][3][kemasyarakatan][pposyandu]" placeholder="Pengurus Posyandu" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pposyandu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pposyantekdes" class="col-sm-3 control-label">Pengurus Posyantekdes</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pposyantekdes" name="data[anggota][3][kemasyarakatan][pposyantekdes]" placeholder="Pengurus Posyantekdes" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pposyantekdes"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_poktan" class="col-sm-3 control-label">Pengurus Organisasi Kelompok Tani/Nelayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_poktan" name="data[anggota][3][kemasyarakatan][poktan]" placeholder="Pengurus Organisasi Kelompok Tani/Nelayan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["poktan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aoktan" class="col-sm-3 control-label">Anggota Organisasi Kelompok Tani/Nelayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aoktan" name="data[anggota][3][kemasyarakatan][aoktan]" placeholder="Anggota Organisasi Kelompok Tani/Nelayan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aoktan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_plgr" class="col-sm-3 control-label">Pengurus Lembaga Gotong royong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_plgr" name="data[anggota][3][kemasyarakatan][plgr]" placeholder="Pengurus Lembaga Gotong royong" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["plgr"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_algr" class="col-sm-3 control-label">Anggota Lembaga Gotong royong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_algr" name="data[anggota][3][kemasyarakatan][algr]" placeholder="Anggota Lembaga Gotong royong" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["algr"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_popg" class="col-sm-3 control-label">Pengurus Organisasi Profesi guru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_popg" name="data[anggota][3][kemasyarakatan][popg]" placeholder="Pengurus Organisasi Profesi guru" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["popg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aopg" class="col-sm-3 control-label">Anggota Organisasi Profesi guru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aopg" name="data[anggota][3][kemasyarakatan][aopg]" placeholder="Anggota Organisasi Profesi guru" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aopg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_popdtm" class="col-sm-3 control-label">Pengurus Organisasi profesi dokter/tenaga medis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_popdtm" name="data[anggota][3][kemasyarakatan][popdtm]" placeholder="Pengurus Organisasi profesi dokter/tenaga medis" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["popdtm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aoptm" class="col-sm-3 control-label">Anggota Organisasi profesi/tenaga medis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aoptm" name="data[anggota][3][kemasyarakatan][aoptm]" placeholder="Anggota Organisasi profesi/tenaga medis" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aoptm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_popensiun" class="col-sm-3 control-label">Pengurus organisasi pensiunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_popensiun" name="data[anggota][3][kemasyarakatan][popensiun]" placeholder="Pengurus organisasi pensiunan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["popensiun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aopensiun" class="col-sm-3 control-label">Anggota organisasi pensiunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aopensiun" name="data[anggota][3][kemasyarakatan][aopensiun]" placeholder="Anggota organisasi pensiunan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aopensiun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_popp" class="col-sm-3 control-label">Pengurus organisasi pemirsa/pendengar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_popp" name="data[anggota][3][kemasyarakatan][popp]" placeholder="Pengurus organisasi pemirsa/pendengar" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["popp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aopp" class="col-sm-3 control-label">Anggota organisasi pemirsa/pendengar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aopp" name="data[anggota][3][kemasyarakatan][aopp]" placeholder="Anggota organisasi pemirsa/pendengar" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aopp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_plpa" class="col-sm-3 control-label">Pengurus lembaga pencinta alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_plpa" name="data[anggota][3][kemasyarakatan][plpa]" placeholder="Pengurus lembaga pencinta alam" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["plpa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_alpa" class="col-sm-3 control-label">Anggota organisasi pencinta alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_alpa" name="data[anggota][3][kemasyarakatan][alpa]" placeholder="Anggota organisasi pencinta alam" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["alpa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_popip" class="col-sm-3 control-label">Pengurus organisasi pengembangan ilmu pengetahuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_popip" name="data[anggota][3][kemasyarakatan][popip]" placeholder="Pengurus organisasi pengembangan ilmu pengetahuan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["popip"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_aopip" class="col-sm-3 control-label">Anggota organisasi pengembangan ilmu pengetaahuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_aopip" name="data[anggota][3][kemasyarakatan][aopip]" placeholder="Anggota organisasi pengembangan ilmu pengetaahuan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["aopip"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pemyaya" class="col-sm-3 control-label">Pemilik yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pemyaya" name="data[anggota][3][kemasyarakatan][pemyaya]" placeholder="Pemilik yayasan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pemyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_penyaya" class="col-sm-3 control-label">Pengurus yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_penyaya" name="data[anggota][3][kemasyarakatan][penyaya]" placeholder="Pengurus yayasan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["penyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_angyaya" class="col-sm-3 control-label">Anggota yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_angyaya" name="data[anggota][3][kemasyarakatan][angyaya]" placeholder="Anggota yayasan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["angyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pkebersihan" class="col-sm-3 control-label">Pengurus Satgas Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pkebersihan" name="data[anggota][3][kemasyarakatan][pkebersihan]" placeholder="Pengurus Satgas Kebersihan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pkebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_akebersihan" class="col-sm-3 control-label">Anggota Satgas Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_akebersihan" name="data[anggota][3][kemasyarakatan][akebersihan]" placeholder="Anggota Satgas Kebersihan" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["akebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_pkebakaran" class="col-sm-3 control-label">Pengurus Satgas Kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_pkebakaran" name="data[anggota][3][kemasyarakatan][pkebakaran]" placeholder="Pengurus Satgas Kebakaran" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["pkebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_akebakaran" class="col-sm-3 control-label">Anggota Satgas Kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_akebakaran" name="data[anggota][3][kemasyarakatan][akebakaran]" placeholder="Anggota Satgas Kebakaran" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["akebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_ppb" class="col-sm-3 control-label">Pengurus Posko Penanggulangan Bencana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_ppb" name="data[anggota][3][kemasyarakatan][ppb]" placeholder="Pengurus Posko Penanggulangan Bencana" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["ppb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_atpb" class="col-sm-3 control-label">Anggota Tim Penanggulangan Bencana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_atpb" name="data[anggota][3][kemasyarakatan][atpb]" placeholder="Anggota Tim Penanggulangan Bencana" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["atpb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_kemasyarakatan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_lainnya" name="data[anggota][3][kemasyarakatan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_kemasyarakatan_lainnya" name="data[anggota][3][kemasyarakatan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[3]["kemasyarakatan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Ekonomi Yang Dimiliki Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_koperasi" class="col-sm-3 control-label">Koperasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_koperasi" name="data[anggota][3][ekonomi][koperasi]" placeholder="Koperasi" value="<?php echo $ddk->anggota[3]["ekonomi"]["koperasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_unit_usaha_simpan_pinjam" class="col-sm-3 control-label">Unit Usaha Simpan Pinjam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_unit_usaha_simpan_pinjam" name="data[anggota][3][ekonomi][unit_usaha_simpan_pinjam]" placeholder="Unit Usaha Simpan Pinjam" value="<?php echo $ddk->anggota[3]["ekonomi"]["unit_usaha_simpan_pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_industri_kerajinan_tangan" class="col-sm-3 control-label">Industri Kerajinan Tangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_industri_kerajinan_tangan" name="data[anggota][3][ekonomi][industri_kerajinan_tangan]" placeholder="Industri Kerajinan Tangan" value="<?php echo $ddk->anggota[3]["ekonomi"]["industri_kerajinan_tangan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_industri_pakaian" class="col-sm-3 control-label">Industri Pakaian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_industri_pakaian" name="data[anggota][3][ekonomi][industri_pakaian]" placeholder="Industri Pakaian" value="<?php echo $ddk->anggota[3]["ekonomi"]["industri_pakaian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_industri_usaha_makanan" class="col-sm-3 control-label">Industri Usaha Makanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_industri_usaha_makanan" name="data[anggota][3][ekonomi][industri_usaha_makanan]" placeholder="Industri Usaha Makanan" value="<?php echo $ddk->anggota[3]["ekonomi"]["industri_usaha_makanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_industri_alat_rumah_tangga" class="col-sm-3 control-label">Industri Alat Rumah Tangga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_industri_alat_rumah_tangga" name="data[anggota][3][ekonomi][industri_alat_rumah_tangga]" placeholder="Industri Alat Rumah Tangga" value="<?php echo $ddk->anggota[3]["ekonomi"]["industri_alat_rumah_tangga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_industri_usaha_bahan_bangunan" class="col-sm-3 control-label">Industri Usaha Bahan Bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_industri_usaha_bahan_bangunan" name="data[anggota][3][ekonomi][industri_usaha_bahan_bangunan]" placeholder="Industri Usaha Bahan Bangunan" value="<?php echo $ddk->anggota[3]["ekonomi"]["industri_usaha_bahan_bangunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_industri_alat_pertanian" class="col-sm-3 control-label">Industri Alat Pertanian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_industri_alat_pertanian" name="data[anggota][3][ekonomi][industri_alat_pertanian]" placeholder="Industri Alat Pertanian" value="<?php echo $ddk->anggota[3]["ekonomi"]["industri_alat_pertanian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_restoran" class="col-sm-3 control-label">Restoran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_restoran" name="data[anggota][3][ekonomi][restoran]" placeholder="Restoran" value="<?php echo $ddk->anggota[3]["ekonomi"]["restoran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_toko__swalayan" class="col-sm-3 control-label">Toko/ Swalayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_toko__swalayan" name="data[anggota][3][ekonomi][toko__swalayan]" placeholder="Toko/ Swalayan" value="<?php echo $ddk->anggota[3]["ekonomi"]["toko__swalayan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_warung_kelontongan_kios" class="col-sm-3 control-label">Warung Kelontongan/Kios</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_warung_kelontongan_kios" name="data[anggota][3][ekonomi][warung_kelontongan_kios]" placeholder="Warung Kelontongan/Kios" value="<?php echo $ddk->anggota[3]["ekonomi"]["warung_kelontongan_kios"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_angkutan_darat" class="col-sm-3 control-label">Angkutan Darat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_angkutan_darat" name="data[anggota][3][ekonomi][angkutan_darat]" placeholder="Angkutan Darat" value="<?php echo $ddk->anggota[3]["ekonomi"]["angkutan_darat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_angkutan_sungai" class="col-sm-3 control-label">Angkutan Sungai</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_angkutan_sungai" name="data[anggota][3][ekonomi][angkutan_sungai]" placeholder="Angkutan Sungai" value="<?php echo $ddk->anggota[3]["ekonomi"]["angkutan_sungai"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_angkutan_laut" class="col-sm-3 control-label">Angkutan Laut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_angkutan_laut" name="data[anggota][3][ekonomi][angkutan_laut]" placeholder="Angkutan Laut" value="<?php echo $ddk->anggota[3]["ekonomi"]["angkutan_laut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_angkutan_udara" class="col-sm-3 control-label">Angkutan Udara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_angkutan_udara" name="data[anggota][3][ekonomi][angkutan_udara]" placeholder="Angkutan Udara" value="<?php echo $ddk->anggota[3]["ekonomi"]["angkutan_udara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_jasa_ekspedisi_pengiriman_barang" class="col-sm-3 control-label">Jasa Ekspedisi/Pengiriman Barang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_jasa_ekspedisi_pengiriman_barang" name="data[anggota][3][ekonomi][jasa_ekspedisi_pengiriman_barang]" placeholder="Jasa Ekspedisi/Pengiriman Barang" value="<?php echo $ddk->anggota[3]["ekonomi"]["jasa_ekspedisi_pengiriman_barang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_pasar_harian" class="col-sm-3 control-label">Usaha Pasar Harian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_pasar_harian" name="data[anggota][3][ekonomi][usaha_pasar_harian]" placeholder="Usaha Pasar Harian" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_pasar_harian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_pasar_mingguan" class="col-sm-3 control-label">Usaha Pasar Mingguan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_pasar_mingguan" name="data[anggota][3][ekonomi][usaha_pasar_mingguan]" placeholder="Usaha Pasar Mingguan" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_pasar_mingguan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_pasar_ternak" class="col-sm-3 control-label">Usaha Pasar Ternak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_pasar_ternak" name="data[anggota][3][ekonomi][usaha_pasar_ternak]" placeholder="Usaha Pasar Ternak" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_pasar_ternak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_pasar_hasil_bumi_dan_tambang" class="col-sm-3 control-label">Usaha Pasar Hasil Bumi Dan Tambang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_pasar_hasil_bumi_dan_tambang" name="data[anggota][3][ekonomi][usaha_pasar_hasil_bumi_dan_tambang]" placeholder="Usaha Pasar Hasil Bumi Dan Tambang" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_pasar_hasil_bumi_dan_tambang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_perdagangan_antar_pulau" class="col-sm-3 control-label">Usaha Perdagangan Antar Pulau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_perdagangan_antar_pulau" name="data[anggota][3][ekonomi][usaha_perdagangan_antar_pulau]" placeholder="Usaha Perdagangan Antar Pulau" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_perdagangan_antar_pulau"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_pengijon" class="col-sm-3 control-label">Pengijon</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_pengijon" name="data[anggota][3][ekonomi][pengijon]" placeholder="Pengijon" value="<?php echo $ddk->anggota[3]["ekonomi"]["pengijon"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_pedagang_pengumpul_tengkulak" class="col-sm-3 control-label">Pedagang Pengumpul/Tengkulak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_pedagang_pengumpul_tengkulak" name="data[anggota][3][ekonomi][pedagang_pengumpul_tengkulak]" placeholder="Pedagang Pengumpul/Tengkulak" value="<?php echo $ddk->anggota[3]["ekonomi"]["pedagang_pengumpul_tengkulak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_peternakan" class="col-sm-3 control-label">Usaha Peternakan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_peternakan" name="data[anggota][3][ekonomi][usaha_peternakan]" placeholder="Usaha Peternakan" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_peternakan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_perikanan" class="col-sm-3 control-label">Usaha Perikanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_perikanan" name="data[anggota][3][ekonomi][usaha_perikanan]" placeholder="Usaha Perikanan" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_perikanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_perkebunan" class="col-sm-3 control-label">Usaha Perkebunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_perkebunan" name="data[anggota][3][ekonomi][usaha_perkebunan]" placeholder="Usaha Perkebunan" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_perkebunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_kelompok_simpan_pinjam" class="col-sm-3 control-label">Kelompok Simpan Pinjam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_kelompok_simpan_pinjam" name="data[anggota][3][ekonomi][kelompok_simpan_pinjam]" placeholder="Kelompok Simpan Pinjam" value="<?php echo $ddk->anggota[3]["ekonomi"]["kelompok_simpan_pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_minuman" class="col-sm-3 control-label">Usaha Minuman</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_minuman" name="data[anggota][3][ekonomi][usaha_minuman]" placeholder="Usaha Minuman" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_minuman"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_industri_farmasi" class="col-sm-3 control-label">Industri Farmasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_industri_farmasi" name="data[anggota][3][ekonomi][industri_farmasi]" placeholder="Industri Farmasi" value="<?php echo $ddk->anggota[3]["ekonomi"]["industri_farmasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_industri_karoseri" class="col-sm-3 control-label">Industri Karoseri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_industri_karoseri" name="data[anggota][3][ekonomi][industri_karoseri]" placeholder="Industri Karoseri" value="<?php echo $ddk->anggota[3]["ekonomi"]["industri_karoseri"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_penitipan_kendaraan_bermotor" class="col-sm-3 control-label">Penitipan Kendaraan Bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_penitipan_kendaraan_bermotor" name="data[anggota][3][ekonomi][penitipan_kendaraan_bermotor]" placeholder="Penitipan Kendaraan Bermotor" value="<?php echo $ddk->anggota[3]["ekonomi"]["penitipan_kendaraan_bermotor"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_industri_perakitan_elektronik" class="col-sm-3 control-label">Industri Perakitan Elektronik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_industri_perakitan_elektronik" name="data[anggota][3][ekonomi][industri_perakitan_elektronik]" placeholder="Industri Perakitan Elektronik" value="<?php echo $ddk->anggota[3]["ekonomi"]["industri_perakitan_elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_pengolahan_kayu" class="col-sm-3 control-label">Pengolahan Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_pengolahan_kayu" name="data[anggota][3][ekonomi][pengolahan_kayu]" placeholder="Pengolahan Kayu" value="<?php echo $ddk->anggota[3]["ekonomi"]["pengolahan_kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_bioskop" class="col-sm-3 control-label">Bioskop</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_bioskop" name="data[anggota][3][ekonomi][bioskop]" placeholder="Bioskop" value="<?php echo $ddk->anggota[3]["ekonomi"]["bioskop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_film_keliling" class="col-sm-3 control-label">Film Keliling</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_film_keliling" name="data[anggota][3][ekonomi][film_keliling]" placeholder="Film Keliling" value="<?php echo $ddk->anggota[3]["ekonomi"]["film_keliling"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_sandiwara_drama" class="col-sm-3 control-label">Sandiwara/Drama</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_sandiwara_drama" name="data[anggota][3][ekonomi][sandiwara_drama]" placeholder="Sandiwara/Drama" value="<?php echo $ddk->anggota[3]["ekonomi"]["sandiwara_drama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_group_lawak" class="col-sm-3 control-label">Group Lawak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_group_lawak" name="data[anggota][3][ekonomi][group_lawak]" placeholder="Group Lawak" value="<?php echo $ddk->anggota[3]["ekonomi"]["group_lawak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_jaipongan" class="col-sm-3 control-label">Jaipongan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_jaipongan" name="data[anggota][3][ekonomi][jaipongan]" placeholder="Jaipongan" value="<?php echo $ddk->anggota[3]["ekonomi"]["jaipongan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_wayang_orang_golek" class="col-sm-3 control-label">Wayang Orang/Golek</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_wayang_orang_golek" name="data[anggota][3][ekonomi][wayang_orang_golek]" placeholder="Wayang Orang/Golek" value="<?php echo $ddk->anggota[3]["ekonomi"]["wayang_orang_golek"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_group_musik_band" class="col-sm-3 control-label">Group Musik/Band</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_group_musik_band" name="data[anggota][3][ekonomi][group_musik_band]" placeholder="Group Musik/Band" value="<?php echo $ddk->anggota[3]["ekonomi"]["group_musik_band"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_group_vokal_paduan_suara" class="col-sm-3 control-label">Group Vokal/Paduan Suara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_group_vokal_paduan_suara" name="data[anggota][3][ekonomi][group_vokal_paduan_suara]" placeholder="Group Vokal/Paduan Suara" value="<?php echo $ddk->anggota[3]["ekonomi"]["group_vokal_paduan_suara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_persewaan_tenaga_listrik" class="col-sm-3 control-label">Usaha Persewaan Tenaga Listrik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_persewaan_tenaga_listrik" name="data[anggota][3][ekonomi][usaha_persewaan_tenaga_listrik]" placeholder="Usaha Persewaan Tenaga Listrik" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_persewaan_tenaga_listrik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_pengecer_gas_dan_bahan_bakar_minyak" class="col-sm-3 control-label">Usaha Pengecer Gas Dan Bahan Bakar Minyak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_pengecer_gas_dan_bahan_bakar_minyak" name="data[anggota][3][ekonomi][usaha_pengecer_gas_dan_bahan_bakar_minyak]" placeholder="Usaha Pengecer Gas Dan Bahan Bakar Minyak" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_pengecer_gas_dan_bahan_bakar_minyak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_air_minum_dalam_kemasan" class="col-sm-3 control-label">Usaha Air Minum Dalam Kemasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_air_minum_dalam_kemasan" name="data[anggota][3][ekonomi][usaha_air_minum_dalam_kemasan]" placeholder="Usaha Air Minum Dalam Kemasan" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_air_minum_dalam_kemasan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_tukang_kayu" class="col-sm-3 control-label">Tukang Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_tukang_kayu" name="data[anggota][3][ekonomi][tukang_kayu]" placeholder="Tukang Kayu" value="<?php echo $ddk->anggota[3]["ekonomi"]["tukang_kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_tukang_batu" class="col-sm-3 control-label">Tukang Batu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_tukang_batu" name="data[anggota][3][ekonomi][tukang_batu]" placeholder="Tukang Batu" value="<?php echo $ddk->anggota[3]["ekonomi"]["tukang_batu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_tukang_jahit_bordir" class="col-sm-3 control-label">Tukang Jahit/Bordir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_tukang_jahit_bordir" name="data[anggota][3][ekonomi][tukang_jahit_bordir]" placeholder="Tukang Jahit/Bordir" value="<?php echo $ddk->anggota[3]["ekonomi"]["tukang_jahit_bordir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_tukang_cukur" class="col-sm-3 control-label">Tukang Cukur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_tukang_cukur" name="data[anggota][3][ekonomi][tukang_cukur]" placeholder="Tukang Cukur" value="<?php echo $ddk->anggota[3]["ekonomi"]["tukang_cukur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_tukang_service_elektronik" class="col-sm-3 control-label">Tukang Service Elektronik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_tukang_service_elektronik" name="data[anggota][3][ekonomi][tukang_service_elektronik]" placeholder="Tukang Service Elektronik" value="<?php echo $ddk->anggota[3]["ekonomi"]["tukang_service_elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_tukang_besi" class="col-sm-3 control-label">Tukang Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_tukang_besi" name="data[anggota][3][ekonomi][tukang_besi]" placeholder="Tukang Besi" value="<?php echo $ddk->anggota[3]["ekonomi"]["tukang_besi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_tukang_pijat_urut" class="col-sm-3 control-label">Tukang Pijat/Urut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_tukang_pijat_urut" name="data[anggota][3][ekonomi][tukang_pijat_urut]" placeholder="Tukang Pijat/Urut" value="<?php echo $ddk->anggota[3]["ekonomi"]["tukang_pijat_urut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_tukang_sumur" class="col-sm-3 control-label">Tukang Sumur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_tukang_sumur" name="data[anggota][3][ekonomi][tukang_sumur]" placeholder="Tukang Sumur" value="<?php echo $ddk->anggota[3]["ekonomi"]["tukang_sumur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_notaris" class="col-sm-3 control-label">Notaris</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_notaris" name="data[anggota][3][ekonomi][notaris]" placeholder="Notaris" value="<?php echo $ddk->anggota[3]["ekonomi"]["notaris"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_pengacara_advokat" class="col-sm-3 control-label">Pengacara/Advokat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_pengacara_advokat" name="data[anggota][3][ekonomi][pengacara_advokat]" placeholder="Pengacara/Advokat" value="<?php echo $ddk->anggota[3]["ekonomi"]["pengacara_advokat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_konsultan_manajemen" class="col-sm-3 control-label">Konsultan Manajemen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_konsultan_manajemen" name="data[anggota][3][ekonomi][konsultan_manajemen]" placeholder="Konsultan Manajemen" value="<?php echo $ddk->anggota[3]["ekonomi"]["konsultan_manajemen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_konsultan_teknis" class="col-sm-3 control-label">Konsultan Teknis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_konsultan_teknis" name="data[anggota][3][ekonomi][konsultan_teknis]" placeholder="Konsultan Teknis" value="<?php echo $ddk->anggota[3]["ekonomi"]["konsultan_teknis"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_pejabat_pembuat_akta_tanah" class="col-sm-3 control-label">Pejabat Pembuat Akta Tanah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_pejabat_pembuat_akta_tanah" name="data[anggota][3][ekonomi][pejabat_pembuat_akta_tanah]" placeholder="Pejabat Pembuat Akta Tanah" value="<?php echo $ddk->anggota[3]["ekonomi"]["pejabat_pembuat_akta_tanah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_losmen" class="col-sm-3 control-label">Losmen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_losmen" name="data[anggota][3][ekonomi][losmen]" placeholder="Losmen" value="<?php echo $ddk->anggota[3]["ekonomi"]["losmen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_wisma" class="col-sm-3 control-label">Wisma</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_wisma" name="data[anggota][3][ekonomi][wisma]" placeholder="Wisma" value="<?php echo $ddk->anggota[3]["ekonomi"]["wisma"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_asrama" class="col-sm-3 control-label">Asrama</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_asrama" name="data[anggota][3][ekonomi][asrama]" placeholder="Asrama" value="<?php echo $ddk->anggota[3]["ekonomi"]["asrama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_persewaan_kamar" class="col-sm-3 control-label">Persewaan Kamar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_persewaan_kamar" name="data[anggota][3][ekonomi][persewaan_kamar]" placeholder="Persewaan Kamar" value="<?php echo $ddk->anggota[3]["ekonomi"]["persewaan_kamar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_kontrakan_rumah" class="col-sm-3 control-label">Kontrakan Rumah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_kontrakan_rumah" name="data[anggota][3][ekonomi][kontrakan_rumah]" placeholder="Kontrakan Rumah" value="<?php echo $ddk->anggota[3]["ekonomi"]["kontrakan_rumah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_mess" class="col-sm-3 control-label">Mess</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_mess" name="data[anggota][3][ekonomi][mess]" placeholder="Mess" value="<?php echo $ddk->anggota[3]["ekonomi"]["mess"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_hotel" class="col-sm-3 control-label">Hotel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_hotel" name="data[anggota][3][ekonomi][hotel]" placeholder="Hotel" value="<?php echo $ddk->anggota[3]["ekonomi"]["hotel"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_home_stay" class="col-sm-3 control-label">Home Stay</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_home_stay" name="data[anggota][3][ekonomi][home_stay]" placeholder="Home Stay" value="<?php echo $ddk->anggota[3]["ekonomi"]["home_stay"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_villa" class="col-sm-3 control-label">Villa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_villa" name="data[anggota][3][ekonomi][villa]" placeholder="Villa" value="<?php echo $ddk->anggota[3]["ekonomi"]["villa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_town_house" class="col-sm-3 control-label">Town House</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_town_house" name="data[anggota][3][ekonomi][town_house]" placeholder="Town House" value="<?php echo $ddk->anggota[3]["ekonomi"]["town_house"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_asuransi" class="col-sm-3 control-label">Usaha Asuransi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_asuransi" name="data[anggota][3][ekonomi][usaha_asuransi]" placeholder="Usaha Asuransi" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_asuransi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_lembaga_keuangan_bukan_bank" class="col-sm-3 control-label">Lembaga Keuangan Bukan Bank</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_lembaga_keuangan_bukan_bank" name="data[anggota][3][ekonomi][lembaga_keuangan_bukan_bank]" placeholder="Lembaga Keuangan Bukan Bank" value="<?php echo $ddk->anggota[3]["ekonomi"]["lembaga_keuangan_bukan_bank"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_lembaga_perkreditan_rakyat" class="col-sm-3 control-label">Lembaga Perkreditan Rakyat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_lembaga_perkreditan_rakyat" name="data[anggota][3][ekonomi][lembaga_perkreditan_rakyat]" placeholder="Lembaga Perkreditan Rakyat" value="<?php echo $ddk->anggota[3]["ekonomi"]["lembaga_perkreditan_rakyat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_pegadaian" class="col-sm-3 control-label">Pegadaian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_pegadaian" name="data[anggota][3][ekonomi][pegadaian]" placeholder="Pegadaian" value="<?php echo $ddk->anggota[3]["ekonomi"]["pegadaian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_bank_perkreditan_rakyat" class="col-sm-3 control-label">Bank Perkreditan Rakyat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_bank_perkreditan_rakyat" name="data[anggota][3][ekonomi][bank_perkreditan_rakyat]" placeholder="Bank Perkreditan Rakyat" value="<?php echo $ddk->anggota[3]["ekonomi"]["bank_perkreditan_rakyat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_penyewaan_alat_pesta" class="col-sm-3 control-label">Usaha Penyewaan Alat Pesta</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_penyewaan_alat_pesta" name="data[anggota][3][ekonomi][usaha_penyewaan_alat_pesta]" placeholder="Usaha Penyewaan Alat Pesta" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_penyewaan_alat_pesta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_usaha_pengolahan_dan_penjualan_hasil_hutan" class="col-sm-3 control-label">Usaha Pengolahan dan Penjualan Hasil Hutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_usaha_pengolahan_dan_penjualan_hasil_hutan" name="data[anggota][3][ekonomi][usaha_pengolahan_dan_penjualan_hasil_hutan]" placeholder="Usaha Pengolahan dan Penjualan Hasil Hutan" value="<?php echo $ddk->anggota[3]["ekonomi"]["usaha_pengolahan_dan_penjualan_hasil_hutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_ekonomi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_ekonomi_lainnya" name="data[anggota][3][ekonomi][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[3]["ekonomi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_ekonomi_lainnya" name="data[anggota][3][ekonomi][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[3]["ekonomi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Produksi bahan galian yang dimiliki anggota keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_batu_kali" class="col-sm-3 control-label">Batu kali</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_batu_kali" name="data[anggota][3][galian][batu_kali][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["batu_kali"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_kali" name="data[anggota][3][galian][batu_kali][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["batu_kali"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_kali" name="data[anggota][3][galian][batu_kali][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["batu_kali"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_kali" name="data[anggota][3][galian][batu_kali][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["batu_kali"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_batu_kapur" class="col-sm-3 control-label">Batu kapur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_batu_kapur" name="data[anggota][3][galian][batu_kapur][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["batu_kapur"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_kapur" name="data[anggota][3][galian][batu_kapur][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["batu_kapur"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_kapur" name="data[anggota][3][galian][batu_kapur][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["batu_kapur"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_kapur" name="data[anggota][3][galian][batu_kapur][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["batu_kapur"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_pasir" class="col-sm-3 control-label">Pasir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_pasir" name="data[anggota][3][galian][pasir][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["pasir"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir" name="data[anggota][3][galian][pasir][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["pasir"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir" name="data[anggota][3][galian][pasir][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["pasir"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir" name="data[anggota][3][galian][pasir][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["pasir"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_emas" class="col-sm-3 control-label">Emas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_emas" name="data[anggota][3][galian][emas][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["emas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_emas" name="data[anggota][3][galian][emas][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["emas"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_emas" name="data[anggota][3][galian][emas][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["emas"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_emas" name="data[anggota][3][galian][emas][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["emas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_kuningan" class="col-sm-3 control-label">Kuningan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_kuningan" name="data[anggota][3][galian][kuningan][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["kuningan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_kuningan" name="data[anggota][3][galian][kuningan][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["kuningan"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_kuningan" name="data[anggota][3][galian][kuningan][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["kuningan"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_kuningan" name="data[anggota][3][galian][kuningan][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["kuningan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_aluminium" class="col-sm-3 control-label">Aluminium</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_aluminium" name="data[anggota][3][galian][aluminium][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["aluminium"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_aluminium" name="data[anggota][3][galian][aluminium][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["aluminium"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_aluminium" name="data[anggota][3][galian][aluminium][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["aluminium"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_aluminium" name="data[anggota][3][galian][aluminium][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["aluminium"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_perunggu" class="col-sm-3 control-label">Perunggu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_perunggu" name="data[anggota][3][galian][perunggu][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["perunggu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_perunggu" name="data[anggota][3][galian][perunggu][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["perunggu"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_perunggu" name="data[anggota][3][galian][perunggu][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["perunggu"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_perunggu" name="data[anggota][3][galian][perunggu][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["perunggu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_belerang" class="col-sm-3 control-label">Belerang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_belerang" name="data[anggota][3][galian][belerang][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["belerang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_belerang" name="data[anggota][3][galian][belerang][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["belerang"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_belerang" name="data[anggota][3][galian][belerang][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["belerang"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_belerang" name="data[anggota][3][galian][belerang][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["belerang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_batu_marmer" class="col-sm-3 control-label">Batu marmer</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_batu_marmer" name="data[anggota][3][galian][batu_marmer][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["batu_marmer"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_marmer" name="data[anggota][3][galian][batu_marmer][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["batu_marmer"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_marmer" name="data[anggota][3][galian][batu_marmer][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["batu_marmer"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_marmer" name="data[anggota][3][galian][batu_marmer][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["batu_marmer"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_batu_cadas" class="col-sm-3 control-label">Batu cadas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_batu_cadas" name="data[anggota][3][galian][batu_cadas][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["batu_cadas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_cadas" name="data[anggota][3][galian][batu_cadas][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["batu_cadas"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_cadas" name="data[anggota][3][galian][batu_cadas][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["batu_cadas"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_cadas" name="data[anggota][3][galian][batu_cadas][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["batu_cadas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_batu_apung" class="col-sm-3 control-label">Batu apung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_batu_apung" name="data[anggota][3][galian][batu_apung][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["batu_apung"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_apung" name="data[anggota][3][galian][batu_apung][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["batu_apung"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_apung" name="data[anggota][3][galian][batu_apung][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["batu_apung"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_apung" name="data[anggota][3][galian][batu_apung][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["batu_apung"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_pasir_kwarsa" class="col-sm-3 control-label">Pasir kwarsa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_pasir_kwarsa" name="data[anggota][3][galian][pasir_kwarsa][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["pasir_kwarsa"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir_kwarsa" name="data[anggota][3][galian][pasir_kwarsa][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["pasir_kwarsa"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir_kwarsa" name="data[anggota][3][galian][pasir_kwarsa][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["pasir_kwarsa"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir_kwarsa" name="data[anggota][3][galian][pasir_kwarsa][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["pasir_kwarsa"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_batubara" class="col-sm-3 control-label">Batubara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_batubara" name="data[anggota][3][galian][batubara][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["batubara"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batubara" name="data[anggota][3][galian][batubara][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["batubara"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batubara" name="data[anggota][3][galian][batubara][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["batubara"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batubara" name="data[anggota][3][galian][batubara][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["batubara"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_batu_granit" class="col-sm-3 control-label">Batu Granit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_batu_granit" name="data[anggota][3][galian][batu_granit][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["batu_granit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_granit" name="data[anggota][3][galian][batu_granit][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["batu_granit"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_granit" name="data[anggota][3][galian][batu_granit][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["batu_granit"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_granit" name="data[anggota][3][galian][batu_granit][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["batu_granit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_batu_gamping" class="col-sm-3 control-label">Batu Gamping</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_batu_gamping" name="data[anggota][3][galian][batu_gamping][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["batu_gamping"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_gamping" name="data[anggota][3][galian][batu_gamping][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["batu_gamping"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_gamping" name="data[anggota][3][galian][batu_gamping][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["batu_gamping"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_gamping" name="data[anggota][3][galian][batu_gamping][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["batu_gamping"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_mangan" class="col-sm-3 control-label">Mangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_mangan" name="data[anggota][3][galian][mangan][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["mangan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_mangan" name="data[anggota][3][galian][mangan][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["mangan"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_mangan" name="data[anggota][3][galian][mangan][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["mangan"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_mangan" name="data[anggota][3][galian][mangan][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["mangan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_batu_trass" class="col-sm-3 control-label">Batu Trass</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_batu_trass" name="data[anggota][3][galian][batu_trass][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["batu_trass"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_trass" name="data[anggota][3][galian][batu_trass][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["batu_trass"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_trass" name="data[anggota][3][galian][batu_trass][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["batu_trass"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_trass" name="data[anggota][3][galian][batu_trass][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["batu_trass"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_batu_putih" class="col-sm-3 control-label">Batu Putih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_batu_putih" name="data[anggota][3][galian][batu_putih][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["batu_putih"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_putih" name="data[anggota][3][galian][batu_putih][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["batu_putih"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_putih" name="data[anggota][3][galian][batu_putih][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["batu_putih"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_batu_putih" name="data[anggota][3][galian][batu_putih][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["batu_putih"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_pasir_batu" class="col-sm-3 control-label">Pasir Batu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_pasir_batu" name="data[anggota][3][galian][pasir_batu][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["pasir_batu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir_batu" name="data[anggota][3][galian][pasir_batu][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["pasir_batu"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir_batu" name="data[anggota][3][galian][pasir_batu][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["pasir_batu"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir_batu" name="data[anggota][3][galian][pasir_batu][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["pasir_batu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_pasir_besi" class="col-sm-3 control-label">Pasir Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_pasir_besi" name="data[anggota][3][galian][pasir_besi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["pasir_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir_besi" name="data[anggota][3][galian][pasir_besi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["pasir_besi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir_besi" name="data[anggota][3][galian][pasir_besi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["pasir_besi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_pasir_besi" name="data[anggota][3][galian][pasir_besi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["pasir_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_gips" class="col-sm-3 control-label">Gips</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_gips" name="data[anggota][3][galian][gips][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["gips"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_gips" name="data[anggota][3][galian][gips][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["gips"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_gips" name="data[anggota][3][galian][gips][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["gips"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_gips" name="data[anggota][3][galian][gips][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["gips"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_minyak_bumi" class="col-sm-3 control-label">Minyak Bumi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_minyak_bumi" name="data[anggota][3][galian][minyak_bumi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["minyak_bumi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_minyak_bumi" name="data[anggota][3][galian][minyak_bumi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["minyak_bumi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_minyak_bumi" name="data[anggota][3][galian][minyak_bumi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["minyak_bumi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_minyak_bumi" name="data[anggota][3][galian][minyak_bumi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["minyak_bumi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_gas_alam" class="col-sm-3 control-label">Gas Alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_gas_alam" name="data[anggota][3][galian][gas_alam][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["gas_alam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_gas_alam" name="data[anggota][3][galian][gas_alam][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["gas_alam"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_gas_alam" name="data[anggota][3][galian][gas_alam][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["gas_alam"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_gas_alam" name="data[anggota][3][galian][gas_alam][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["gas_alam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_perak" class="col-sm-3 control-label">Perak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_perak" name="data[anggota][3][galian][perak][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["perak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_perak" name="data[anggota][3][galian][perak][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["perak"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_perak" name="data[anggota][3][galian][perak][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["perak"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_perak" name="data[anggota][3][galian][perak][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["perak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_timah" class="col-sm-3 control-label">Timah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_timah" name="data[anggota][3][galian][timah][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["timah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_timah" name="data[anggota][3][galian][timah][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["timah"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_timah" name="data[anggota][3][galian][timah][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["timah"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_timah" name="data[anggota][3][galian][timah][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["timah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_tembaga" class="col-sm-3 control-label">Tembaga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_tembaga" name="data[anggota][3][galian][tembaga][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["tembaga"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_tembaga" name="data[anggota][3][galian][tembaga][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["tembaga"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_tembaga" name="data[anggota][3][galian][tembaga][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["tembaga"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_tembaga" name="data[anggota][3][galian][tembaga][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["tembaga"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_biji_besi" class="col-sm-3 control-label">Biji Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_biji_besi" name="data[anggota][3][galian][biji_besi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["biji_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_biji_besi" name="data[anggota][3][galian][biji_besi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["biji_besi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_biji_besi" name="data[anggota][3][galian][biji_besi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["biji_besi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_biji_besi" name="data[anggota][3][galian][biji_besi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["biji_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_uranium" class="col-sm-3 control-label">Uranium</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_uranium" name="data[anggota][3][galian][uranium][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["uranium"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_uranium" name="data[anggota][3][galian][uranium][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["uranium"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_uranium" name="data[anggota][3][galian][uranium][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["uranium"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_uranium" name="data[anggota][3][galian][uranium][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["uranium"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_bouxit" class="col-sm-3 control-label">Bouxit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_bouxit" name="data[anggota][3][galian][bouxit][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["bouxit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_bouxit" name="data[anggota][3][galian][bouxit][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["bouxit"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_bouxit" name="data[anggota][3][galian][bouxit][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["bouxit"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_bouxit" name="data[anggota][3][galian][bouxit][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["bouxit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_garam" class="col-sm-3 control-label">Garam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_garam" name="data[anggota][3][galian][garam][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["garam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_garam" name="data[anggota][3][galian][garam][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["garam"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_garam" name="data[anggota][3][galian][garam][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["garam"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_garam" name="data[anggota][3][galian][garam][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["garam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_nikel" class="col-sm-3 control-label">Nikel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_nikel" name="data[anggota][3][galian][nikel][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["nikel"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_nikel" name="data[anggota][3][galian][nikel][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["nikel"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_nikel" name="data[anggota][3][galian][nikel][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["nikel"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_nikel" name="data[anggota][3][galian][nikel][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["nikel"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota4_galian_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota4_galian_lainnya" name="data[anggota][3][galian][lainnya][keterangan]" placeholder="Keterangan" value="<?php echo $ddk->anggota[3]["galian"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_lainnya" name="data[anggota][3][galian][lainnya][opsi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[3]["galian"]["lainnya"]["opsi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_lainnya" name="data[anggota][3][galian][lainnya][opsi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[3]["galian"]["lainnya"]["opsi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_lainnya" name="data[anggota][3][galian][lainnya][opsi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[3]["galian"]["lainnya"]["opsi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota4_galian_lainnya" name="data[anggota][3][galian][lainnya][opsi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[3]["galian"]["lainnya"]["opsi"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Data Anggota Keluarga 5</strong></h4>
				<h4>Biodata</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_no_urut" class="col-sm-3 control-label">Nomor Urut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_no_urut" name="data[anggota][4][no_urut]" placeholder="Nomor Urut" value="<?php echo $ddk->anggota[4]["no_urut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_nik" class="col-sm-3 control-label">Nomor Induk Kependudukan (NIK)</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_nik" name="data[anggota][4][nik]" placeholder="Nomor Induk Kependudukan (NIK)" value="<?php echo $ddk->anggota[4]["nik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_nama" class="col-sm-3 control-label">Nama Lengkap</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_nama" name="data[anggota][4][nama]" placeholder="Nama Lengkap" value="<?php echo $ddk->anggota[4]["nama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_no_akte" class="col-sm-3 control-label">Nomor Akte Kelahiran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_no_akte" name="data[anggota][4][no_akte]" placeholder="Nomor Akte Kelahiran" value="<?php echo $ddk->anggota[4]["no_akte"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_jenis_kelamin" class="col-sm-3 control-label">Jenis Kelamin</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][4][jenis_kelamin]" id="anggota5_jenis_kelamin">
					<option value="laki" <?php echo $ddk->anggota[4]["jenis_kelamin"] == "laki" ? "selected" : ""; ?>>Laki-laki</option>
					<option value="perempuan" <?php echo $ddk->anggota[4]["jenis_kelamin"] == "perempuan" ? "selected" : ""; ?>>Perempuan</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_hubungan" class="col-sm-3 control-label">Hubungan dengan Kepala Keluarga</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][4][hubungan]" id="anggota5_hubungan">
					<option value="istri" <?php echo $ddk->anggota[4]["hubungan"] == "istri" ? "selected" : ""; ?>>Istri</option>
					<option value="suami" <?php echo $ddk->anggota[4]["hubungan"] == "suami" ? "selected" : ""; ?>>Suami</option>
					<option value="anak" <?php echo $ddk->anggota[4]["hubungan"] == "anak" ? "selected" : ""; ?>>Anak</option>
					<option value="cucu" <?php echo $ddk->anggota[4]["hubungan"] == "cucu" ? "selected" : ""; ?>>Cucu</option>
					<option value="mertua" <?php echo $ddk->anggota[4]["hubungan"] == "mertua" ? "selected" : ""; ?>>Mertua</option>
					<option value="menantu" <?php echo $ddk->anggota[4]["hubungan"] == "menantu" ? "selected" : ""; ?>>Menantu</option>
					<option value="keponakan" <?php echo $ddk->anggota[4]["hubungan"] == "keponakan" ? "selected" : ""; ?>>Keponakan</option>
					<option value="lainnya" <?php echo $ddk->anggota[4]["hubungan"] == "lainnya" ? "selected" : ""; ?>>Lainnya</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_tempat_lahir" class="col-sm-3 control-label">Tempat Lahir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_tempat_lahir" name="data[anggota][4][tempat_lahir]" placeholder="Tempat Lahir" value="<?php echo $ddk->anggota[4]["tempat_lahir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_tanggal_lahir" class="col-sm-3 control-label">Tanggal Lahir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="anggota5_tanggal_lahir" name="data[anggota][4][tanggal_lahir]" placeholder="Tanggal Lahir">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_tanggal_pencatatan" class="col-sm-3 control-label">Tanggal Pencatatan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="anggota5_tanggal_pencatatan" name="data[anggota][4][tanggal_pencatatan]" placeholder="Tanggal Pencatatan">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_status_kawin" class="col-sm-3 control-label">Status Perkawinan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][4][status_kawin]" id="anggota5_status_kawin">
					<option value="kawin" <?php echo $ddk->anggota[4]["status_kawin"] == "kawin" ? "selected" : ""; ?>>Kawin</option>
					<option value="belum" <?php echo $ddk->anggota[4]["status_kawin"] == "belum" ? "selected" : ""; ?>>Belum Kawin</option>
					<option value="pernah" <?php echo $ddk->anggota[4]["status_kawin"] == "pernah" ? "selected" : ""; ?>>Pernah Kawin</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_agama" class="col-sm-3 control-label">Agama dan Aliran Kepercayaan</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][4][agama]" id="anggota5_agama">
					<option value="islam" <?php echo $ddk->anggota[4]["agama"] == "islam" ? "selected" : ""; ?>>Islam</option>
					<option value="protestan" <?php echo $ddk->anggota[4]["agama"] == "protestan" ? "selected" : ""; ?>>Protestan</option>
					<option value="katolik" <?php echo $ddk->anggota[4]["agama"] == "katolik" ? "selected" : ""; ?>>Katolik</option>
					<option value="hindu" <?php echo $ddk->anggota[4]["agama"] == "hindu" ? "selected" : ""; ?>>Hindu</option>
					<option value="budha" <?php echo $ddk->anggota[4]["agama"] == "budha" ? "selected" : ""; ?>>Budha</option>
					<option value="kong hu chu" <?php echo $ddk->anggota[4]["agama"] == "kong hu chu" ? "selected" : ""; ?>>Kong Hu Chu</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_darah" class="col-sm-3 control-label">Golongan Darah</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][4][darah]" id="anggota5_darah">
					<option value="O" <?php echo $ddk->anggota[4]["darah"] == "O" ? "selected" : ""; ?>>O</option>
					<option value="A" <?php echo $ddk->anggota[4]["darah"] == "A" ? "selected" : ""; ?>>A</option>
					<option value="B" <?php echo $ddk->anggota[4]["darah"] == "B" ? "selected" : ""; ?>>B</option>
					<option value="AB" <?php echo $ddk->anggota[4]["darah"] == "AB" ? "selected" : ""; ?>>AB</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kewarganegaraan" class="col-sm-3 control-label">Kewarganegaraan/Etnis/Suku</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kewarganegaraan" name="data[anggota][4][kewarganegaraan]" placeholder="Kewarganegaraan/Etnis/Suku" value="<?php echo $ddk->anggota[4]["kewarganegaraan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pendidikan" class="col-sm-3 control-label">Pendidikan Umum Terakhir</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][4][pendidikan]" id="anggota5_pendidikan">
					<option value="SD" <?php echo $ddk->anggota[4]["pendidikan"] == "SD" ? "selected" : ""; ?>>SD</option>
					<option value="SMP" <?php echo $ddk->anggota[4]["pendidikan"] == "SMP" ? "selected" : ""; ?>>SMP</option>
					<option value="SMA" <?php echo $ddk->anggota[4]["pendidikan"] == "SMA" ? "selected" : ""; ?>>SMA</option>
					<option value="Diploma" <?php echo $ddk->anggota[4]["pendidikan"] == "Diploma" ? "selected" : ""; ?>>Diploma</option>
					<option value="S1" <?php echo $ddk->anggota[4]["pendidikan"] == "S1" ? "selected" : ""; ?>>S1</option>
					<option value="S2" <?php echo $ddk->anggota[4]["pendidikan"] == "S2" ? "selected" : ""; ?>>S2</option>
					<option value="S3" <?php echo $ddk->anggota[4]["pendidikan"] == "S3" ? "selected" : ""; ?>>S3</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pekerjaan" class="col-sm-3 control-label">Mata Pencaharian Pokok/Pekerjaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pekerjaan" name="data[anggota][4][pekerjaan]" placeholder="Mata Pencaharian Pokok/Pekerjaan" value="<?php echo $ddk->anggota[4]["pekerjaan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_nama_ortu" class="col-sm-3 control-label">Nama Bapak / Ibu Kandung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_nama_ortu" name="data[anggota][4][nama_ortu]" placeholder="Nama Bapak / Ibu Kandung" value="<?php echo $ddk->anggota[4]["nama_ortu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kb" class="col-sm-3 control-label">Akseptor KB</label>
			<div class="col-sm-5">
				<select class="form-control" name="data[anggota][4][kb]" id="anggota5_kb">
					<option value="Pil" <?php echo $ddk->anggota[4]["kb"] == "Pil" ? "selected" : ""; ?>>Pil</option>
					<option value="Spiral" <?php echo $ddk->anggota[4]["kb"] == "Spiral" ? "selected" : ""; ?>>Spiral</option>
					<option value="Suntik" <?php echo $ddk->anggota[4]["kb"] == "Suntik" ? "selected" : ""; ?>>Suntik</option>
					<option value="Susuk" <?php echo $ddk->anggota[4]["kb"] == "Susuk" ? "selected" : ""; ?>>Susuk</option>
					<option value="Kondom" <?php echo $ddk->anggota[4]["kb"] == "Kondom" ? "selected" : ""; ?>>Kondom</option>
					<option value="Vaksetomi" <?php echo $ddk->anggota[4]["kb"] == "Vaksetomi" ? "selected" : ""; ?>>Vaksetomi</option>
					<option value="Tubektomi" <?php echo $ddk->anggota[4]["kb"] == "Tubektomi" ? "selected" : ""; ?>>Tubektomi</option>
				</select>
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Cacat Menurut Jenis</strong></h4>
				<h4>Cacat Fisik</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_cacat_fisik_tuli" class="col-sm-3 control-label">Tuna rungu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_cacat_fisik_tuli" name="data[anggota][4][cacat_fisik][tuli]" placeholder="Tuna rungu" value="<?php echo $ddk->anggota[4]["cacat_fisik"]["tuli"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_cacat_fisik_bisu" class="col-sm-3 control-label">Tuna wicara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_cacat_fisik_bisu" name="data[anggota][4][cacat_fisik][bisu]" placeholder="Tuna wicara" value="<?php echo $ddk->anggota[4]["cacat_fisik"]["bisu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_cacat_fisik_buta" class="col-sm-3 control-label">Tuna netra</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_cacat_fisik_buta" name="data[anggota][4][cacat_fisik][buta]" placeholder="Tuna netra" value="<?php echo $ddk->anggota[4]["cacat_fisik"]["buta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_cacat_fisik_lumpuh" class="col-sm-3 control-label">Lumpuh</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_cacat_fisik_lumpuh" name="data[anggota][4][cacat_fisik][lumpuh]" placeholder="Lumpuh" value="<?php echo $ddk->anggota[4]["cacat_fisik"]["lumpuh"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_cacat_fisik_sumbing" class="col-sm-3 control-label">Sumbing</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_cacat_fisik_sumbing" name="data[anggota][4][cacat_fisik][sumbing]" placeholder="Sumbing" value="<?php echo $ddk->anggota[4]["cacat_fisik"]["sumbing"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_cacat_fisik_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_cacat_fisik_lainnya" name="data[anggota][4][cacat_fisik][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[4]["cacat_fisik"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_cacat_fisik_lainnya" name="data[anggota][4][cacat_fisik][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[4]["cacat_fisik"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4>Cacat Mental</h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_cacat_mental_idiot" class="col-sm-3 control-label">Idiot</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_cacat_mental_idiot" name="data[anggota][4][cacat_mental][idiot]" placeholder="Idiot" value="<?php echo $ddk->anggota[4]["cacat_mental"]["idiot"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_cacat_mental_gila" class="col-sm-3 control-label">Gila</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_cacat_mental_gila" name="data[anggota][4][cacat_mental][gila]" placeholder="Gila" value="<?php echo $ddk->anggota[4]["cacat_mental"]["gila"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_cacat_mental_stress" class="col-sm-3 control-label">Stress</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_cacat_mental_stress" name="data[anggota][4][cacat_mental][stress]" placeholder="Stress" value="<?php echo $ddk->anggota[4]["cacat_mental"]["stress"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_cacat_mental_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_cacat_mental_lainnya" name="data[anggota][4][cacat_mental][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[4]["cacat_mental"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_cacat_mental_lainnya" name="data[anggota][4][cacat_mental][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[4]["cacat_mental"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Kedudukan Anggota Keluarga sebagai Wajib Pajak dan Retribusi</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pajak_retribusi_pbb" class="col-sm-3 control-label">Wajib Pajak Bumi dan Bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pajak_retribusi_pbb" name="data[anggota][4][pajak_retribusi][pbb]" placeholder="Wajib Pajak Bumi dan Bangunan" value="<?php echo $ddk->anggota[4]["pajak_retribusi"]["pbb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pajak_retribusi_ppp" class="col-sm-3 control-label">Wajib Pajak Penghasilan Perorangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pajak_retribusi_ppp" name="data[anggota][4][pajak_retribusi][ppp]" placeholder="Wajib Pajak Penghasilan Perorangan" value="<?php echo $ddk->anggota[4]["pajak_retribusi"]["ppp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pajak_retribusi_pb" class="col-sm-3 control-label">Wajib Pajak Badan/Perusahaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pajak_retribusi_pb" name="data[anggota][4][pajak_retribusi][pb]" placeholder="Wajib Pajak Badan/Perusahaan" value="<?php echo $ddk->anggota[4]["pajak_retribusi"]["pb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pajak_retribusi_pkb" class="col-sm-3 control-label">Wajib Pajak Kendaraan Bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pajak_retribusi_pkb" name="data[anggota][4][pajak_retribusi][pkb]" placeholder="Wajib Pajak Kendaraan Bermotor" value="<?php echo $ddk->anggota[4]["pajak_retribusi"]["pkb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pajak_retribusi_kebersihan" class="col-sm-3 control-label">Wajib Retribusi Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pajak_retribusi_kebersihan" name="data[anggota][4][pajak_retribusi][kebersihan]" placeholder="Wajib Retribusi Kebersihan" value="<?php echo $ddk->anggota[4]["pajak_retribusi"]["kebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pajak_retribusi_keamanan" class="col-sm-3 control-label">Wajib Retribusi Keamanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pajak_retribusi_keamanan" name="data[anggota][4][pajak_retribusi][keamanan]" placeholder="Wajib Retribusi Keamanan" value="<?php echo $ddk->anggota[4]["pajak_retribusi"]["keamanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pajak_retribusi_iuran" class="col-sm-3 control-label">Wajib iuran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pajak_retribusi_iuran" name="data[anggota][4][pajak_retribusi][iuran]" placeholder="Wajib iuran" value="<?php echo $ddk->anggota[4]["pajak_retribusi"]["iuran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pajak_retribusi_pungutan" class="col-sm-3 control-label">Wajib pungutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pajak_retribusi_pungutan" name="data[anggota][4][pajak_retribusi][pungutan]" placeholder="Wajib pungutan" value="<?php echo $ddk->anggota[4]["pajak_retribusi"]["pungutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pajak_retribusi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pajak_retribusi_lainnya" name="data[anggota][4][pajak_retribusi][lainnya][keterangan]" placeholder="Keterangan Lainnya" value="<?php echo $ddk->anggota[4]["pajak_retribusi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_pajak_retribusi_lainnya" name="data[anggota][4][pajak_retribusi][lainnya][jumlah]" placeholder="Jumlah Lainnya" value="<?php echo $ddk->anggota[4]["pajak_retribusi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Pemerintahan Yang Diikuti Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pemerintahan_kepala_desa" class="col-sm-3 control-label">Kepala Desa/Lurah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pemerintahan_kepala_desa" name="data[anggota][4][pemerintahan][kepala_desa]" placeholder="Kepala Desa/Lurah" value="<?php echo $ddk->anggota[4]["pemerintahan"]["kepala_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pemerintahan_sekretaris_desa" class="col-sm-3 control-label">Sekretaris Desa/Kelurahan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pemerintahan_sekretaris_desa" name="data[anggota][4][pemerintahan][sekretaris_desa]" placeholder="Sekretaris Desa/Kelurahan" value="<?php echo $ddk->anggota[4]["pemerintahan"]["sekretaris_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pemerintahan_kepala_urusan" class="col-sm-3 control-label">Kepala Urusan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pemerintahan_kepala_urusan" name="data[anggota][4][pemerintahan][kepala_urusan]" placeholder="Kepala Urusan" value="<?php echo $ddk->anggota[4]["pemerintahan"]["kepala_urusan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pemerintahan_kepala_dusun" class="col-sm-3 control-label">Kepala Dusun/Lingkungan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pemerintahan_kepala_dusun" name="data[anggota][4][pemerintahan][kepala_dusun]" placeholder="Kepala Dusun/Lingkungan" value="<?php echo $ddk->anggota[4]["pemerintahan"]["kepala_dusun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pemerintahan_staf_desa" class="col-sm-3 control-label">Staf Desa/Kelurahan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pemerintahan_staf_desa" name="data[anggota][4][pemerintahan][staf_desa]" placeholder="Staf Desa/Kelurahan" value="<?php echo $ddk->anggota[4]["pemerintahan"]["staf_desa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pemerintahan_ketua_bpd" class="col-sm-3 control-label">Ketua BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pemerintahan_ketua_bpd" name="data[anggota][4][pemerintahan][ketua_bpd]" placeholder="Ketua BPD" value="<?php echo $ddk->anggota[4]["pemerintahan"]["ketua_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pemerintahan_wakil_ketua_bpd" class="col-sm-3 control-label">Wakil Ketua BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pemerintahan_wakil_ketua_bpd" name="data[anggota][4][pemerintahan][wakil_ketua_bpd]" placeholder="Wakil Ketua BPD" value="<?php echo $ddk->anggota[4]["pemerintahan"]["wakil_ketua_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pemerintahan_sekretaris_bpd" class="col-sm-3 control-label">Sekretaris BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pemerintahan_sekretaris_bpd" name="data[anggota][4][pemerintahan][sekretaris_bpd]" placeholder="Sekretaris BPD" value="<?php echo $ddk->anggota[4]["pemerintahan"]["sekretaris_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pemerintahan_anggota_bpd" class="col-sm-3 control-label">Anggota BPD</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pemerintahan_anggota_bpd" name="data[anggota][4][pemerintahan][anggota_bpd]" placeholder="Anggota BPD" value="<?php echo $ddk->anggota[4]["pemerintahan"]["anggota_bpd"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_pemerintahan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_pemerintahan_lainnya" name="data[anggota][4][pemerintahan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[4]["pemerintahan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_pemerintahan_lainnya" name="data[anggota][4][pemerintahan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[4]["pemerintahan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Kemasyarakatan Yang Diikuti Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_prt" class="col-sm-3 control-label">Pengurus RT</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_prt" name="data[anggota][4][kemasyarakatan][prt]" placeholder="Pengurus RT" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["prt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aprt" class="col-sm-3 control-label">Anggota Pengurus RT</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aprt" name="data[anggota][4][kemasyarakatan][aprt]" placeholder="Anggota Pengurus RT" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aprt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_prw" class="col-sm-3 control-label">Pengurus RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_prw" name="data[anggota][4][kemasyarakatan][prw]" placeholder="Pengurus RW" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["prw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aprw" class="col-sm-3 control-label">Anggota Pengurus RW</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aprw" name="data[anggota][4][kemasyarakatan][aprw]" placeholder="Anggota Pengurus RW" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aprw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_plkmdklpm" class="col-sm-3 control-label">Pengurus LKMD/K/LPM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_plkmdklpm" name="data[anggota][4][kemasyarakatan][plkmdklpm]" placeholder="Pengurus LKMD/K/LPM" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["plkmdklpm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_alkmdklpm" class="col-sm-3 control-label">Anggota LKMD/K/LPM</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_alkmdklpm" name="data[anggota][4][kemasyarakatan][alkmdklpm]" placeholder="Anggota LKMD/K/LPM" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["alkmdklpm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_ppkk" class="col-sm-3 control-label">Pengurus PKK</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_ppkk" name="data[anggota][4][kemasyarakatan][ppkk]" placeholder="Pengurus PKK" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["ppkk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_apkk" class="col-sm-3 control-label">Anggota PKK</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_apkk" name="data[anggota][4][kemasyarakatan][apkk]" placeholder="Anggota PKK" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["apkk"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pla" class="col-sm-3 control-label">Pengurus Lembaga Adat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pla" name="data[anggota][4][kemasyarakatan][pla]" placeholder="Pengurus Lembaga Adat" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pla"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pkt" class="col-sm-3 control-label">Pengurus Karang Taruna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pkt" name="data[anggota][4][kemasyarakatan][pkt]" placeholder="Pengurus Karang Taruna" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pkt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_akt" class="col-sm-3 control-label">Anggota Karang Taruna</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_akt" name="data[anggota][4][kemasyarakatan][akt]" placeholder="Anggota Karang Taruna" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["akt"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_phl" class="col-sm-3 control-label">Pengurus Hansip/Linmas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_phl" name="data[anggota][4][kemasyarakatan][phl]" placeholder="Pengurus Hansip/Linmas" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["phl"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pp" class="col-sm-3 control-label">Pengurus Poskamling</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pp" name="data[anggota][4][kemasyarakatan][pp]" placeholder="Pengurus Poskamling" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pop" class="col-sm-3 control-label">Pengurus Organisasi Perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pop" name="data[anggota][4][kemasyarakatan][pop]" placeholder="Pengurus Organisasi Perempuan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aop" class="col-sm-3 control-label">Anggota Organisasi Perempuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aop" name="data[anggota][4][kemasyarakatan][aop]" placeholder="Anggota Organisasi Perempuan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pob" class="col-sm-3 control-label">Pengurus Organisasi Bapak-bapak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pob" name="data[anggota][4][kemasyarakatan][pob]" placeholder="Pengurus Organisasi Bapak-bapak" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pob"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aob" class="col-sm-3 control-label">Anggota Organisasi Bapak-bapak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aob" name="data[anggota][4][kemasyarakatan][aob]" placeholder="Anggota Organisasi Bapak-bapak" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aob"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pok" class="col-sm-3 control-label">Pengurus Organisasi keagamaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pok" name="data[anggota][4][kemasyarakatan][pok]" placeholder="Pengurus Organisasi keagamaan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aok" class="col-sm-3 control-label">Anggota Organisasi keagamaan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aok" name="data[anggota][4][kemasyarakatan][aok]" placeholder="Anggota Organisasi keagamaan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aok"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_popw" class="col-sm-3 control-label">Pengurus Organisasi profesi wartawan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_popw" name="data[anggota][4][kemasyarakatan][popw]" placeholder="Pengurus Organisasi profesi wartawan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["popw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aopw" class="col-sm-3 control-label">Anggota Organisasi profesi wartawan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aopw" name="data[anggota][4][kemasyarakatan][aopw]" placeholder="Anggota Organisasi profesi wartawan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aopw"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pposyandu" class="col-sm-3 control-label">Pengurus Posyandu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pposyandu" name="data[anggota][4][kemasyarakatan][pposyandu]" placeholder="Pengurus Posyandu" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pposyandu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pposyantekdes" class="col-sm-3 control-label">Pengurus Posyantekdes</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pposyantekdes" name="data[anggota][4][kemasyarakatan][pposyantekdes]" placeholder="Pengurus Posyantekdes" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pposyantekdes"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_poktan" class="col-sm-3 control-label">Pengurus Organisasi Kelompok Tani/Nelayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_poktan" name="data[anggota][4][kemasyarakatan][poktan]" placeholder="Pengurus Organisasi Kelompok Tani/Nelayan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["poktan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aoktan" class="col-sm-3 control-label">Anggota Organisasi Kelompok Tani/Nelayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aoktan" name="data[anggota][4][kemasyarakatan][aoktan]" placeholder="Anggota Organisasi Kelompok Tani/Nelayan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aoktan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_plgr" class="col-sm-3 control-label">Pengurus Lembaga Gotong royong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_plgr" name="data[anggota][4][kemasyarakatan][plgr]" placeholder="Pengurus Lembaga Gotong royong" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["plgr"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_algr" class="col-sm-3 control-label">Anggota Lembaga Gotong royong</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_algr" name="data[anggota][4][kemasyarakatan][algr]" placeholder="Anggota Lembaga Gotong royong" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["algr"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_popg" class="col-sm-3 control-label">Pengurus Organisasi Profesi guru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_popg" name="data[anggota][4][kemasyarakatan][popg]" placeholder="Pengurus Organisasi Profesi guru" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["popg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aopg" class="col-sm-3 control-label">Anggota Organisasi Profesi guru</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aopg" name="data[anggota][4][kemasyarakatan][aopg]" placeholder="Anggota Organisasi Profesi guru" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aopg"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_popdtm" class="col-sm-3 control-label">Pengurus Organisasi profesi dokter/tenaga medis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_popdtm" name="data[anggota][4][kemasyarakatan][popdtm]" placeholder="Pengurus Organisasi profesi dokter/tenaga medis" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["popdtm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aoptm" class="col-sm-3 control-label">Anggota Organisasi profesi/tenaga medis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aoptm" name="data[anggota][4][kemasyarakatan][aoptm]" placeholder="Anggota Organisasi profesi/tenaga medis" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aoptm"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_popensiun" class="col-sm-3 control-label">Pengurus organisasi pensiunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_popensiun" name="data[anggota][4][kemasyarakatan][popensiun]" placeholder="Pengurus organisasi pensiunan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["popensiun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aopensiun" class="col-sm-3 control-label">Anggota organisasi pensiunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aopensiun" name="data[anggota][4][kemasyarakatan][aopensiun]" placeholder="Anggota organisasi pensiunan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aopensiun"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_popp" class="col-sm-3 control-label">Pengurus organisasi pemirsa/pendengar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_popp" name="data[anggota][4][kemasyarakatan][popp]" placeholder="Pengurus organisasi pemirsa/pendengar" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["popp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aopp" class="col-sm-3 control-label">Anggota organisasi pemirsa/pendengar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aopp" name="data[anggota][4][kemasyarakatan][aopp]" placeholder="Anggota organisasi pemirsa/pendengar" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aopp"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_plpa" class="col-sm-3 control-label">Pengurus lembaga pencinta alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_plpa" name="data[anggota][4][kemasyarakatan][plpa]" placeholder="Pengurus lembaga pencinta alam" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["plpa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_alpa" class="col-sm-3 control-label">Anggota organisasi pencinta alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_alpa" name="data[anggota][4][kemasyarakatan][alpa]" placeholder="Anggota organisasi pencinta alam" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["alpa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_popip" class="col-sm-3 control-label">Pengurus organisasi pengembangan ilmu pengetahuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_popip" name="data[anggota][4][kemasyarakatan][popip]" placeholder="Pengurus organisasi pengembangan ilmu pengetahuan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["popip"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_aopip" class="col-sm-3 control-label">Anggota organisasi pengembangan ilmu pengetaahuan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_aopip" name="data[anggota][4][kemasyarakatan][aopip]" placeholder="Anggota organisasi pengembangan ilmu pengetaahuan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["aopip"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pemyaya" class="col-sm-3 control-label">Pemilik yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pemyaya" name="data[anggota][4][kemasyarakatan][pemyaya]" placeholder="Pemilik yayasan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pemyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_penyaya" class="col-sm-3 control-label">Pengurus yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_penyaya" name="data[anggota][4][kemasyarakatan][penyaya]" placeholder="Pengurus yayasan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["penyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_angyaya" class="col-sm-3 control-label">Anggota yayasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_angyaya" name="data[anggota][4][kemasyarakatan][angyaya]" placeholder="Anggota yayasan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["angyaya"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pkebersihan" class="col-sm-3 control-label">Pengurus Satgas Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pkebersihan" name="data[anggota][4][kemasyarakatan][pkebersihan]" placeholder="Pengurus Satgas Kebersihan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pkebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_akebersihan" class="col-sm-3 control-label">Anggota Satgas Kebersihan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_akebersihan" name="data[anggota][4][kemasyarakatan][akebersihan]" placeholder="Anggota Satgas Kebersihan" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["akebersihan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_pkebakaran" class="col-sm-3 control-label">Pengurus Satgas Kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_pkebakaran" name="data[anggota][4][kemasyarakatan][pkebakaran]" placeholder="Pengurus Satgas Kebakaran" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["pkebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_akebakaran" class="col-sm-3 control-label">Anggota Satgas Kebakaran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_akebakaran" name="data[anggota][4][kemasyarakatan][akebakaran]" placeholder="Anggota Satgas Kebakaran" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["akebakaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_ppb" class="col-sm-3 control-label">Pengurus Posko Penanggulangan Bencana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_ppb" name="data[anggota][4][kemasyarakatan][ppb]" placeholder="Pengurus Posko Penanggulangan Bencana" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["ppb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_atpb" class="col-sm-3 control-label">Anggota Tim Penanggulangan Bencana</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_atpb" name="data[anggota][4][kemasyarakatan][atpb]" placeholder="Anggota Tim Penanggulangan Bencana" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["atpb"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_kemasyarakatan_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_lainnya" name="data[anggota][4][kemasyarakatan][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_kemasyarakatan_lainnya" name="data[anggota][4][kemasyarakatan][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[4]["kemasyarakatan"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Lembaga Ekonomi Yang Dimiliki Anggota Keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_koperasi" class="col-sm-3 control-label">Koperasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_koperasi" name="data[anggota][4][ekonomi][koperasi]" placeholder="Koperasi" value="<?php echo $ddk->anggota[4]["ekonomi"]["koperasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_unit_usaha_simpan_pinjam" class="col-sm-3 control-label">Unit Usaha Simpan Pinjam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_unit_usaha_simpan_pinjam" name="data[anggota][4][ekonomi][unit_usaha_simpan_pinjam]" placeholder="Unit Usaha Simpan Pinjam" value="<?php echo $ddk->anggota[4]["ekonomi"]["unit_usaha_simpan_pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_industri_kerajinan_tangan" class="col-sm-3 control-label">Industri Kerajinan Tangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_industri_kerajinan_tangan" name="data[anggota][4][ekonomi][industri_kerajinan_tangan]" placeholder="Industri Kerajinan Tangan" value="<?php echo $ddk->anggota[4]["ekonomi"]["industri_kerajinan_tangan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_industri_pakaian" class="col-sm-3 control-label">Industri Pakaian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_industri_pakaian" name="data[anggota][4][ekonomi][industri_pakaian]" placeholder="Industri Pakaian" value="<?php echo $ddk->anggota[4]["ekonomi"]["industri_pakaian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_industri_usaha_makanan" class="col-sm-3 control-label">Industri Usaha Makanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_industri_usaha_makanan" name="data[anggota][4][ekonomi][industri_usaha_makanan]" placeholder="Industri Usaha Makanan" value="<?php echo $ddk->anggota[4]["ekonomi"]["industri_usaha_makanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_industri_alat_rumah_tangga" class="col-sm-3 control-label">Industri Alat Rumah Tangga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_industri_alat_rumah_tangga" name="data[anggota][4][ekonomi][industri_alat_rumah_tangga]" placeholder="Industri Alat Rumah Tangga" value="<?php echo $ddk->anggota[4]["ekonomi"]["industri_alat_rumah_tangga"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_industri_usaha_bahan_bangunan" class="col-sm-3 control-label">Industri Usaha Bahan Bangunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_industri_usaha_bahan_bangunan" name="data[anggota][4][ekonomi][industri_usaha_bahan_bangunan]" placeholder="Industri Usaha Bahan Bangunan" value="<?php echo $ddk->anggota[4]["ekonomi"]["industri_usaha_bahan_bangunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_industri_alat_pertanian" class="col-sm-3 control-label">Industri Alat Pertanian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_industri_alat_pertanian" name="data[anggota][4][ekonomi][industri_alat_pertanian]" placeholder="Industri Alat Pertanian" value="<?php echo $ddk->anggota[4]["ekonomi"]["industri_alat_pertanian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_restoran" class="col-sm-3 control-label">Restoran</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_restoran" name="data[anggota][4][ekonomi][restoran]" placeholder="Restoran" value="<?php echo $ddk->anggota[4]["ekonomi"]["restoran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_toko__swalayan" class="col-sm-3 control-label">Toko/ Swalayan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_toko__swalayan" name="data[anggota][4][ekonomi][toko__swalayan]" placeholder="Toko/ Swalayan" value="<?php echo $ddk->anggota[4]["ekonomi"]["toko__swalayan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_warung_kelontongan_kios" class="col-sm-3 control-label">Warung Kelontongan/Kios</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_warung_kelontongan_kios" name="data[anggota][4][ekonomi][warung_kelontongan_kios]" placeholder="Warung Kelontongan/Kios" value="<?php echo $ddk->anggota[4]["ekonomi"]["warung_kelontongan_kios"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_angkutan_darat" class="col-sm-3 control-label">Angkutan Darat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_angkutan_darat" name="data[anggota][4][ekonomi][angkutan_darat]" placeholder="Angkutan Darat" value="<?php echo $ddk->anggota[4]["ekonomi"]["angkutan_darat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_angkutan_sungai" class="col-sm-3 control-label">Angkutan Sungai</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_angkutan_sungai" name="data[anggota][4][ekonomi][angkutan_sungai]" placeholder="Angkutan Sungai" value="<?php echo $ddk->anggota[4]["ekonomi"]["angkutan_sungai"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_angkutan_laut" class="col-sm-3 control-label">Angkutan Laut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_angkutan_laut" name="data[anggota][4][ekonomi][angkutan_laut]" placeholder="Angkutan Laut" value="<?php echo $ddk->anggota[4]["ekonomi"]["angkutan_laut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_angkutan_udara" class="col-sm-3 control-label">Angkutan Udara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_angkutan_udara" name="data[anggota][4][ekonomi][angkutan_udara]" placeholder="Angkutan Udara" value="<?php echo $ddk->anggota[4]["ekonomi"]["angkutan_udara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_jasa_ekspedisi_pengiriman_barang" class="col-sm-3 control-label">Jasa Ekspedisi/Pengiriman Barang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_jasa_ekspedisi_pengiriman_barang" name="data[anggota][4][ekonomi][jasa_ekspedisi_pengiriman_barang]" placeholder="Jasa Ekspedisi/Pengiriman Barang" value="<?php echo $ddk->anggota[4]["ekonomi"]["jasa_ekspedisi_pengiriman_barang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_pasar_harian" class="col-sm-3 control-label">Usaha Pasar Harian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_pasar_harian" name="data[anggota][4][ekonomi][usaha_pasar_harian]" placeholder="Usaha Pasar Harian" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_pasar_harian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_pasar_mingguan" class="col-sm-3 control-label">Usaha Pasar Mingguan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_pasar_mingguan" name="data[anggota][4][ekonomi][usaha_pasar_mingguan]" placeholder="Usaha Pasar Mingguan" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_pasar_mingguan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_pasar_ternak" class="col-sm-3 control-label">Usaha Pasar Ternak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_pasar_ternak" name="data[anggota][4][ekonomi][usaha_pasar_ternak]" placeholder="Usaha Pasar Ternak" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_pasar_ternak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_pasar_hasil_bumi_dan_tambang" class="col-sm-3 control-label">Usaha Pasar Hasil Bumi Dan Tambang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_pasar_hasil_bumi_dan_tambang" name="data[anggota][4][ekonomi][usaha_pasar_hasil_bumi_dan_tambang]" placeholder="Usaha Pasar Hasil Bumi Dan Tambang" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_pasar_hasil_bumi_dan_tambang"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_perdagangan_antar_pulau" class="col-sm-3 control-label">Usaha Perdagangan Antar Pulau</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_perdagangan_antar_pulau" name="data[anggota][4][ekonomi][usaha_perdagangan_antar_pulau]" placeholder="Usaha Perdagangan Antar Pulau" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_perdagangan_antar_pulau"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_pengijon" class="col-sm-3 control-label">Pengijon</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_pengijon" name="data[anggota][4][ekonomi][pengijon]" placeholder="Pengijon" value="<?php echo $ddk->anggota[4]["ekonomi"]["pengijon"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_pedagang_pengumpul_tengkulak" class="col-sm-3 control-label">Pedagang Pengumpul/Tengkulak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_pedagang_pengumpul_tengkulak" name="data[anggota][4][ekonomi][pedagang_pengumpul_tengkulak]" placeholder="Pedagang Pengumpul/Tengkulak" value="<?php echo $ddk->anggota[4]["ekonomi"]["pedagang_pengumpul_tengkulak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_peternakan" class="col-sm-3 control-label">Usaha Peternakan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_peternakan" name="data[anggota][4][ekonomi][usaha_peternakan]" placeholder="Usaha Peternakan" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_peternakan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_perikanan" class="col-sm-3 control-label">Usaha Perikanan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_perikanan" name="data[anggota][4][ekonomi][usaha_perikanan]" placeholder="Usaha Perikanan" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_perikanan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_perkebunan" class="col-sm-3 control-label">Usaha Perkebunan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_perkebunan" name="data[anggota][4][ekonomi][usaha_perkebunan]" placeholder="Usaha Perkebunan" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_perkebunan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_kelompok_simpan_pinjam" class="col-sm-3 control-label">Kelompok Simpan Pinjam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_kelompok_simpan_pinjam" name="data[anggota][4][ekonomi][kelompok_simpan_pinjam]" placeholder="Kelompok Simpan Pinjam" value="<?php echo $ddk->anggota[4]["ekonomi"]["kelompok_simpan_pinjam"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_minuman" class="col-sm-3 control-label">Usaha Minuman</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_minuman" name="data[anggota][4][ekonomi][usaha_minuman]" placeholder="Usaha Minuman" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_minuman"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_industri_farmasi" class="col-sm-3 control-label">Industri Farmasi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_industri_farmasi" name="data[anggota][4][ekonomi][industri_farmasi]" placeholder="Industri Farmasi" value="<?php echo $ddk->anggota[4]["ekonomi"]["industri_farmasi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_industri_karoseri" class="col-sm-3 control-label">Industri Karoseri</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_industri_karoseri" name="data[anggota][4][ekonomi][industri_karoseri]" placeholder="Industri Karoseri" value="<?php echo $ddk->anggota[4]["ekonomi"]["industri_karoseri"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_penitipan_kendaraan_bermotor" class="col-sm-3 control-label">Penitipan Kendaraan Bermotor</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_penitipan_kendaraan_bermotor" name="data[anggota][4][ekonomi][penitipan_kendaraan_bermotor]" placeholder="Penitipan Kendaraan Bermotor" value="<?php echo $ddk->anggota[4]["ekonomi"]["penitipan_kendaraan_bermotor"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_industri_perakitan_elektronik" class="col-sm-3 control-label">Industri Perakitan Elektronik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_industri_perakitan_elektronik" name="data[anggota][4][ekonomi][industri_perakitan_elektronik]" placeholder="Industri Perakitan Elektronik" value="<?php echo $ddk->anggota[4]["ekonomi"]["industri_perakitan_elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_pengolahan_kayu" class="col-sm-3 control-label">Pengolahan Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_pengolahan_kayu" name="data[anggota][4][ekonomi][pengolahan_kayu]" placeholder="Pengolahan Kayu" value="<?php echo $ddk->anggota[4]["ekonomi"]["pengolahan_kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_bioskop" class="col-sm-3 control-label">Bioskop</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_bioskop" name="data[anggota][4][ekonomi][bioskop]" placeholder="Bioskop" value="<?php echo $ddk->anggota[4]["ekonomi"]["bioskop"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_film_keliling" class="col-sm-3 control-label">Film Keliling</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_film_keliling" name="data[anggota][4][ekonomi][film_keliling]" placeholder="Film Keliling" value="<?php echo $ddk->anggota[4]["ekonomi"]["film_keliling"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_sandiwara_drama" class="col-sm-3 control-label">Sandiwara/Drama</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_sandiwara_drama" name="data[anggota][4][ekonomi][sandiwara_drama]" placeholder="Sandiwara/Drama" value="<?php echo $ddk->anggota[4]["ekonomi"]["sandiwara_drama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_group_lawak" class="col-sm-3 control-label">Group Lawak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_group_lawak" name="data[anggota][4][ekonomi][group_lawak]" placeholder="Group Lawak" value="<?php echo $ddk->anggota[4]["ekonomi"]["group_lawak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_jaipongan" class="col-sm-3 control-label">Jaipongan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_jaipongan" name="data[anggota][4][ekonomi][jaipongan]" placeholder="Jaipongan" value="<?php echo $ddk->anggota[4]["ekonomi"]["jaipongan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_wayang_orang_golek" class="col-sm-3 control-label">Wayang Orang/Golek</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_wayang_orang_golek" name="data[anggota][4][ekonomi][wayang_orang_golek]" placeholder="Wayang Orang/Golek" value="<?php echo $ddk->anggota[4]["ekonomi"]["wayang_orang_golek"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_group_musik_band" class="col-sm-3 control-label">Group Musik/Band</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_group_musik_band" name="data[anggota][4][ekonomi][group_musik_band]" placeholder="Group Musik/Band" value="<?php echo $ddk->anggota[4]["ekonomi"]["group_musik_band"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_group_vokal_paduan_suara" class="col-sm-3 control-label">Group Vokal/Paduan Suara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_group_vokal_paduan_suara" name="data[anggota][4][ekonomi][group_vokal_paduan_suara]" placeholder="Group Vokal/Paduan Suara" value="<?php echo $ddk->anggota[4]["ekonomi"]["group_vokal_paduan_suara"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_persewaan_tenaga_listrik" class="col-sm-3 control-label">Usaha Persewaan Tenaga Listrik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_persewaan_tenaga_listrik" name="data[anggota][4][ekonomi][usaha_persewaan_tenaga_listrik]" placeholder="Usaha Persewaan Tenaga Listrik" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_persewaan_tenaga_listrik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_pengecer_gas_dan_bahan_bakar_minyak" class="col-sm-3 control-label">Usaha Pengecer Gas Dan Bahan Bakar Minyak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_pengecer_gas_dan_bahan_bakar_minyak" name="data[anggota][4][ekonomi][usaha_pengecer_gas_dan_bahan_bakar_minyak]" placeholder="Usaha Pengecer Gas Dan Bahan Bakar Minyak" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_pengecer_gas_dan_bahan_bakar_minyak"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_air_minum_dalam_kemasan" class="col-sm-3 control-label">Usaha Air Minum Dalam Kemasan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_air_minum_dalam_kemasan" name="data[anggota][4][ekonomi][usaha_air_minum_dalam_kemasan]" placeholder="Usaha Air Minum Dalam Kemasan" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_air_minum_dalam_kemasan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_tukang_kayu" class="col-sm-3 control-label">Tukang Kayu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_tukang_kayu" name="data[anggota][4][ekonomi][tukang_kayu]" placeholder="Tukang Kayu" value="<?php echo $ddk->anggota[4]["ekonomi"]["tukang_kayu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_tukang_batu" class="col-sm-3 control-label">Tukang Batu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_tukang_batu" name="data[anggota][4][ekonomi][tukang_batu]" placeholder="Tukang Batu" value="<?php echo $ddk->anggota[4]["ekonomi"]["tukang_batu"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_tukang_jahit_bordir" class="col-sm-3 control-label">Tukang Jahit/Bordir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_tukang_jahit_bordir" name="data[anggota][4][ekonomi][tukang_jahit_bordir]" placeholder="Tukang Jahit/Bordir" value="<?php echo $ddk->anggota[4]["ekonomi"]["tukang_jahit_bordir"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_tukang_cukur" class="col-sm-3 control-label">Tukang Cukur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_tukang_cukur" name="data[anggota][4][ekonomi][tukang_cukur]" placeholder="Tukang Cukur" value="<?php echo $ddk->anggota[4]["ekonomi"]["tukang_cukur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_tukang_service_elektronik" class="col-sm-3 control-label">Tukang Service Elektronik</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_tukang_service_elektronik" name="data[anggota][4][ekonomi][tukang_service_elektronik]" placeholder="Tukang Service Elektronik" value="<?php echo $ddk->anggota[4]["ekonomi"]["tukang_service_elektronik"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_tukang_besi" class="col-sm-3 control-label">Tukang Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_tukang_besi" name="data[anggota][4][ekonomi][tukang_besi]" placeholder="Tukang Besi" value="<?php echo $ddk->anggota[4]["ekonomi"]["tukang_besi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_tukang_pijat_urut" class="col-sm-3 control-label">Tukang Pijat/Urut</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_tukang_pijat_urut" name="data[anggota][4][ekonomi][tukang_pijat_urut]" placeholder="Tukang Pijat/Urut" value="<?php echo $ddk->anggota[4]["ekonomi"]["tukang_pijat_urut"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_tukang_sumur" class="col-sm-3 control-label">Tukang Sumur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_tukang_sumur" name="data[anggota][4][ekonomi][tukang_sumur]" placeholder="Tukang Sumur" value="<?php echo $ddk->anggota[4]["ekonomi"]["tukang_sumur"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_notaris" class="col-sm-3 control-label">Notaris</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_notaris" name="data[anggota][4][ekonomi][notaris]" placeholder="Notaris" value="<?php echo $ddk->anggota[4]["ekonomi"]["notaris"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_pengacara_advokat" class="col-sm-3 control-label">Pengacara/Advokat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_pengacara_advokat" name="data[anggota][4][ekonomi][pengacara_advokat]" placeholder="Pengacara/Advokat" value="<?php echo $ddk->anggota[4]["ekonomi"]["pengacara_advokat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_konsultan_manajemen" class="col-sm-3 control-label">Konsultan Manajemen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_konsultan_manajemen" name="data[anggota][4][ekonomi][konsultan_manajemen]" placeholder="Konsultan Manajemen" value="<?php echo $ddk->anggota[4]["ekonomi"]["konsultan_manajemen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_konsultan_teknis" class="col-sm-3 control-label">Konsultan Teknis</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_konsultan_teknis" name="data[anggota][4][ekonomi][konsultan_teknis]" placeholder="Konsultan Teknis" value="<?php echo $ddk->anggota[4]["ekonomi"]["konsultan_teknis"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_pejabat_pembuat_akta_tanah" class="col-sm-3 control-label">Pejabat Pembuat Akta Tanah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_pejabat_pembuat_akta_tanah" name="data[anggota][4][ekonomi][pejabat_pembuat_akta_tanah]" placeholder="Pejabat Pembuat Akta Tanah" value="<?php echo $ddk->anggota[4]["ekonomi"]["pejabat_pembuat_akta_tanah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_losmen" class="col-sm-3 control-label">Losmen</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_losmen" name="data[anggota][4][ekonomi][losmen]" placeholder="Losmen" value="<?php echo $ddk->anggota[4]["ekonomi"]["losmen"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_wisma" class="col-sm-3 control-label">Wisma</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_wisma" name="data[anggota][4][ekonomi][wisma]" placeholder="Wisma" value="<?php echo $ddk->anggota[4]["ekonomi"]["wisma"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_asrama" class="col-sm-3 control-label">Asrama</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_asrama" name="data[anggota][4][ekonomi][asrama]" placeholder="Asrama" value="<?php echo $ddk->anggota[4]["ekonomi"]["asrama"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_persewaan_kamar" class="col-sm-3 control-label">Persewaan Kamar</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_persewaan_kamar" name="data[anggota][4][ekonomi][persewaan_kamar]" placeholder="Persewaan Kamar" value="<?php echo $ddk->anggota[4]["ekonomi"]["persewaan_kamar"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_kontrakan_rumah" class="col-sm-3 control-label">Kontrakan Rumah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_kontrakan_rumah" name="data[anggota][4][ekonomi][kontrakan_rumah]" placeholder="Kontrakan Rumah" value="<?php echo $ddk->anggota[4]["ekonomi"]["kontrakan_rumah"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_mess" class="col-sm-3 control-label">Mess</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_mess" name="data[anggota][4][ekonomi][mess]" placeholder="Mess" value="<?php echo $ddk->anggota[4]["ekonomi"]["mess"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_hotel" class="col-sm-3 control-label">Hotel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_hotel" name="data[anggota][4][ekonomi][hotel]" placeholder="Hotel" value="<?php echo $ddk->anggota[4]["ekonomi"]["hotel"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_home_stay" class="col-sm-3 control-label">Home Stay</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_home_stay" name="data[anggota][4][ekonomi][home_stay]" placeholder="Home Stay" value="<?php echo $ddk->anggota[4]["ekonomi"]["home_stay"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_villa" class="col-sm-3 control-label">Villa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_villa" name="data[anggota][4][ekonomi][villa]" placeholder="Villa" value="<?php echo $ddk->anggota[4]["ekonomi"]["villa"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_town_house" class="col-sm-3 control-label">Town House</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_town_house" name="data[anggota][4][ekonomi][town_house]" placeholder="Town House" value="<?php echo $ddk->anggota[4]["ekonomi"]["town_house"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_asuransi" class="col-sm-3 control-label">Usaha Asuransi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_asuransi" name="data[anggota][4][ekonomi][usaha_asuransi]" placeholder="Usaha Asuransi" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_asuransi"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_lembaga_keuangan_bukan_bank" class="col-sm-3 control-label">Lembaga Keuangan Bukan Bank</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_lembaga_keuangan_bukan_bank" name="data[anggota][4][ekonomi][lembaga_keuangan_bukan_bank]" placeholder="Lembaga Keuangan Bukan Bank" value="<?php echo $ddk->anggota[4]["ekonomi"]["lembaga_keuangan_bukan_bank"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_lembaga_perkreditan_rakyat" class="col-sm-3 control-label">Lembaga Perkreditan Rakyat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_lembaga_perkreditan_rakyat" name="data[anggota][4][ekonomi][lembaga_perkreditan_rakyat]" placeholder="Lembaga Perkreditan Rakyat" value="<?php echo $ddk->anggota[4]["ekonomi"]["lembaga_perkreditan_rakyat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_pegadaian" class="col-sm-3 control-label">Pegadaian</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_pegadaian" name="data[anggota][4][ekonomi][pegadaian]" placeholder="Pegadaian" value="<?php echo $ddk->anggota[4]["ekonomi"]["pegadaian"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_bank_perkreditan_rakyat" class="col-sm-3 control-label">Bank Perkreditan Rakyat</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_bank_perkreditan_rakyat" name="data[anggota][4][ekonomi][bank_perkreditan_rakyat]" placeholder="Bank Perkreditan Rakyat" value="<?php echo $ddk->anggota[4]["ekonomi"]["bank_perkreditan_rakyat"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_penyewaan_alat_pesta" class="col-sm-3 control-label">Usaha Penyewaan Alat Pesta</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_penyewaan_alat_pesta" name="data[anggota][4][ekonomi][usaha_penyewaan_alat_pesta]" placeholder="Usaha Penyewaan Alat Pesta" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_penyewaan_alat_pesta"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_usaha_pengolahan_dan_penjualan_hasil_hutan" class="col-sm-3 control-label">Usaha Pengolahan dan Penjualan Hasil Hutan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_usaha_pengolahan_dan_penjualan_hasil_hutan" name="data[anggota][4][ekonomi][usaha_pengolahan_dan_penjualan_hasil_hutan]" placeholder="Usaha Pengolahan dan Penjualan Hasil Hutan" value="<?php echo $ddk->anggota[4]["ekonomi"]["usaha_pengolahan_dan_penjualan_hasil_hutan"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_ekonomi_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_ekonomi_lainnya" name="data[anggota][4][ekonomi][lainnya][keterangan]" placeholder="keterangan lainnya" value="<?php echo $ddk->anggota[4]["ekonomi"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_ekonomi_lainnya" name="data[anggota][4][ekonomi][lainnya][jumlah]" placeholder="jumlah lainnya" value="<?php echo $ddk->anggota[4]["ekonomi"]["lainnya"]["jumlah"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-22">
				<h4><strong>Produksi bahan galian yang dimiliki anggota keluarga</strong></h4>
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_batu_kali" class="col-sm-3 control-label">Batu kali</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_batu_kali" name="data[anggota][4][galian][batu_kali][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["batu_kali"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_kali" name="data[anggota][4][galian][batu_kali][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["batu_kali"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_kali" name="data[anggota][4][galian][batu_kali][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["batu_kali"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_kali" name="data[anggota][4][galian][batu_kali][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["batu_kali"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_batu_kapur" class="col-sm-3 control-label">Batu kapur</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_batu_kapur" name="data[anggota][4][galian][batu_kapur][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["batu_kapur"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_kapur" name="data[anggota][4][galian][batu_kapur][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["batu_kapur"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_kapur" name="data[anggota][4][galian][batu_kapur][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["batu_kapur"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_kapur" name="data[anggota][4][galian][batu_kapur][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["batu_kapur"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_pasir" class="col-sm-3 control-label">Pasir</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_pasir" name="data[anggota][4][galian][pasir][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["pasir"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir" name="data[anggota][4][galian][pasir][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["pasir"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir" name="data[anggota][4][galian][pasir][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["pasir"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir" name="data[anggota][4][galian][pasir][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["pasir"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_emas" class="col-sm-3 control-label">Emas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_emas" name="data[anggota][4][galian][emas][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["emas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_emas" name="data[anggota][4][galian][emas][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["emas"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_emas" name="data[anggota][4][galian][emas][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["emas"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_emas" name="data[anggota][4][galian][emas][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["emas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_kuningan" class="col-sm-3 control-label">Kuningan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_kuningan" name="data[anggota][4][galian][kuningan][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["kuningan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_kuningan" name="data[anggota][4][galian][kuningan][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["kuningan"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_kuningan" name="data[anggota][4][galian][kuningan][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["kuningan"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_kuningan" name="data[anggota][4][galian][kuningan][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["kuningan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_aluminium" class="col-sm-3 control-label">Aluminium</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_aluminium" name="data[anggota][4][galian][aluminium][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["aluminium"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_aluminium" name="data[anggota][4][galian][aluminium][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["aluminium"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_aluminium" name="data[anggota][4][galian][aluminium][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["aluminium"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_aluminium" name="data[anggota][4][galian][aluminium][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["aluminium"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_perunggu" class="col-sm-3 control-label">Perunggu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_perunggu" name="data[anggota][4][galian][perunggu][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["perunggu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_perunggu" name="data[anggota][4][galian][perunggu][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["perunggu"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_perunggu" name="data[anggota][4][galian][perunggu][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["perunggu"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_perunggu" name="data[anggota][4][galian][perunggu][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["perunggu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_belerang" class="col-sm-3 control-label">Belerang</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_belerang" name="data[anggota][4][galian][belerang][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["belerang"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_belerang" name="data[anggota][4][galian][belerang][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["belerang"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_belerang" name="data[anggota][4][galian][belerang][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["belerang"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_belerang" name="data[anggota][4][galian][belerang][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["belerang"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_batu_marmer" class="col-sm-3 control-label">Batu marmer</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_batu_marmer" name="data[anggota][4][galian][batu_marmer][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["batu_marmer"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_marmer" name="data[anggota][4][galian][batu_marmer][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["batu_marmer"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_marmer" name="data[anggota][4][galian][batu_marmer][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["batu_marmer"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_marmer" name="data[anggota][4][galian][batu_marmer][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["batu_marmer"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_batu_cadas" class="col-sm-3 control-label">Batu cadas</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_batu_cadas" name="data[anggota][4][galian][batu_cadas][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["batu_cadas"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_cadas" name="data[anggota][4][galian][batu_cadas][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["batu_cadas"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_cadas" name="data[anggota][4][galian][batu_cadas][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["batu_cadas"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_cadas" name="data[anggota][4][galian][batu_cadas][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["batu_cadas"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_batu_apung" class="col-sm-3 control-label">Batu apung</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_batu_apung" name="data[anggota][4][galian][batu_apung][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["batu_apung"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_apung" name="data[anggota][4][galian][batu_apung][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["batu_apung"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_apung" name="data[anggota][4][galian][batu_apung][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["batu_apung"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_apung" name="data[anggota][4][galian][batu_apung][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["batu_apung"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_pasir_kwarsa" class="col-sm-3 control-label">Pasir kwarsa</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_pasir_kwarsa" name="data[anggota][4][galian][pasir_kwarsa][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["pasir_kwarsa"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir_kwarsa" name="data[anggota][4][galian][pasir_kwarsa][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["pasir_kwarsa"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir_kwarsa" name="data[anggota][4][galian][pasir_kwarsa][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["pasir_kwarsa"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir_kwarsa" name="data[anggota][4][galian][pasir_kwarsa][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["pasir_kwarsa"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_batubara" class="col-sm-3 control-label">Batubara</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_batubara" name="data[anggota][4][galian][batubara][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["batubara"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batubara" name="data[anggota][4][galian][batubara][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["batubara"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batubara" name="data[anggota][4][galian][batubara][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["batubara"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batubara" name="data[anggota][4][galian][batubara][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["batubara"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_batu_granit" class="col-sm-3 control-label">Batu Granit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_batu_granit" name="data[anggota][4][galian][batu_granit][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["batu_granit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_granit" name="data[anggota][4][galian][batu_granit][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["batu_granit"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_granit" name="data[anggota][4][galian][batu_granit][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["batu_granit"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_granit" name="data[anggota][4][galian][batu_granit][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["batu_granit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_batu_gamping" class="col-sm-3 control-label">Batu Gamping</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_batu_gamping" name="data[anggota][4][galian][batu_gamping][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["batu_gamping"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_gamping" name="data[anggota][4][galian][batu_gamping][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["batu_gamping"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_gamping" name="data[anggota][4][galian][batu_gamping][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["batu_gamping"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_gamping" name="data[anggota][4][galian][batu_gamping][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["batu_gamping"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_mangan" class="col-sm-3 control-label">Mangan</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_mangan" name="data[anggota][4][galian][mangan][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["mangan"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_mangan" name="data[anggota][4][galian][mangan][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["mangan"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_mangan" name="data[anggota][4][galian][mangan][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["mangan"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_mangan" name="data[anggota][4][galian][mangan][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["mangan"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_batu_trass" class="col-sm-3 control-label">Batu Trass</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_batu_trass" name="data[anggota][4][galian][batu_trass][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["batu_trass"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_trass" name="data[anggota][4][galian][batu_trass][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["batu_trass"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_trass" name="data[anggota][4][galian][batu_trass][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["batu_trass"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_trass" name="data[anggota][4][galian][batu_trass][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["batu_trass"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_batu_putih" class="col-sm-3 control-label">Batu Putih</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_batu_putih" name="data[anggota][4][galian][batu_putih][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["batu_putih"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_putih" name="data[anggota][4][galian][batu_putih][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["batu_putih"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_putih" name="data[anggota][4][galian][batu_putih][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["batu_putih"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_batu_putih" name="data[anggota][4][galian][batu_putih][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["batu_putih"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_pasir_batu" class="col-sm-3 control-label">Pasir Batu</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_pasir_batu" name="data[anggota][4][galian][pasir_batu][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["pasir_batu"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir_batu" name="data[anggota][4][galian][pasir_batu][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["pasir_batu"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir_batu" name="data[anggota][4][galian][pasir_batu][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["pasir_batu"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir_batu" name="data[anggota][4][galian][pasir_batu][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["pasir_batu"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_pasir_besi" class="col-sm-3 control-label">Pasir Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_pasir_besi" name="data[anggota][4][galian][pasir_besi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["pasir_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir_besi" name="data[anggota][4][galian][pasir_besi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["pasir_besi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir_besi" name="data[anggota][4][galian][pasir_besi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["pasir_besi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_pasir_besi" name="data[anggota][4][galian][pasir_besi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["pasir_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_gips" class="col-sm-3 control-label">Gips</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_gips" name="data[anggota][4][galian][gips][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["gips"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_gips" name="data[anggota][4][galian][gips][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["gips"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_gips" name="data[anggota][4][galian][gips][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["gips"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_gips" name="data[anggota][4][galian][gips][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["gips"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_minyak_bumi" class="col-sm-3 control-label">Minyak Bumi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_minyak_bumi" name="data[anggota][4][galian][minyak_bumi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["minyak_bumi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_minyak_bumi" name="data[anggota][4][galian][minyak_bumi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["minyak_bumi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_minyak_bumi" name="data[anggota][4][galian][minyak_bumi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["minyak_bumi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_minyak_bumi" name="data[anggota][4][galian][minyak_bumi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["minyak_bumi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_gas_alam" class="col-sm-3 control-label">Gas Alam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_gas_alam" name="data[anggota][4][galian][gas_alam][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["gas_alam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_gas_alam" name="data[anggota][4][galian][gas_alam][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["gas_alam"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_gas_alam" name="data[anggota][4][galian][gas_alam][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["gas_alam"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_gas_alam" name="data[anggota][4][galian][gas_alam][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["gas_alam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_perak" class="col-sm-3 control-label">Perak</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_perak" name="data[anggota][4][galian][perak][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["perak"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_perak" name="data[anggota][4][galian][perak][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["perak"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_perak" name="data[anggota][4][galian][perak][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["perak"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_perak" name="data[anggota][4][galian][perak][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["perak"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_timah" class="col-sm-3 control-label">Timah</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_timah" name="data[anggota][4][galian][timah][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["timah"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_timah" name="data[anggota][4][galian][timah][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["timah"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_timah" name="data[anggota][4][galian][timah][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["timah"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_timah" name="data[anggota][4][galian][timah][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["timah"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_tembaga" class="col-sm-3 control-label">Tembaga</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_tembaga" name="data[anggota][4][galian][tembaga][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["tembaga"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_tembaga" name="data[anggota][4][galian][tembaga][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["tembaga"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_tembaga" name="data[anggota][4][galian][tembaga][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["tembaga"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_tembaga" name="data[anggota][4][galian][tembaga][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["tembaga"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_biji_besi" class="col-sm-3 control-label">Biji Besi</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_biji_besi" name="data[anggota][4][galian][biji_besi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["biji_besi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_biji_besi" name="data[anggota][4][galian][biji_besi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["biji_besi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_biji_besi" name="data[anggota][4][galian][biji_besi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["biji_besi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_biji_besi" name="data[anggota][4][galian][biji_besi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["biji_besi"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_uranium" class="col-sm-3 control-label">Uranium</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_uranium" name="data[anggota][4][galian][uranium][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["uranium"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_uranium" name="data[anggota][4][galian][uranium][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["uranium"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_uranium" name="data[anggota][4][galian][uranium][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["uranium"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_uranium" name="data[anggota][4][galian][uranium][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["uranium"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_bouxit" class="col-sm-3 control-label">Bouxit</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_bouxit" name="data[anggota][4][galian][bouxit][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["bouxit"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_bouxit" name="data[anggota][4][galian][bouxit][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["bouxit"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_bouxit" name="data[anggota][4][galian][bouxit][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["bouxit"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_bouxit" name="data[anggota][4][galian][bouxit][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["bouxit"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_garam" class="col-sm-3 control-label">Garam</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_garam" name="data[anggota][4][galian][garam][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["garam"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_garam" name="data[anggota][4][galian][garam][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["garam"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_garam" name="data[anggota][4][galian][garam][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["garam"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_garam" name="data[anggota][4][galian][garam][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["garam"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_nikel" class="col-sm-3 control-label">Nikel</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_nikel" name="data[anggota][4][galian][nikel][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["nikel"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_nikel" name="data[anggota][4][galian][nikel][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["nikel"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_nikel" name="data[anggota][4][galian][nikel][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["nikel"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_nikel" name="data[anggota][4][galian][nikel][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["nikel"]["pemasaran"] ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="anggota5_galian_lainnya" class="col-sm-3 control-label">Lainnya</label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="anggota5_galian_lainnya" name="data[anggota][4][galian][lainnya][keterangan]" placeholder="Keterangan" value="<?php echo $ddk->anggota[4]["galian"]["lainnya"]["keterangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_lainnya" name="data[anggota][4][galian][lainnya][opsi][produksi]" placeholder="Milik Produksi" value="<?php echo $ddk->anggota[4]["galian"]["lainnya"]["opsi"]["produksi"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_lainnya" name="data[anggota][4][galian][lainnya][opsi][adat]" placeholder="Milik Adat" value="<?php echo $ddk->anggota[4]["galian"]["lainnya"]["opsi"]["adat"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_lainnya" name="data[anggota][4][galian][lainnya][opsi][perorangan]" placeholder="Milik Perorangan" value="<?php echo $ddk->anggota[4]["galian"]["lainnya"]["opsi"]["perorangan"] ?>"><br>
				<input type="text" class="form-control" id="anggota5_galian_lainnya" name="data[anggota][4][galian][lainnya][opsi][pemasaran]" placeholder="Pemasaran Hasil" value="<?php echo $ddk->anggota[4]["galian"]["lainnya"]["opsi"]["pemasaran"] ?>">
			</div>
		</div>

		<div class="form-group">
			<div class="col-sm-5 col-sm-offset-2">
				<button type="submit" class="btn btn-lg btn-success"><i class="entypo-check"></i> Simpan</button>
				<a href="<?php echo base_url('data_dasar_keluarga') ?>" class="btn btn-lg btn-red pull-right"><i class="entypo-back"></i> Kembali</a>
			</div>
		</div>
	</form>

	<script type="text/javascript">
		jQuery(document).ready(function($){
			$('#kabupaten_id').select2({
				minimumInputLength: 3,
				allowClear: false,
				minimumResultsForSearch: 10,
				ajax: {
					url: "<?php echo base_url('data_dasar_keluarga/get_lokasi') ?>",
					dataType: 'json',
					data: function (term, page) {
						return{
							where: 'kabupaten',
							provinsi_id: $('#provinsi_id').val(),
							term: term,
						}
					},
					results: function (data, page) {
						return {
							results: data
						};
					}
				}
			});
			$('#kecamatan_id').select2({
				minimumInputLength: 3,
				allowClear: false,
				minimumResultsForSearch: 10,
				ajax: {
					url: "<?php echo base_url('data_dasar_keluarga/get_lokasi') ?>",
					dataType: 'json',
					data: function (term, page) {
						return{
							where: 'kecamatan',
							kabupaten_id: $('#kabupaten_id').val(),
							term: term,
						}
					},
					results: function (data, page) {
						return {
							results: data
						};
					}
				}
			});
			$('#desa_id').select2({
				minimumInputLength: 3,
				allowClear: false,
				minimumResultsForSearch: 10,
				ajax: {
					url: "<?php echo base_url('data_dasar_keluarga/get_lokasi') ?>",
					dataType: 'json',
					data: function (term, page) {
						return{
							where: 'desa',
							kecamatan_id: $('#kecamatan_id').val(),
							term: term,
						}
					},
					results: function (data, page) {
						return {
							results: data
						};
					}
				}
			});

			<?php if(!empty($ddk->kabupaten)): ?> $('#kabupaten_id').select2('data', <?php echo json_encode($ddk->kabupaten) ?>); <?php endif ?>
			<?php if(!empty($ddk->kecamatan)): ?> $('#kecamatan_id').select2('data', <?php echo json_encode($ddk->kecamatan) ?>); <?php endif ?>
			<?php if(!empty($ddk->desa)): ?> $('#desa_id').select2('data', <?php echo json_encode($ddk->desa) ?>); <?php endif ?>
		});
	</script>