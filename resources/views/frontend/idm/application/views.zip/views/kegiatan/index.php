<?php if ($this->session->flashdata('success_message')) : ?>
    <div class="alert alert-success"><?php echo $this->session->flashdata('success_message'); ?></div>
<?php endif;?>
<?php if ($this->session->flashdata('error_message')) : ?>
    <div class="alert alert-danger"><?php echo $this->session->flashdata('error_message'); ?></div>
<?php endif;?>
	<p>
<?php if($this->permission->check_permission($modules, 'add')): ?>
		<a class="btn btn-blue btn-icon icon-left" href="<?php echo base_url('kegiatan/tambah'); ?>">
			<i class="entypo-plus"></i>
			Tambah kegiatan
		</a> &nbsp;
		<button class="btn btn-blue btn-icon icon-left" data-load-remote="<?php echo base_url('kegiatan/modal/impor'); ?>" data-toggle="modal" data-target="#modal_global">
			<i class="entypo-upload"></i>
			Impor kegiatan
		</button> &nbsp;
		<button class="btn btn-blue btn-icon icon-left" data-load-remote="<?php echo base_url('kegiatan/modal/ekspor'); ?>" data-toggle="modal" data-target="#modal_global">
			<i class="entypo-download"></i>
			Ekspor kegiatan
		</button> &nbsp;
<?php endif ?>
	</p>
	<p class="text-right">Total Peserta: <strong><?php echo $total_peserta; ?></strong></p>
	<table class="table table-bordered datatable" id="list-kegiatan">
		<thead>
			<tr>
				<th>No.</th>
				<th>Kegiatan</th>
				<th>Tanggal</th>
				<th>Kabupaten</th>
				<th>Kecamatan</th>
				<th>Desa</th>
				<th>Peserta</th>
				<th>Status</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
		<?php if(!empty($list_kegiatan)): ?>
			<?php foreach ($list_kegiatan as $kegiatan): ?>
				<tr>
					<td></td>
					<td><?php echo $kegiatan->nama; ?></td>
					<td data-order="<?php echo $kegiatan->tanggal; ?>"><?php echo date_reverse($kegiatan->tanggal); ?></td>
					<td><?php echo $kegiatan->kabupaten; ?></td>
					<td><?php echo $kegiatan->kecamatan; ?></td>
					<td><?php echo $kegiatan->desa; ?></td>
					<td class="text-center">
						<p><div class="label label-info">Laki-laki: <?php echo $kegiatan->jumlah_lk ?></div></p>
						<p><div class="label label-secondary">Perempuan: <?php echo $kegiatan->jumlah_p ?></div></p>
					</td>
					<td class="text-center">
					<?php
						if($kegiatan->status == 0){
							echo '<div class="label label-danger">Belum Terlaksana</div>';
						}
						elseif($kegiatan->status == 1){
							echo '<div class="label label-success">Sudah Terlaksana</div>';
						}
					?>
					</td>
					<td>
						<a class="btn btn-blue btn-sm" href="<?php echo base_url('kegiatan/detail/'.$kegiatan->id); ?>" title="Detail Kegiatan" target="_blank">
							<i class="entypo-newspaper"></i>
						</a>
					<?php if($this->permission->check_permission($modules, 'all') || $this->session->userdata('edit_saran') == 1 ): ?>
						<a class="btn btn-info btn-sm" href="<?php echo base_url('kegiatan/saran/'.$kegiatan->id); ?>" title="Edit Saran" target="_blank">
							<i class="entypo-clipboard"></i>
						</a>
					<?php endif; ?>
					<?php if($this->permission->check_permission($modules, 'all') || ($this->permission->check_permission($modules, 'edit') && $kegiatan->id_operator == $this->session->userdata('user_id'))): ?>
						<a class="btn btn-green btn-sm" href="<?php echo base_url('kegiatan/edit/'.$kegiatan->id); ?>" title="Edit">
							<i class="entypo-pencil"></i>
						</a>
					<?php endif; ?>
					<?php if($this->permission->check_permission($modules, 'all') || ($this->permission->check_permission($modules, 'delete') && $kegiatan->id_operator == $this->session->userdata('user_id'))): ?>
						<button class="btn btn-danger btn-sm delete-trigger" data-href="<?php echo base_url('kegiatan/hapus/'.$kegiatan->id); ?>" data-toggle="modal" data-target="#confirm-delete" title="Hapus Kegiatan">
							<i class="entypo-cancel"></i>
						</button>
					<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php else: ?>
			<tr>
				<td colspan="6">Belum ada data kegiatan untuk saat ini.</td>
			</tr>
		<?php endif ?>
		</tbody>
	</table>

	<script>
		jQuery(document).ready(function($){
			var responsiveHelper;
			var breakpointDefinition = {
			    tablet: 1024,
			    phone : 480
			};

	<?php if(!empty($list_kegiatan)): ?>
		<?php if($this->permission->check_module($modules, 'kegiatan')): ?>
			tableKegiatan = $("#list-kegiatan");

			tableKegiatan.dataTable({
		        "order": [[ 2, 'desc' ]],
				fnPreDrawCallback: function () {
			        if (!responsiveHelper) {
			            responsiveHelper = new ResponsiveDatatablesHelper(tableKegiatan, breakpointDefinition);
			        }
			    },
			    fnRowCallback  : function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
			        responsiveHelper.createExpandIcon(nRow);
			    },
			    fnDrawCallback : function (oSettings) {
			        responsiveHelper.respond();
			        if ( oSettings.bSorted || oSettings.bFiltered )
		            {
		                for ( var i=0, iLen=oSettings.aiDisplay.length ; i<iLen ; i++ )
		                {
		                    $('td:eq(0)', oSettings.aoData[ oSettings.aiDisplay[i] ].nTr ).html( i+1 );
		                }
		            }
			        $('#confirm-delete').on('show.bs.modal', function(e) {
			            $(this).find('.btn-delete').attr('href', $(e.relatedTarget).data('href'));
			        });
			    }
			});
		<?php endif ?>
	<?php endif ?>
		});
	</script>