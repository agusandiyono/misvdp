	<?php if ($this->session->flashdata('error_message')) : ?>
		<div class="alert alert-danger"><?php echo $this->session->flashdata('error_message'); ?></div>
	<?php endif;?>
	<form role="form" method="post" class="form-horizontal form-groups-bordered validate" enctype="multipart/form-data">
		<input type="hidden" name="<?php echo $this->security->get_csrf_token_name() ?>" id="csrf" value="<?php echo $this->security->get_csrf_hash() ?>" />		
		<div class="form-group">
			<div class="col-sm-12">
				<span class="text-danger">* Wajib Diisi</span>
			</div>
		</div>
		<div class="form-group">
			<label for="nama" class="col-sm-3 control-label">Nama Kegiatan<span class="text-danger">*</span></label>
			<div class="col-sm-5">
			<?php
				if($kegiatan->nama != "Penyusunan rencana kerja" || $kegiatan->nama != "Perkenalan dan Koordinasi" || $kegiatan->nama != "Sosialisasi, Promosi dan Penyadaran" || $kegiatan->nama != "Musyawarah Pemilihan Pendamping Kampung " || $kegiatan->nama != "Musyawarah dan Fasilitasi Penyusunan RKP Desa" || $kegiatan->nama != "Penggalian situasi dan Kondisi" || $kegiatan->nama != "Fasilitasi Pelatihan P3D dan Teknik" || $kegiatan->nama != "Fasilitasi Bimtek Pengolahan Hasil" || $kegiatan->nama != "Sekolah Lapang" || $kegiatan->nama != "Rapat koordinasi rutin" || $kegiatan->nama != "Pembinaan Masyarakat" || $kegiatan->nama != "Monitoring dan evaluasi" || $kegiatan->nama != "Pelaporan"){
					$kegiatan->nama_lain = 1;
				}
			?>
				<div id="field-nama" <?php echo $kegiatan->nama_lain == 1 ? 'style="display: none;"' : "" ?>>
					<select name="data[nama]" class="form-control select2" id="nama" placeholder="Nama Kegiatan">
						<option></option>
						<option value="Penyusunan rencana kerja" <?php echo $kegiatan->nama == "Penyusunan rencana kerja" || $kegiatan->nama_lain == 1 ? "selected" : "" ?>>Penyusunan rencana kerja</option>
						<option value="Perkenalan dan Koordinasi" <?php echo $kegiatan->nama == "Perkenalan dan Koordinasi" ? "selected" : "" ?>>Perkenalan dan Koordinasi</option>
						<option value="Sosialisasi, Promosi dan Penyadaran" <?php echo $kegiatan->nama == "Sosialisasi, Promosi dan Penyadaran" ? "selected" : "" ?>>Sosialisasi, Promosi dan Penyadaran</option>
						<option value="Musyawarah Pemilihan Pendamping Kampung " <?php echo $kegiatan->nama == "Musyawarah Pemilihan Pendamping Kampung " ? "selected" : "" ?>>Musyawarah Pemilihan Pendamping Kampung </option>
						<option value="Musyawarah dan Fasilitasi Penyusunan RKP Desa" <?php echo $kegiatan->nama == "Musyawarah dan Fasilitasi Penyusunan RKP Desa" ? "selected" : "" ?>>Musyawarah dan Fasilitasi Penyusunan RKP Desa</option>
						<option value="Penggalian situasi dan Kondisi" <?php echo $kegiatan->nama == "Penggalian situasi dan Kondisi" ? "selected" : "" ?>>Penggalian situasi dan Kondisi</option>
						<option value="Fasilitasi Pelatihan P3D dan Teknik" <?php echo $kegiatan->nama == "Fasilitasi Pelatihan P3D dan Teknik" ? "selected" : "" ?>>Fasilitasi Pelatihan P3D dan Teknik</option>
						<option value="Fasilitasi Bimtek Pengolahan Hasil" <?php echo $kegiatan->nama == "Fasilitasi Bimtek Pengolahan Hasil" ? "selected" : "" ?>>Fasilitasi Bimtek Pengolahan Hasil</option>
						<option value="Sekolah Lapang" <?php echo $kegiatan->nama == "Sekolah Lapang" ? "selected" : "" ?>>Sekolah Lapang</option>
						<option value="Rapat koordinasi rutin" <?php echo $kegiatan->nama == "Rapat koordinasi rutin" ? "selected" : "" ?>>Rapat koordinasi rutin</option>
						<option value="Pembinaan Masyarakat" <?php echo $kegiatan->nama == "Pembinaan Masyarakat" ? "selected" : "" ?>>Pembinaan Masyarakat</option>
						<option value="Monitoring dan evaluasi" <?php echo $kegiatan->nama == "Monitoring dan evaluasi" ? "selected" : "" ?>>Monitoring dan evaluasi</option>
						<option value="Pelaporan" <?php echo $kegiatan->nama == "Pelaporan" ? "selected" : "" ?>>Pelaporan</option>
					</select>
					<br>
				</div>
				<div class="checkbox checkbox-replace color-blue">
					<input type="checkbox" name="data[nama_lain]" id="nama_lain" <?php echo $kegiatan->nama_lain == 1 ? 'checked="checked"' : "" ?>>
					<label>Centang untuk nama kegiatan selain yang tersedia pada pilihan diatas</label>
				</div><br>
				<div id="field-nama-lain" <?php echo $kegiatan->nama_lain == 0 ? 'style="display: none;"' : "" ?>>
					<input type="text" class="form-control" name="kegiatan_lain" data-validate="required" data-message-required="Kolom nama kegiatan lain tidak boleh kosong." placeholder="Nama Kegiatan" value="<?php echo $kegiatan->nama_lain == 1 ? $kegiatan->nama : "" ?>">
				</div>
			</div>
		</div>
		<div class="form-group">
			<label for="sub_kegiatan" class="col-sm-3 control-label">Sub Kegiatan</label>
			<div class="col-sm-5">
				<textarea class="form-control" name="data[sub_kegiatan]" rows="5"><?php echo $kegiatan->sub_kegiatan ?></textarea>
			</div>
		</div>
		<div class="form-group">
			<label for="tanggal" class="col-sm-3 control-label">Tanggal Kegiatan<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" class="form-control datepicker" data-format="dd-mm-yyyy" id="tanggal" name="data[tanggal]" data-validate="required" data-message-required="Kolom tanggal kegiatan tidak boleh kosong." placeholder="Tanggal Kegiatan" value="<?php echo date_reverse($kegiatan->tanggal) ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="provinsi_id" class="col-sm-3 control-label">Provinsi<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<?php if(!empty($this->session->userdata('provinsi_id'))): ?>
					<input type="hidden" name="data[provinsi_id]" value="<?php echo $this->session->userdata('provinsi_id') ?>" />
				<?php endif ?>
				<select name="data[provinsi_id]" class="form-control select2" id="provinsi_id" placeholder="Provinsi" data-validate="required" data-message-required="Kolom provinsi tidak boleh kosong." <?php echo !empty($this->session->userdata('provinsi_id')) ? 'disabled' : "" ?>>
					<option></option>
				<?php foreach ($list_provinsi as $provinsi): ?>
					<option value="<?php echo $provinsi->provinsi_code ?>" <?php echo $provinsi->provinsi_code == $kegiatan->provinsi_id ? "selected" : "" ?>><?php echo $provinsi->provinsi_code ?> - <?php echo $provinsi->provinsi_name ?></option>
				<?php endforeach ?>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="kabupaten_id" class="col-sm-3 control-label">Kabupaten<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" name="data[kabupaten_id]" class="form-control" id="kabupaten_id" placeholder="Kabupaten" <?php echo !empty($this->session->userdata('kabupaten_id')) ? 'readonly' : "" ?>>
			</div>
		</div>
		<div class="form-group">
			<label for="kecamatan_id" class="col-sm-3 control-label">Kecamatan<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" name="data[kecamatan_id]" class="form-control" id="kecamatan_id" placeholder="Kecamatan" <?php echo !empty($this->session->userdata('kecamatan_id')) ? 'readonly' : "" ?>>
			</div>
		</div>
		<div class="form-group">
			<label for="desa_id" class="col-sm-3 control-label">Desa<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" name="data[desa_id]" class="form-control" id="desa_id" placeholder="Desa" <?php echo !empty($this->session->userdata('desa_id')) ? 'readonly' : "" ?>>
			</div>
		</div>
		<div class="form-group">
			<label for="status" class="col-sm-3 control-label">Progress<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<select name="data[status]" class="form-control" id="status">
					<option value="0" <?php echo $kegiatan->status == 0 ? "selected" : "" ?>>Belum Terlaksana</option>
					<option value="1" <?php echo $kegiatan->status == 1 ? "selected" : "" ?>>Sudah Terlaksana</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label for="deskripsi" class="col-sm-3 control-label">Gambaran Pelaksanaan Kegiatan<span class="text-danger">*</span></label>
			<div class="col-sm-9">
				<textarea class="form-control ckeditor" name="data[deskripsi]"><?php echo $kegiatan->deskripsi ?></textarea>
			</div>
		</div>
		<div class="form-group">
			<label for="sasaran" class="col-sm-3 control-label">Sasaran<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="sasaran" name="data[sasaran]" data-validate="required" data-message-required="Kolom sasaran kegiatan tidak boleh kosong." placeholder="Sasaran" value="<?php echo $kegiatan->sasaran ?>">
			</div>
		</div>

		<h3>Jumlah Peserta yang Hadir</h3>
		<hr>
		<div class="form-group">
			<label for="jumlah_lk" class="col-sm-3 control-label">Jumlah Peserta Laki-laki<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="jumlah_lk" name="data[jumlah_lk]" data-validate="required" data-message-required="Kolom jumlah yang hadir kegiatan tidak boleh kosong." placeholder="Jumlah peserta" value="<?php echo $kegiatan->jumlah_lk ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="jumlah_p" class="col-sm-3 control-label">Jumlah Peserta Perempuan<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="jumlah_p" name="data[jumlah_p]" data-validate="required" data-message-required="Kolom jumlah yang hadir kegiatan tidak boleh kosong." placeholder="Jumlah peserta" value="<?php echo $kegiatan->jumlah_p ?>">
			</div>
		</div>

		<h3>Dokumentasi</h3>
		<hr>
		<div class="form-group">
			<label for="foto" class="col-sm-3 control-label">Foto<span class="text-danger">*</span></label>
			<div class="col-sm-9">
			<?php if(!empty($list_foto)): ?>
				<div class="row">
					<?php foreach($list_foto as $foto_key => $foto): ?>
						<div class="col-sm-6 col-md-2 clearfix">
							<div class="container-foto">
								<img src="<?php echo base_url('uploads/foto/'.$foto) ?>" alt="<?php echo $foto ?>" class="img-responsive">
								<button type="button" class="btn btn-red btn-icon btn-sm delete-file" data-target="foto" data-file="<?php echo $foto ?>">
									Hapus Foto
									<i class="entypo-cancel"></i>
								</button>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
				<br>
			<?php endif ?>
				<input type="file" class="form-control file2 inline btn btn-primary" id="foto" name="foto[]" multiple="1" data-label="<i class='glyphicon glyphicon-circle-arrow-up'></i> &nbsp;Upload Foto" />
				<p><strong>Ekstensi foto yang diperbolehkan adalah gif, jpg, jpeg, png.</strong></p>
			</div>
		</div>
		<div class="form-group">
			<label for="video" class="col-sm-3 control-label">Video<span class="text-danger">*</span></label>
			<div class="col-sm-9">
			<?php if(!empty($list_video)): ?>
				<div class="row">
					<div class="col-md-12">
					<?php foreach($list_video as $video_key => $video): ?>
						<div class="container-video">
							<a href="<?php echo base_url('uploads/video/'.$video) ?>"><?php echo $video ?></a>
							<button type="button" class="btn btn-red btn-icon btn-sm delete-file" data-target="video" data-file="<?php echo $video ?>">
								Hapus Video
								<i class="entypo-cancel"></i>
							</button>
						</div>
						<br>
					<?php endforeach; ?>
					</div>
				</div>
			<?php endif ?>
				<input type="file" class="form-control file2 inline btn btn-primary" id="video" name="video[]" multiple="1" data-label="<i class='glyphicon glyphicon-circle-arrow-up'></i> &nbsp;Upload Video" />
				<p><strong>Ekstensi foto yang diperbolehkan adalah avi, mp4, 3gp, mpeg, mpg, mov, mp3, flv, wmv.</strong></p>
			</div>
		</div>

		<h3>Pemahaman Peserta</h3>
		<hr>
		<div class="form-group">
			<label for="jumlah_paham" class="col-sm-3 control-label">Berapa Persen Sasaran Dapat Memahami?<span class="text-danger">*</span></label>
			<div class="col-sm-5">
				<input type="text" class="form-control" id="jumlah_paham" name="data[jumlah_paham]" data-validate="required" data-message-required="Kolom jumlah yang hadir kegiatan tidak boleh kosong." placeholder="Persentase" value="<?php echo $kegiatan->jumlah_paham ?>">
			</div>
		</div>
		<div class="form-group">
			<label for="alasan_paham" class="col-sm-3 control-label">Apa Alasan Anda Mereka Dapat Memahami?<span class="text-danger">*</span></label>
			<div class="col-sm-9">
				<textarea class="form-control ckeditor" name="data[alasan_paham]"><?php echo $kegiatan->alasan_paham ?></textarea>
			</div>
		</div>

		<h3>Kesimpulan</h3>
		<hr>
		<div class="form-group">
			<label for="masalah" class="col-sm-3 control-label">Masalah<span class="text-danger">*</span></label>
			<div class="col-sm-9">
				<textarea class="form-control ckeditor" name="data[masalah]"><?php echo $kegiatan->masalah ?></textarea>
			</div>
		</div>
		<?php if($this->permission->check_permission($modules, 'all')): ?>
		<div class="form-group">
			<label for="saran" class="col-sm-3 control-label">Saran/Rekomendasi<span class="text-danger">*</span></label>
			<div class="col-sm-9">
				<textarea class="form-control ckeditor" name="data[saran]"><?php echo $kegiatan->saran ?></textarea>
			</div>
		</div>
		<?php endif ?>
		<div class="form-group">
			<label for="rencana_tindak_lanjut" class="col-sm-3 control-label">Rencana Tindak Lanjut<span class="text-danger">*</span></label>
			<div class="col-sm-9">
				<textarea class="form-control ckeditor" name="data[rencana_tindak_lanjut]"><?php echo $kegiatan->rencana_tindak_lanjut ?></textarea>
			</div>
		</div>
		<div class="form-group">
			<label for="tindak_lanjut_lalu" class="col-sm-3 control-label">Tindak Lanjut Masalah Bulan Lalu<span class="text-danger">*</span></label>
			<div class="col-sm-9">
				<textarea class="form-control ckeditor" name="data[tindak_lanjut_lalu]"><?php echo $kegiatan->tindak_lanjut_lalu ?></textarea>
			</div>
		</div>

		<div class="form-group">
			<div class="col-sm-5 col-sm-offset-2">
				<button type="submit" class="btn btn-lg btn-success"><i class="entypo-check"></i> Simpan</button>
				<a href="<?php echo base_url('kegiatan') ?>" class="btn btn-lg btn-red pull-right"><i class="entypo-back"></i> Kembali</a>
			</div>
		</div>
	</form>

	<script type="text/javascript">
		jQuery(document).ready(function($){
			$('#kabupaten_id').select2({
				minimumInputLength: 3,
				allowClear: false,
				minimumResultsForSearch: 10,
				ajax: {
					url: "<?php echo base_url('kegiatan/get_lokasi') ?>",
					dataType: 'json',
					data: function (term, page) {
						return{
							where: 'kabupaten',
							provinsi_id: $('#provinsi_id').val(),
							term: term,
						}
					},
					results: function (data, page) {
						return {
							results: data
						};
					}
				}
			});
			$('#kecamatan_id').select2({
				minimumInputLength: 3,
				allowClear: false,
				minimumResultsForSearch: 10,
				ajax: {
					url: "<?php echo base_url('kegiatan/get_lokasi') ?>",
					dataType: 'json',
					data: function (term, page) {
						return{
							where: 'kecamatan',
							kabupaten_id: $('#kabupaten_id').val(),
							term: term,
						}
					},
					results: function (data, page) {
						return {
							results: data
						};
					}
				}
			});
			$('#desa_id').select2({
				minimumInputLength: 3,
				allowClear: false,
				minimumResultsForSearch: 10,
				ajax: {
					url: "<?php echo base_url('kegiatan/get_lokasi') ?>",
					dataType: 'json',
					data: function (term, page) {
						return{
							where: 'desa',
							kecamatan_id: $('#kecamatan_id').val(),
							term: term,
						}
					},
					results: function (data, page) {
						return {
							results: data
						};
					}
				}
			});
			
			<?php if(!empty($kegiatan->kabupaten)): ?>
				$('#kabupaten_id').select2('data', <?php echo json_encode($kegiatan->kabupaten) ?>);
			<?php endif ?>
			<?php if(!empty($kegiatan->kecamatan)): ?>
				$('#kecamatan_id').select2('data', <?php echo json_encode($kegiatan->kecamatan) ?>);
			<?php endif ?>
			<?php if(!empty($kegiatan->desa)): ?>
				$('#desa_id').select2('data', <?php echo json_encode($kegiatan->desa) ?>);
			<?php endif ?>

			$(".delete-file").click(function(){
				var target = $(this).data('target'),
					file = $(this).data('file');

				$(this).closest('.container-'+target).hide().append('<input type="hidden" name="hapus_'+target+'[]" value="'+file+'">');
			});

			$('#nama_lain').change(function() {
				if(this.checked) {
					$("#field-nama").slideUp();
					$("#field-nama-lain").slideDown();
				}
				else{
					$("#field-nama").slideDown();
					$("#field-nama-lain").slideUp();
				}
			});
		});
	</script>